<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            $table->dropUnique('users_badgenumber_unique');
            $table->dropColumn('badgeNumber');
        });
    }

    public function down(): void
    {
        Schema::table('users', fn (Blueprint $table) => $table->string('badgeNumber')->nullable()->unique());
    }
};
