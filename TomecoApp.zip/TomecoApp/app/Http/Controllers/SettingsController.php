<?php

namespace App\Http\Controllers;

use App\Services\Settings;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class SettingsController extends Controller
{
    public function index(Request $request, Settings $settings): View
    {
        $this->admin($request);

        return view('dashboard.settings', ['settings' => $settings->all(), 'activeTab' => $request->query('tab', 'general')]);
    }

    public function update(Request $request, Settings $settings): RedirectResponse
    {
        $this->admin($request);
        $section = $request->validate(['section' => ['required', Rule::in(['general', 'notifications', 'security'])]])['section'];
        foreach ($this->booleanFields($section) as $field) {
            $request->merge([$field => $request->boolean($field)]);
        }
        $values = $this->validatedSection($request, $section);
        $settings->putMany(collect($values)->mapWithKeys(fn ($value, $key) => [$section.'.'.$key => $value])->all());

        return to_route('dashboard.settings', ['tab' => $section])->with('success', ucfirst($section).' settings saved.');
    }

    private function validatedSection(Request $request, string $section): array
    {
        return match ($section) {
            'general' => $request->validate(['organization_name' => 'required|string|max:100', 'address' => 'nullable|string|max:255', 'phone' => 'nullable|string|max:30', 'email' => 'nullable|email', 'timezone' => 'required|timezone', 'date_format' => 'required|string|max:30', 'violation_prefix' => 'required|string|max:10']),
            'notifications' => $request->validate(['new_violation' => 'boolean', 'overdue_reminder' => 'boolean', 'recipient_email' => 'nullable|email']),
            'security' => $request->validate(['password_min_length' => 'required|integer|min:8|max:64', 'session_timeout' => 'required|integer|min:5|max:1440', 'login_attempts' => 'required|integer|min:3|max:20', 'two_factor' => 'boolean', 'admin_signup_enabled' => 'boolean', 'api_token_days' => 'required|integer|min:1|max:365', 'audit_retention_days' => 'required|integer|min:30|max:3650']),
        };
    }

    private function admin(Request $request): void
    {
        abort_unless($request->user()?->isAdmin(), 403);
    }

    private function booleanFields(string $section): array
    {
        return match ($section) {
            'notifications' => ['new_violation', 'overdue_reminder'],
            'security' => ['two_factor', 'admin_signup_enabled'],
            default => [],
        };
    }
}
