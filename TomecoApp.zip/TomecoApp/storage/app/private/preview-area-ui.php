<?php
foreach (['APP_ENV' => 'testing', 'DB_CONNECTION' => 'sqlite', 'DB_DATABASE' => ':memory:', 'DB_URL' => '', 'CACHE_STORE' => 'array', 'SESSION_DRIVER' => 'array', 'MAIL_MAILER' => 'array', 'BROADCAST_CONNECTION' => 'null'] as $key => $value) { putenv($key.'='.$value); $_ENV[$key]=$value; $_SERVER[$key]=$value; }
require __DIR__.'/../../../vendor/autoload.php';
$app=require __DIR__.'/../../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
config(['database.default'=>'sqlite','database.connections.sqlite.database'=>':memory:','database.connections.sqlite.url'=>null,'session.driver'=>'array','cache.default'=>'array']);
Illuminate\Support\Facades\DB::purge();
Illuminate\Support\Facades\Artisan::call('migrate',['--force'=>true]);
Illuminate\Support\Facades\URL::forceRootUrl('http://area.test');
$app['session']->start();
Illuminate\Support\Facades\View::share('errors',new Illuminate\Support\ViewErrorBag);
foreach (['Abucay','Downtown','Palo'] as $name) Illuminate\Support\Facades\DB::table('operational_areas')->insertOrIgnore(['name'=>$name,'created_at'=>now(),'updated_at'=>now()]);
$admin=App\Models\User::factory()->create(['role'=>App\Models\User::ROLE_ADMIN,'firstName'=>'Sample','lastName'=>'Administrator']);
$supervisor=App\Models\User::factory()->create(['role'=>App\Models\User::ROLE_SUPERVISOR,'firstName'=>'Sample','lastName'=>'Supervisor']);
foreach ([['Ana','Santos','Abucay'],['Miguel','Reyes',null],['Sofia','Cruz','Downtown'],['Carlo','Ramos','Palo']] as [$first,$last,$area]) App\Models\User::factory()->create(['role'=>App\Models\User::ROLE_OFFICER,'supervisor_id'=>$supervisor->id,'firstName'=>$first,'lastName'=>$last,'middleName'=>null,'nameExtension'=>null,'area'=>$area,'username'=>strtolower($first).'.'.strtolower($last),'profile_photo_path'=>null]);
$render=function($key,$viewer,$query=[])use($app){
 Illuminate\Support\Facades\Auth::setUser($viewer);
 $request=Illuminate\Http\Request::create('http://area.test/area-assignments','GET',$query);
 $request->setLaravelSession($app["session"]->driver()); $request->setUserResolver(fn()=>$viewer); $app->instance('request',$request);
 Illuminate\Pagination\Paginator::currentPathResolver(fn()=>'http://area.test/area-assignments');
 file_put_contents(__DIR__.'/area-ui-'.$key.'.html',app(App\Http\Controllers\AreaAssignmentController::class)->index($request)->render());
};
$render('admin',$admin); $render('supervisor',$supervisor); $render('filtered',$admin,['search'=>'Ana','area'=>'Abucay']); $render('empty',$admin,['search'=>'Missing']);
$longArea = str_repeat('Long operational area name ', 5);
Illuminate\Support\Facades\DB::table('operational_areas')->insert(['name'=>$longArea,'created_at'=>now(),'updated_at'=>now()]);
App\Models\User::where('role', App\Models\User::ROLE_OFFICER)->orderBy('id')->first()->update(['firstName'=>str_repeat('LongName ',8),'area'=>$longArea]);
$render('long',$admin);
Illuminate\Support\Facades\View::share('errors',(new Illuminate\Support\ViewErrorBag)->put('default',new Illuminate\Support\MessageBag(['name'=>'The name has already been taken.'])));
$app['session']->flash('_old_input',['name'=>'Abucay']);
$render('modal-error',$admin);
$app['session']->forget('_old_input');
Illuminate\Support\Facades\View::share('errors',new Illuminate\Support\ViewErrorBag);
for($i=0;$i<20;$i++) App\Models\User::factory()->create(['role'=>App\Models\User::ROLE_OFFICER,'supervisor_id'=>$supervisor->id,'firstName'=>'Team','lastName'=>'Member '.($i+1),'area'=>'Abucay','profile_photo_path'=>null]);
$render('pages',$admin);
$render('page2',$admin,['page'=>2]);
$failedOfficer=App\Models\User::where('role',App\Models\User::ROLE_OFFICER)->orderBy('id')->first();
Illuminate\Support\Facades\View::share('errors',(new Illuminate\Support\ViewErrorBag)->put('default',new Illuminate\Support\MessageBag(['area'=>'The selected area is invalid.'])));
$app['session']->flash('_old_input',['assignment_user_id'=>(string)$failedOfficer->id,'area'=>'Palo']);
$render('row-error',$admin);
$app['session']->forget('_old_input');
Illuminate\Support\Facades\View::share('errors',new Illuminate\Support\ViewErrorBag);
$failedOfficer->update(['area'=>'Palo']);
$app['session']->flash('area_assignment_success','Area assignment was updated.');
$render('success',$admin);
App\Models\Violation::create(['first_name'=>'Mara','last_name'=>'Santos','plate_number'=>'ABC-2468','vehicle_type'=>'Motorcycle','violation_type'=>'Illegal parking','fine_amount'=>500]);
foreach (['admin'=>$admin,'supervisor'=>$supervisor] as $role=>$viewer) {
 foreach (['area','Ana','Mara','nomatch'] as $query) {
  $request=Illuminate\Http\Request::create('http://area.test/dashboard/search','GET',['q'=>$query]);
  $request->setUserResolver(fn()=>$viewer);
  file_put_contents(__DIR__.'/dashboard-search-'.$role.'-'.strtolower($query).'.json',app(App\Http\Controllers\DashboardSearchController::class)($request,app(App\Services\ViolationRecords::class))->getContent());
 }
}
echo "Rendered area/search UI fixtures using fictional in-memory data.\n";




