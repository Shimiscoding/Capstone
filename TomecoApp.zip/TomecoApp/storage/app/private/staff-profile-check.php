<?php

use App\Http\Controllers\DashboardController;
use App\Models\User;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

require __DIR__.'/../../../vendor/autoload.php';
$app = require __DIR__.'/../../../bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();
$admin = User::query()->where('role', User::ROLE_ADMIN)->firstOrFail();
Auth::setUser($admin);
$request = Request::create('/dashboard/users', 'GET');
$request->setUserResolver(fn () => $admin);
$request->setLaravelSession($app->make('session')->driver());
$app->instance('request', $request);
view()->share('errors', new \Illuminate\Support\ViewErrorBag);
$controller = $app->make(DashboardController::class);
$results = [];
foreach (['officer' => 'showEnforcer', 'supervisor' => 'showSupervisor', 'admin' => 'showAdmin'] as $role => $method) {
    $user = User::query()->where('role', $role)->firstOrFail();
    $html = $controller->$method($request, $user)->render();
    if ($user->profile_photo_url) {
        $photo = $app->make(\App\Http\Controllers\ProfilePhotoController::class)->show($request, $user)->getFile();
        $html = str_replace(e($user->profile_photo_url), 'data:'.$photo->getMimeType().';base64,'.base64_encode(file_get_contents($photo->getPathname())), $html);
    }
    foreach (['Personal information', 'Contact information', 'Account details', 'First name', 'Address', 'Username', 'Joined'] as $label) {
        if (!str_contains($html, $label)) throw new RuntimeException('Missing profile detail: '.$label);
    }
    file_put_contents(__DIR__.'/staff-profile-'.$role.'.html', $html);
    $results[] = ['role' => $role, 'sections' => true, 'rendered' => true];
    if ($role === 'officer') {
        $user->firstName = 'Alexandria Patricia';
        $user->lastName = 'Fernandez Dela Cruz';
        $user->email = 'alexandria.patricia.fernandez.delacruz@example.com';
        $user->address = str_repeat('Unit 204, Justice Romualdez Street, Barangay 17, Tacloban City. ', 3);
        $user->area = null;
        $user->profile_photo_path = null;
        $user->setRelation('supervisor', null);
        $html = view('dashboard.users.staff-show', ['staffUser' => $user, 'section' => 'enforcers', 'sectionLabel' => 'Enforcer'])->render();
        if (!str_contains($html, 'Unassigned')) throw new RuntimeException('Missing assignment fallback.');
        file_put_contents(__DIR__.'/staff-profile-long.html', $html);
    }
}
$supervisors = User::query()->where('role', User::ROLE_SUPERVISOR)->get();
$html = view('dashboard.users.user-create', ['fixedRole' => User::ROLE_OFFICER, 'userSection' => 'enforcers', 'supervisors' => $supervisors])->render();
file_put_contents(__DIR__.'/staff-profile-create-comparison.html', $html);
echo json_encode($results).PHP_EOL;
