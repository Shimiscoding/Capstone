<?php
// Isolated visual fixtures: all database changes are confined to SQLite memory.
foreach (['APP_ENV' => 'testing', 'DB_CONNECTION' => 'sqlite', 'DB_DATABASE' => ':memory:', 'DB_URL' => '', 'CACHE_STORE' => 'array', 'SESSION_DRIVER' => 'array', 'MAIL_MAILER' => 'array', 'BROADCAST_CONNECTION' => 'null'] as $key => $value) {
    putenv($key.'='.$value);
    $_ENV[$key] = $value;
    $_SERVER[$key] = $value;
}
require __DIR__.'/../../../vendor/autoload.php';
$app = require __DIR__.'/../../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
config(['database.default' => 'sqlite', 'database.connections.sqlite.database' => ':memory:', 'database.connections.sqlite.url' => null, 'session.driver' => 'array', 'cache.default' => 'array']);
Illuminate\Support\Facades\DB::purge();
Illuminate\Support\Facades\Artisan::call('migrate', ['--force' => true]);
Illuminate\Support\Facades\URL::forceRootUrl('http://127.0.0.1:8799');
$app['session']->start();
$supervisor = App\Models\User::factory()->create(['role' => App\Models\User::ROLE_SUPERVISOR, 'firstName' => 'Andrea', 'lastName' => 'Reyes', 'profile_photo_path' => null]);
Illuminate\Support\Facades\Auth::setUser($supervisor);
$names = [['Miguel','Santos','Downtown'], ['Ana','Cruz','Downtown'], ['Paolo','Reyes','Downtown'], ['Isabel','Garcia','Downtown'], ['Carlo','Mendoza','San Jose'], ['Sofia','Ramos','San Jose'], ['Luis','Torres','Marasbaras'], ['Maria','Flores','Marasbaras'], ['Daniel','Lim','Abucay'], ['Rosa','Dela Cruz',null]];
foreach ($names as $i => [$first, $last, $area]) {
    App\Models\User::factory()->create(['role' => App\Models\User::ROLE_OFFICER, 'supervisor_id' => $supervisor->id, 'firstName' => $first, 'lastName' => $last, 'middleName' => null, 'nameExtension' => null, 'area' => $area, 'username' => strtolower($first).'.'.strtolower(str_replace(' ', '', $last)), 'email' => strtolower($first).'.enforcer@example.test', 'phoneNumber' => '0917 000 '.str_pad((string) $i, 4, '0', STR_PAD_LEFT), 'profile_photo_path' => null]);
}
$render = function ($file, $page = 1) use ($app, $supervisor) {
    $request = Illuminate\Http\Request::create('http://127.0.0.1:8799/dashboard', 'GET', ['page' => $page]);
    $request->setUserResolver(fn () => $supervisor);
    $app->instance('request', $request);
    Illuminate\Pagination\Paginator::currentPathResolver(fn () => 'http://127.0.0.1:8799/dashboard');
    $html = app(App\Http\Controllers\DashboardController::class)->index($request)->render();
    file_put_contents(__DIR__.'/'.$file, $html);
};
$render('supervisor-home-preview.html');
$render('supervisor-home-page2.html', 2);
App\Models\User::where('supervisor_id', $supervisor->id)->update(['area' => str_repeat('Long operational area name ', 7), 'firstName' => str_repeat('Longname ', 5)]);
$render('supervisor-home-long.html');
App\Models\User::where('supervisor_id', $supervisor->id)->delete();
$render('supervisor-home-empty.html');
echo "Rendered populated, page 2, long-content, and empty fixtures using SQLite memory.\n";
