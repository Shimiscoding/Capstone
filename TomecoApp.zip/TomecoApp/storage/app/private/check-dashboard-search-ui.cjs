const {chromium}=require('C:/Users/Tamano/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs'),path=require('path');
(async()=>{
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
const page=await browser.newPage(); const errors=[];page.on('pageerror',e=>errors.push(e.message));let fail=false;const queries=[];
await page.route('**/*',async route=>{const url=new URL(route.request().url());
if(url.pathname==='/dashboard/search'){const q=url.searchParams.get('q');queries.push(q);if(q==='slow')await new Promise(r=>setTimeout(r,600));if(fail)return route.fulfill({status:500,body:'failed'});return route.fulfill({contentType:'application/json',body:JSON.stringify({results:q==='none'?[]:[{kind:'Pages',label:q==='fast'?'Fast result':'Area Assignments',description:'Manage enforcer areas',url:'http://area.test/area-assignments'}]})});}
if(url.pathname==='/area-assignments')return route.fulfill({contentType:'text/html',body:fs.readFileSync('storage/app/private/area-ui-admin.html','utf8')});
if(/^\/(css|js|images|build)\//.test(url.pathname)&&!url.pathname.includes('..')){const file=path.join('public',decodeURIComponent(url.pathname));if(fs.existsSync(file))return route.fulfill({contentType:url.pathname.endsWith('.css')?'text/css':url.pathname.endsWith('.js')?'application/javascript':url.pathname.endsWith('.png')?'image/png':'image/jpeg',body:fs.readFileSync(file)});}
return route.fulfill({status:404,body:''});});
const results=[];
for(const width of [1440,820,600,390,320]){
await page.setViewportSize({width,height:900});await page.goto('http://area.test/area-assignments');
const input=page.locator('#dashboardSearchInput');await input.fill('area');await input.press('Enter');await page.getByRole('link',{name:'Area Assignments Manage enforcer areas',exact:true}).waitFor();
const geom=await page.evaluate(()=>({width:innerWidth,document:document.documentElement.scrollWidth,form:document.querySelector('[data-dashboard-search]').getBoundingClientRect().toJSON(),panel:document.querySelector('#dashboardSearchResults').getBoundingClientRect().toJSON()}));
if(geom.document>width||geom.panel.x<0||geom.panel.right>width)throw new Error('Search overflow '+JSON.stringify(geom));
await input.press('ArrowDown');if(!await page.locator('.dashboard-search-result').evaluate(el=>el===document.activeElement))throw new Error('ArrowDown');await page.keyboard.press('Escape');if(await page.locator('#dashboardSearchResults').isVisible())throw new Error('Escape reopen');
await input.fill('none');await input.press('Enter');await page.getByText('No results found. Try another search.').waitFor();await page.getByRole('button',{name:'Clear dashboard search'}).click();if(await input.inputValue()!==''||await page.locator('#dashboardSearchResults').isVisible())throw new Error('Clear');
results.push(geom);}
fail=true;await page.locator('#dashboardSearchInput').fill('error');await page.locator('#dashboardSearchInput').press('Enter');await page.getByRole('button',{name:'Retry search'}).waitFor();fail=false;await page.getByRole('button',{name:'Retry search'}).click();await page.locator('.dashboard-search-result').waitFor();
await page.locator('#dashboardSearchInput').fill('slow');await page.locator('#dashboardSearchInput').press('Enter');await page.waitForTimeout(60);await page.locator('#dashboardSearchInput').fill('fast');await page.locator('#dashboardSearchInput').press('Enter');await page.getByText('Fast result',{exact:true}).waitFor();await page.waitForTimeout(650);if(await page.locator('.dashboard-search-result strong').innerText()!=='Fast result')throw new Error('Stale response');
await page.locator('#dashboardSearchInput').fill('slow');await page.locator('#dashboardSearchInput').press('Enter');await page.keyboard.press('Escape');await page.waitForTimeout(650);if(await page.locator('#dashboardSearchResults').isVisible())throw new Error('Dismissed response reopened');
if(errors.length)throw new Error(errors.join('\n'));console.log(JSON.stringify({checks:'5 widths, results, keyboard, clear, empty, retry, stale response and pending dismissal passed',results,queries,errors}));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
