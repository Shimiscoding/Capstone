<?php

use App\Http\Controllers\DashboardController;
use App\Models\TicketViolationItem;
use App\Models\User;
use App\Models\Violation;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

require __DIR__.'/../../../vendor/autoload.php';
$app = require __DIR__.'/../../../bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();
$admin = User::query()->where('role', User::ROLE_ADMIN)->firstOrFail();
Auth::setUser($admin);
$request = Request::create('/dashboard', 'GET');
$request->setUserResolver(fn () => $admin);
$request->setLaravelSession($app->make('session')->driver());
$app->instance('request', $request);
$view = $app->make(DashboardController::class)->index($request);
$labels = ['Unregistered Vehicle', 'Illegal Parking', 'Disregarding Traffic Sign', 'No Helmet', 'Defective Headlight'];
$tickets = collect([5, 3, 1])->map(function ($count) use ($labels) {
    $ticket = new Violation([
        'first_name' => 'Juan Pedro', 'last_name' => 'Garcia Dela Cruz',
        'location' => 'Violation location that should not appear in the preview',
        'registered_owner_address' => $count === 1 ? null : 'Justice Romualdez Street, Barangay 17, Tacloban City',
        'plate_number' => 'ABC 1234', 'fine_amount' => 5500, 'status' => 'unpaid',
    ]);
    $ticket->created_at = now();
    $ticket->setRelation('issuedViolations', collect(array_slice($labels, 0, $count))->map(
        fn ($label) => new TicketViolationItem(['description_snapshot' => $label])
    ));
    return $ticket;
});
$html = $view->with('recentViolations', $tickets)->render();
preg_match_all('/<strong>([^<]*)<\/strong><small>Juan Pedro/', $html, $matches);
$expected = [implode(', ', array_slice($labels, 0, 3)).' ...', implode(', ', array_slice($labels, 0, 3)), $labels[0]];
if ($matches[1] !== $expected || !str_contains($html, 'Owner address: Justice Romualdez Street, Barangay 17, Tacloban City')
    || !str_contains($html, 'Owner address: Not recorded')
    || str_contains($html, 'Violation location that should not appear in the preview')) {
    throw new RuntimeException('Ticket preview or owner address rendering failed.');
}
file_put_contents(__DIR__.'/recent-tickets-preview.html', $html);
$empty = $view->with('recentViolations', collect())->render();
if (!str_contains($empty, 'No tickets have been issued yet.')) {
    throw new RuntimeException('Empty state rendering failed.');
}
echo json_encode(['preview_counts' => [5, 3, 1], 'limit_and_ellipsis' => true, 'owner_address' => true, 'missing_address_fallback' => true, 'empty_state' => true]).PHP_EOL;
