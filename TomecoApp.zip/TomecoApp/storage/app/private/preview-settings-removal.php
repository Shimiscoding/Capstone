<?php
foreach (['APP_ENV' => 'testing', 'DB_CONNECTION' => 'sqlite', 'DB_DATABASE' => ':memory:', 'DB_URL' => '', 'CACHE_STORE' => 'array', 'SESSION_DRIVER' => 'array', 'MAIL_MAILER' => 'array', 'BROADCAST_CONNECTION' => 'null'] as $key => $value) {
    putenv($key.'='.$value); $_ENV[$key] = $value; $_SERVER[$key] = $value;
}
require __DIR__.'/../../../vendor/autoload.php';
$app = require __DIR__.'/../../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
config(['database.default' => 'sqlite', 'database.connections.sqlite.database' => ':memory:', 'database.connections.sqlite.url' => null, 'session.driver' => 'array', 'cache.default' => 'array']);
Illuminate\Support\Facades\DB::purge();
Illuminate\Support\Facades\Artisan::call('migrate', ['--force' => true]);
Illuminate\Support\Facades\URL::forceRootUrl('http://settings.test');
$app['session']->start();
Illuminate\Support\Facades\View::share('errors', new Illuminate\Support\ViewErrorBag); 
$admin = App\Models\User::factory()->create(['role' => App\Models\User::ROLE_ADMIN, 'firstName' => 'Sample', 'lastName' => 'Administrator']);
Illuminate\Support\Facades\Auth::setUser($admin);
$settings = app(App\Services\Settings::class);
$settings->putMany(['general.timezone' => 'UTC', 'general.date_format' => 'Y-m-d']);
foreach (['general', 'notifications', 'security', 'permissions', 'violations', 'data'] as $tab) {
    $request = Illuminate\Http\Request::create('http://settings.test/dashboard/settings', 'GET', ['tab' => $tab]);
    $request->setUserResolver(fn () => $admin);
    $app->instance('request', $request);
    $html = app(App\Http\Controllers\SettingsController::class)->index($request, $settings)->render();
    file_put_contents(__DIR__.'/settings-removal-'.$tab.'.html', $html);
}
echo "Rendered remaining and legacy settings tabs with fictional SQLite-memory data.\n";

