const {chromium}=require('C:/Users/Tamano/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const fs=require('fs'),path=require('path');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));let role='admin';const checks=[];
 await page.route('**/*',async route=>{
  const url=new URL(route.request().url());
  if(url.pathname==='/area-assignments')return route.fulfill({contentType:'text/html',body:fs.readFileSync('storage/app/private/area-ui-'+role+'.html','utf8')});
  if(url.pathname==='/dashboard/search'){const key=(url.searchParams.get('q')||'').toLowerCase();const file='storage/app/private/dashboard-search-'+role+'-'+key+'.json';return route.fulfill({contentType:'application/json',body:fs.existsSync(file)?fs.readFileSync(file,'utf8'):'{"results":[]}'});}
  if(/^\/(css|js|images|build)\//.test(url.pathname)&&!url.pathname.includes('..')){const file=path.join('public',decodeURIComponent(url.pathname));if(fs.existsSync(file))return route.fulfill({contentType:url.pathname.endsWith('.css')?'text/css':url.pathname.endsWith('.js')?'application/javascript':url.pathname.endsWith('.ico')?'image/x-icon':'image/jpeg',body:fs.readFileSync(file)});}
  return route.fulfill({status:404,body:''});
 });
 for(const width of [1440,820,390,320]){await page.setViewportSize({width,height:900});for(role of ['admin','supervisor']){
  await page.goto('http://area.test/area-assignments');const input=page.getByRole('searchbox',{name:'Search dashboard',exact:true});
  if(!await input.isVisible())throw new Error('Search hidden '+width);
  for(const [query,kind]of [['area','Pages'],['Ana','Staff'],['Mara',role==='admin'?'Violation records':null],['nomatch',null]]){
   await input.fill(query);await input.press('Enter');
   await page.waitForFunction(()=>{const t=document.querySelector('[data-dashboard-search-status]').textContent;return /found|could not load/.test(t)});
   const panel=page.locator('#dashboardSearchResults');if(!await panel.isVisible())throw new Error('No search panel');
   const text=await panel.textContent();if(kind&&!text.includes(kind))throw new Error('Missing '+kind+' '+role+' '+query);
   if(!kind&&!text.includes('No results found'))throw new Error('No-results missing');
   const box=await panel.boundingBox();if(box.x<0||box.x+box.width>width+1||box.y+box.height>900)throw new Error('Panel escaped viewport');
   if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw new Error('Page overflow');
   if(query==='area'){
    await input.press('ArrowDown');if(!await panel.locator('a').first().evaluate(el=>el===document.activeElement))throw new Error('ArrowDown focus');
    await page.keyboard.press('Escape');if(await panel.isVisible()||!await input.evaluate(el=>el===document.activeElement))throw new Error('Escape focus '+JSON.stringify(await page.evaluate(()=>({active:document.activeElement.outerHTML,panelHidden:document.querySelector('#dashboardSearchResults').hidden,style:getComputedStyle(document.querySelector('#dashboardSearchResults')).display}))));
    await input.press('Enter');await page.waitForFunction(()=>/found/.test(document.querySelector('[data-dashboard-search-status]').textContent));
   }
   if(query==='Ana'&&[1440,390].includes(width))await page.screenshot({path:'storage/app/private/dashboard-search-'+role+'-'+width+'.png',fullPage:true});
   await page.getByRole('button',{name:'Clear dashboard search',exact:true}).click();if(await input.inputValue()!==''||await panel.isVisible())throw new Error('Clear failed');
   checks.push({width,role,query,kind});
  }
 }}
 role='admin';await page.goto('http://area.test/area-assignments');const input=page.getByRole('searchbox',{name:'Search dashboard',exact:true});await input.fill('area');await input.press('Enter');await page.waitForFunction(()=>document.querySelector('[data-dashboard-search-results] a'));await input.press('ArrowDown');await page.keyboard.press('Enter');await page.waitForURL('http://area.test/area-assignments');
 if(errors.length)throw new Error(errors.join('\n'));await page.goto('http://area.test/area-assignments');
 const imeAllowed=await page.locator('#dashboardSearchInput').evaluate(input=>{input.focus();input.dispatchEvent(new CompositionEvent('compositionstart',{bubbles:true}));input.value='Mara';input.dispatchEvent(new InputEvent('input',{bubbles:true,isComposing:true}));return input.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',isComposing:true,bubbles:true,cancelable:true}));});
 if(!imeAllowed)throw new Error('IME Enter default was blocked');await page.waitForTimeout(400);if(await page.locator('#dashboardSearchResults').isVisible())throw new Error('Search ran during composition');
 await page.locator('#dashboardSearchInput').evaluate(input=>input.dispatchEvent(new CompositionEvent('compositionend',{bubbles:true,data:'Mara'})));await page.waitForFunction(()=>document.querySelector('[data-dashboard-search-results]').textContent.includes('Mara Santos'));
 fs.writeFileSync('storage/app/private/dashboard-search-browser-checks.json',JSON.stringify({checks,errors},null,2));console.log('Passed '+checks.length+' search/role/viewport checks with real controller result fixtures; keyboard link navigation passed; no overflow or script errors.');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});


