const {chromium} = require('C:/Users/Tamano/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs = require('fs');
const path = require('path');
(async()=>{
 const browser = await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
 const page = await browser.newPage();
 const errors=[]; page.on('pageerror',e=>errors.push(e.message));
 await page.route('**/*',async route=>{
  const url=new URL(route.request().url());
  if(url.pathname==='/dashboard/settings') return route.fulfill({contentType:'text/html',body:fs.readFileSync('storage/app/private/settings-removal-'+(url.searchParams.get('tab')||'general')+'.html','utf8')});
  if(/^\/(css|js|images|build)\/[\w./-]+$/.test(url.pathname)&&!url.pathname.includes('..')){
   const file=path.join('public',url.pathname);
   if(fs.existsSync(file)) return route.fulfill({contentType:url.pathname.endsWith('.css')?'text/css':url.pathname.endsWith('.js')?'application/javascript':url.pathname.endsWith('.svg')?'image/svg+xml':url.pathname.endsWith('.png')?'image/png':'image/jpeg',body:fs.readFileSync(file)});
  }
  return route.fulfill({status:404,body:''});
 });
 const checks=[];
 for(const width of [1440,390]){
  await page.setViewportSize({width,height:1000});
  for(const tab of ['general','notifications','security','permissions','violations','data']){
   await page.goto('http://settings.test/dashboard/settings?tab='+tab);
   await page.waitForTimeout(250);
   const result=await page.evaluate(()=>({labels:[...document.querySelectorAll('.settings-tabs a')].map(a=>a.textContent.trim()),heading:document.querySelector('.settings-heading h2').textContent,section:document.querySelector('[name=section]').value,overflow:document.documentElement.scrollWidth>innerWidth,timezone:document.querySelector('[name=timezone]')?.value,dateFormat:document.querySelector('[name=date_format]')?.value}));
   if(result.labels.join('|')!=='General|Notifications|Security') throw new Error('Unexpected settings tabs');
   if(result.overflow) throw new Error('Page overflows at '+width+' tab '+tab);
   if(['permissions','violations','data'].includes(tab)&&result.section!=='general') throw new Error('Old tab exposed');
   if(result.section==='general'&&(result.timezone!=='UTC'||result.dateFormat!=='Y-m-d')) throw new Error('Saved selection lost');
   await page.getByRole('button',{name:'Save '+result.heading,exact:true}).focus();
   if(!await page.getByRole('button',{name:'Save '+result.heading,exact:true}).evaluate(el=>el===document.activeElement)) throw new Error('Save button cannot focus');
   checks.push({width,tab,...result});
   if(['general','notifications','security'].includes(tab)) await page.screenshot({path:'storage/app/private/settings-removal-'+tab+'-'+width+'.png',fullPage:true});
  }
 }
 await browser.close();
 if(errors.length) throw new Error(errors.join('\n'));
 fs.writeFileSync('storage/app/private/settings-removal-browser-checks.json',JSON.stringify({checks,errors},null,2));
 console.log('Passed '+checks.length+' browser checks: remaining and legacy tabs, desktop/mobile, saved selects, focus, no page overflow or script errors.');
})().catch(e=>{console.error(e);process.exit(1)});
