const { chromium }=require('C:/Users/Tamano/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs'); const path=require('path');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
 const page=await browser.newPage(); const errors=[]; page.on('pageerror',e=>errors.push(e.message));
 await page.route('**/*',async route=>{
  const url=new URL(route.request().url());
  if(url.pathname==='/area-assignments') return route.fulfill({contentType:'text/html',body:fs.readFileSync('storage/app/private/area-ui-'+(url.searchParams.get('fixture')||'admin')+'.html','utf8')});
  if(/^\/(css|js|images|build)\//.test(url.pathname)&&!url.pathname.includes('..')){const file=path.join('public',decodeURIComponent(url.pathname));if(fs.existsSync(file))return route.fulfill({contentType:url.pathname.endsWith('.css')?'text/css':url.pathname.endsWith('.js')?'application/javascript':url.pathname.endsWith('.svg')?'image/svg+xml':url.pathname.endsWith('.png')?'image/png':'image/jpeg',body:fs.readFileSync(file)});}
  return route.fulfill({status:404,body:''});
 });
 const checks=[];
 for(const width of [1440,1024,768,390]){
  await page.setViewportSize({width,height:1000}); await page.goto('http://area.test/area-assignments'); await page.waitForTimeout(150);
  checks.push(await page.evaluate(()=>({width:innerWidth,overflow:document.documentElement.scrollWidth>innerWidth,toolbar:document.querySelector('.area-assignment-toolbar').getBoundingClientRect().toJSON(),head:document.querySelector('h1').getBoundingClientRect().toJSON(),tableWidth:document.querySelector('table').getBoundingClientRect().width,scroll:({client:document.querySelector('.table-scroll').clientWidth,scroll:document.querySelector('.table-scroll').scrollWidth,overflow:getComputedStyle(document.querySelector('.table-scroll')).overflowX,rect:document.querySelector('.table-scroll').getBoundingClientRect().toJSON()}),offenders:[...document.querySelectorAll('body *')].filter(el=>el.getBoundingClientRect().right>innerWidth+1&&!el.closest('.table-scroll')&&!el.closest('dialog')&&!el.closest('.sidebar')).slice(0,12).map(el=>({tag:el.tagName,class:el.className,right:el.getBoundingClientRect().right}))})));
  await page.screenshot({path:'storage/app/private/area-ui-'+(process.env.AREA_PHASE||'before')+'-'+width+'.png',fullPage:true});
  await page.getByRole('button',{name:'Add area',exact:true}).click(); await page.screenshot({path:'storage/app/private/area-ui-'+(process.env.AREA_PHASE||'before')+'-modal-'+width+'.png',fullPage:true}); await page.keyboard.press('Escape');
 }
 fs.writeFileSync('storage/app/private/area-ui-'+(process.env.AREA_PHASE||'before')+'-checks.json',JSON.stringify({checks,errors},null,2));
 console.log(JSON.stringify({checks,errors})); await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});


