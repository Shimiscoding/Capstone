const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { chromium } = require(path.join(process.env.USERPROFILE, '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));

(async () => {
  const root = path.resolve(__dirname, '../../..');
  let html = fs.readFileSync(path.join(__dirname, 'recent-tickets-preview.html'), 'utf8');
  html = html.replace(/<link rel="stylesheet"[^>]+>/, `<style>${fs.readFileSync(path.join(root, 'public/css/dashboard.css'), 'utf8')}</style>`);
  html = html.replace(/<script src="https:\/\/cdn\.jsdelivr[^>]+><\/script>/g, '');
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  const results = [];
  try {
    for (const width of [1440, 390]) {
      const page = await browser.newPage({ viewport: { width, height: 1000 } });
      await page.setContent(html, { waitUntil: 'domcontentloaded' });
      const panel = page.locator('.dashboard-panel').filter({ has: page.getByRole('heading', { name: 'Recently issued tickets' }) });
      assert.equal(await panel.locator('.recent-details strong').first().innerText(), 'Unregistered Vehicle, Illegal Parking, Disregarding Traffic Sign ...');
      assert.equal(await panel.locator('.recent-details strong').nth(1).innerText(), 'Unregistered Vehicle, Illegal Parking, Disregarding Traffic Sign');
      assert.equal(await panel.locator('.recent-details strong').nth(2).innerText(), 'Unregistered Vehicle');
      const geometry = await panel.locator('.recent-user').evaluateAll(rows => rows.map(row => {
        const details = row.querySelector('.recent-details');
        const date = row.querySelector('.recent-date');
        return { fits: details.scrollWidth <= details.clientWidth + 1, separated: details.getBoundingClientRect().right <= date.getBoundingClientRect().left };
      }));
      await panel.screenshot({ path: path.join(__dirname, `recent-tickets-${width}.png`) });
      assert.ok(geometry.every(row => row.fits && row.separated), JSON.stringify({width, geometry}));
      const review = panel.getByRole('link', { name: 'Review tickets' });
      await review.focus();
      assert.equal(await review.evaluate(el => el === document.activeElement), true);
      await panel.screenshot({ path: path.join(__dirname, `recent-tickets-${width}.png`) });
      results.push({ width, threeViolationLimit: true, correctEllipsis: true, textFits: true, statusSeparated: true, reviewKeyboardFocus: true });
      await page.close();
    }
    fs.writeFileSync(path.join(__dirname, 'recent-tickets-browser-results.json'), JSON.stringify(results, null, 2));
    console.log(JSON.stringify(results));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });
