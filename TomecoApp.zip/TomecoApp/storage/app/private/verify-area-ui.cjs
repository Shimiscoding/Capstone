const {chromium}=require('C:/Users/Tamano/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs'),path=require('path');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
 const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));let fixture='admin';
 await page.route('**/*',async route=>{
  const url=new URL(route.request().url());
  if(url.pathname==='/area-assignments')return route.fulfill({contentType:'text/html',body:fs.readFileSync('storage/app/private/area-ui-'+fixture+'.html','utf8')});
  if(/^\/(css|js|images|build)\//.test(url.pathname)&&!url.pathname.includes('..')){const file=path.join('public',decodeURIComponent(url.pathname));if(fs.existsSync(file))return route.fulfill({contentType:url.pathname.endsWith('.css')?'text/css':url.pathname.endsWith('.js')?'application/javascript':url.pathname.endsWith('.svg')?'image/svg+xml':url.pathname.endsWith('.png')?'image/png':url.pathname.endsWith('.ico')?'image/x-icon':'image/jpeg',body:fs.readFileSync(file)});}
  return route.fulfill({status:404,body:''});
 });
 const results=[];
 for(const width of [1440,1024,768,390]){
  await page.setViewportSize({width,height:1000});
  for(fixture of ['admin','supervisor','filtered','empty','long','pages','page2','modal-error','row-error','success']){
   await page.goto('http://area.test/area-assignments?fixture='+fixture);await page.waitForTimeout(100);
   const result=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth>innerWidth,tableScroll:document.querySelector('.table-scroll').scrollWidth>document.querySelector('.table-scroll').clientWidth,rows:document.querySelectorAll('.area-assignment-form').length,dialogOpen:document.querySelector('#addAreaModal').open,invalidRows:document.querySelectorAll('.area-assignment-form [aria-invalid=true]').length}));
   if(result.overflow)throw new Error('Page overflow '+width+' '+fixture);
   if(fixture==='modal-error'){
    if(!result.dialogOpen||await page.locator('#newAreaName').inputValue()!=='Abucay'||!await page.locator('#newAreaError').isVisible())throw new Error('Modal error not restored');
    const box=await page.locator('#addAreaModal').boundingBox();if(box.x<0||box.x+box.width>width||box.y<0||box.y+box.height>1000)throw new Error('Dialog outside viewport');
    await page.keyboard.press('Escape');
   }
   if(fixture==='row-error'){
    if(result.invalidRows!==1)throw new Error('Row error affected wrong rows');
    if(await page.locator('.area-assignment-form [aria-invalid=true]').inputValue()!=='Palo')throw new Error('Failed row value lost');
    if(await page.locator('select[name=area]').evaluateAll(els=>els.filter(el=>el.value==='Palo').length)<1)throw new Error('Area values missing');
   }
   if(fixture==='admin'){
    await page.getByRole('button',{name:'Add area',exact:true}).click();
    if(!await page.locator('#newAreaName').evaluate(el=>el===document.activeElement))throw new Error('Modal input not focused');
    await page.locator('#addAreaForm').getByRole('button',{name:'Add area',exact:true}).click();
    if(!await page.locator('#newAreaError').isVisible())throw new Error('Blank name not validated');
    await page.locator('#newAreaName').fill('New area');if(await page.locator('#newAreaError').isVisible())throw new Error('Name error not cleared');
    await page.screenshot({path:'storage/app/private/area-ui-final-modal-'+width+'.png'});
    await page.keyboard.press('Escape');if(!await page.locator('#openAddArea').evaluate(el=>el===document.activeElement))throw new Error('Modal focus not restored');
    const scroll=page.locator('.table-scroll');if(result.tableScroll){await scroll.focus();await page.keyboard.press('ArrowRight');await page.waitForTimeout(150);if(await scroll.evaluate(el=>el.scrollLeft)<=0)throw new Error('Keyboard scrolling failed');await scroll.evaluate(el=>el.scrollLeft=0);}
   }
   if(['admin','supervisor','empty','long','modal-error','row-error'].includes(fixture)&&[1440,390].includes(width))await page.screenshot({path:'storage/app/private/area-ui-final-'+fixture+'-'+width+'.png',fullPage:true});
   results.push({width,fixture,...result});
  }
 }
 fixture='filtered';await page.goto('http://area.test/area-assignments?fixture=filtered');
 await page.locator('form[role=search]').evaluate(form=>form.addEventListener('submit',event=>event.preventDefault()));
 await page.getByRole('button',{name:'Clear enforcer search'}).click();
 if(await page.locator('#areaOfficerSearch').inputValue()!==''||await page.locator('form[role=search] select[name=area]').inputValue()!=='Abucay')throw new Error('Search clear lost area filter');
 if(errors.length)throw new Error(errors.join('\n'));
 fs.writeFileSync('storage/app/private/area-ui-final-browser-checks.json',JSON.stringify({results,errors},null,2));
 console.log('Passed '+results.length+' viewport/state checks plus modal validation/focus, keyboard table scrolling, and filtered search clear; no overflow or script errors.');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
