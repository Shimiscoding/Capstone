const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { chromium } = require(path.join(process.env.USERPROFILE, '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));

(async () => {
  const root = path.resolve(__dirname, '../../..');
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  const results = [];
  try {
    for (const variant of ['officer', 'supervisor', 'admin', 'long', 'create-comparison']) {
      for (const width of [1440, 390]) {
        const page = await browser.newPage({ viewport: { width, height: 1000 }, reducedMotion: 'reduce' });
        const errors = [];
        page.on('pageerror', error => errors.push(error.message));
        let html = fs.readFileSync(path.join(__dirname, `staff-profile-${variant}.html`), 'utf8');
        html = html.replace(/<link rel="stylesheet"[^>]+href="[^"]*\/css\/([^"?]+)[^"]*"[^>]*>/g, (link, file) => `<style>${fs.readFileSync(path.join(root, 'public/css', file), 'utf8')}</style>`);
        await page.setContent(html, { waitUntil: 'domcontentloaded' });
        if (variant !== 'create-comparison') {
          const card = page.locator('.staff-profile-card');
          assert.equal(await card.locator('.staff-profile-section').count(), 3);
          const geometry = await page.locator('.staff-profile-details dd').evaluateAll(elements => elements.map(el => ({ fits: el.scrollWidth <= el.clientWidth + 1 })));
          assert.ok(geometry.every(el => el.fits), `${variant} ${width}: detail overflow`);
          const bounds = await card.boundingBox();
          assert.ok(bounds.x >= 0 && bounds.x + bounds.width <= width + 1, `${variant} ${width}: card overflow`);
          assert.equal(await page.locator('.staff-profile-avatar').evaluate(el => getComputedStyle(el).borderRadius), '50%');
          assert.equal(await page.locator('.staff-profile-details').first().evaluate(el => getComputedStyle(el).gridTemplateColumns.split(' ').length), width === 390 ? 1 : 2);
          const edit = page.getByRole('link', { name: /^Edit (enforcer|supervisor|admin)$/i });
          assert.ok((await edit.getAttribute('href')).includes('/edit'));
          await edit.focus();
          assert.equal(await edit.evaluate(el => document.activeElement === el), true);
          if (variant === 'long') assert.ok(await card.getByText('Unassigned', { exact: true }).count() >= 2);
          if (variant === 'supervisor' || variant === 'admin') assert.equal(await card.getByText('Supervisor', { exact: true }).filter({ hasNot: page.locator('.role-badge') }).count(), variant === 'supervisor' ? 1 : 0);
          await page.locator('.workspace').screenshot({ path: path.join(__dirname, `staff-profile-${variant}-${width}.png`) });
          const photo = card.locator('.staff-profile-avatar img');
          if (await photo.count()) assert.ok(await photo.evaluate(el => el.complete && el.naturalWidth > 0));
          const lastDetail = card.locator('.staff-profile-details dd').last();
          await lastDetail.scrollIntoViewIfNeeded();
          const lastBounds = await lastDetail.boundingBox();
          assert.ok(lastBounds.y >= 0 && lastBounds.y + lastBounds.height <= 1001, 'Bottom details must remain reachable');
          await card.locator('.staff-profile-section').last().screenshot({ path: path.join(__dirname, `staff-profile-${variant}-${width}-account.png`) });
          results.push({ variant, width, sectionCount: 3, readableDetails: true, roundAvatar: true, responsiveColumns: true, editKeyboardFocus: true, bottomDetailsReachable: true, photoLoaded: await photo.count() > 0, pageErrors: errors });
        } else {
          await page.locator('.workspace').screenshot({ path: path.join(__dirname, `staff-profile-${variant}-${width}.png`) });
          results.push({ variant, width, siblingRendered: true, pageErrors: errors });
        }
        assert.deepEqual(errors, []);
        await page.close();
      }
    }
    fs.writeFileSync(path.join(__dirname, 'staff-profile-browser-results.json'), JSON.stringify(results, null, 2));
    console.log(JSON.stringify(results));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });
