const {chromium} = require('C:/Users/Tamano/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs = require('fs');
(async () => {
 const browser = await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
 const page = await browser.newPage({viewport:{width:1440,height:1040}, deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 // Serve rendered fixtures and their real application assets entirely from disk.
 await page.route('**/*', async route => {
   const url=new URL(route.request().url());
   if(url.pathname==='/dashboard') {
    const file=url.searchParams.get('fixture')==='empty'?'supervisor-home-empty.html':url.searchParams.get('fixture')==='long'?'supervisor-home-long.html':url.searchParams.get('page')==='2'?'supervisor-home-page2.html':'supervisor-home-preview.html';
    return route.fulfill({contentType:'text/html',body:fs.readFileSync('storage/app/private/'+file,'utf8')});
   }
   if(/^\/(css|images)\/[\w./-]+$/.test(url.pathname) && !url.pathname.includes('..')){
    const file='public'+url.pathname;
    if(fs.existsSync(file))return route.fulfill({contentType:url.pathname.endsWith('.css')?'text/css':url.pathname.endsWith('.png')?'image/png':'image/jpeg',body:fs.readFileSync(file)});
   }
   return route.fulfill({status:404,body:''});
 });
 const checks=[];
 for(const width of [1440,1024,768,390]){
   await page.setViewportSize({width,height:1040});await page.goto('http://127.0.0.1:8799/dashboard');
   await page.screenshot({path:`storage/app/private/supervisor-home-${width}.png`,fullPage:true});
   checks.push(await page.evaluate(()=>({width:innerWidth,overflow:document.documentElement.scrollWidth>innerWidth,stats:document.querySelectorAll('.supervisor-home-stat').length,rosterRows:document.querySelectorAll('.supervisor-roster-table tbody tr').length,tableScrollable:document.querySelector('.supervisor-roster .table-scroll').scrollWidth>document.querySelector('.supervisor-roster .table-scroll').clientWidth,cssLoaded:getComputedStyle(document.querySelector('.supervisor-home-stats')).display==='grid'})));
 }
 await page.getByRole('link',{name:'Next',exact:true}).click();
 await page.getByText('Page 2 of 2').waitFor();
 await page.getByRole('link',{name:'Previous',exact:true}).click();
 await page.locator('.supervisor-home-stat').first().focus();await page.keyboard.press('Tab');
 checks.push({keyboardFocus:await page.evaluate(()=>({tag:document.activeElement.tagName,outline:getComputedStyle(document.activeElement).outlineStyle}))});
 await page.setViewportSize({width:390,height:844});
 for(const fixture of ['empty','long']){
  await page.goto('http://127.0.0.1:8799/dashboard?fixture='+fixture);
  await page.screenshot({path:`storage/app/private/supervisor-home-${fixture}-390.png`,fullPage:true});
  checks.push({fixture,...await page.evaluate(()=>({overflow:document.documentElement.scrollWidth>innerWidth,emptyMessage:document.body.innerText.includes('No enforcers assigned yet')}))});
 }
 await page.emulateMedia({reducedMotion:'reduce'});await page.goto('http://127.0.0.1:8799/dashboard');
 const scroll=page.locator('.supervisor-roster .table-scroll');await scroll.focus();await page.keyboard.press('ArrowRight');await page.waitForTimeout(150);
 checks.push({keyboardTableScroll:await scroll.evaluate(e=>e.scrollLeft),errors});
 console.log(JSON.stringify(checks,null,2));
 fs.writeFileSync('storage/app/private/supervisor-home-browser-checks.json',JSON.stringify(checks,null,2));
 await browser.close();
})();



