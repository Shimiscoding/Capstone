<?php if (isset($component)) { $__componentOriginal03b6c44728e100ba2673d02906458342 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal03b6c44728e100ba2673d02906458342 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-layout','data' => ['title' => 'Admin sign up','page' => 'register']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Admin sign up','page' => 'register']); ?>
    <p class="auth-page-label">Sign up</p>
    <h1 id="auth-heading" class="auth-title">Create your account.</h1>
    <p class="auth-description">Get started with an administrator account for TOMECO.</p>

    <form method="POST" action="<?php echo e(route('register.store')); ?>" class="auth-form" data-auth-form novalidate>
        <?php echo csrf_field(); ?>
        <div class="auth-fields-grid">
            <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'firstName','label' => 'First name','autocomplete' => 'given-name','placeholder' => 'First name','required' => true,'autofocus' => true,'maxlength' => '100']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'firstName','label' => 'First name','autocomplete' => 'given-name','placeholder' => 'First name','required' => true,'autofocus' => true,'maxlength' => '100']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'middleName','label' => 'Middle name','autocomplete' => 'additional-name','placeholder' => 'Middle name','optional' => true,'maxlength' => '100']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'middleName','label' => 'Middle name','autocomplete' => 'additional-name','placeholder' => 'Middle name','optional' => true,'maxlength' => '100']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'lastName','label' => 'Last name','autocomplete' => 'family-name','placeholder' => 'Last name','required' => true,'maxlength' => '100']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'lastName','label' => 'Last name','autocomplete' => 'family-name','placeholder' => 'Last name','required' => true,'maxlength' => '100']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'nameExtension','label' => 'Extension','placeholder' => 'Jr., Sr., III','optional' => true,'maxlength' => '20']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'nameExtension','label' => 'Extension','placeholder' => 'Jr., Sr., III','optional' => true,'maxlength' => '20']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'email','label' => 'Email','type' => 'email','autocomplete' => 'email','placeholder' => 'you@example.com','required' => true,'maxlength' => '255']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email','label' => 'Email','type' => 'email','autocomplete' => 'email','placeholder' => 'you@example.com','required' => true,'maxlength' => '255']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'phoneNumber','label' => 'Phone number','type' => 'tel','autocomplete' => 'tel','placeholder' => '09XXXXXXXXX','inputmode' => 'numeric','pattern' => '09[0-9]{9}','minlength' => '11','maxlength' => '11','required' => true,'hint' => '11 digits, starting with 09.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phoneNumber','label' => 'Phone number','type' => 'tel','autocomplete' => 'tel','placeholder' => '09XXXXXXXXX','inputmode' => 'numeric','pattern' => '09[0-9]{9}','minlength' => '11','maxlength' => '11','required' => true,'hint' => '11 digits, starting with 09.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'password','label' => 'Password','type' => 'password','autocomplete' => 'new-password','placeholder' => 'Create a password','required' => true,'minlength' => ''.e($passwordMinLength).'','hint' => 'At least '.e($passwordMinLength).' characters.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password','label' => 'Password','type' => 'password','autocomplete' => 'new-password','placeholder' => 'Create a password','required' => true,'minlength' => ''.e($passwordMinLength).'','hint' => 'At least '.e($passwordMinLength).' characters.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'password_confirmation','label' => 'Confirm password','type' => 'password','autocomplete' => 'new-password','placeholder' => 'Repeat your password','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password_confirmation','label' => 'Confirm password','type' => 'password','autocomplete' => 'new-password','placeholder' => 'Repeat your password','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
        </div>
        <p class="auth-form-status sr-only" role="status" aria-live="polite"></p>
        <button type="submit" class="auth-button" data-busy-label="Creating account…">Create admin account <span aria-hidden="true">→</span></button>
    </form>
    <p class="auth-note">Already have an account? <a href="<?php echo e(route('login')); ?>" class="auth-link">Log in</a></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal03b6c44728e100ba2673d02906458342)): ?>
<?php $attributes = $__attributesOriginal03b6c44728e100ba2673d02906458342; ?>
<?php unset($__attributesOriginal03b6c44728e100ba2673d02906458342); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal03b6c44728e100ba2673d02906458342)): ?>
<?php $component = $__componentOriginal03b6c44728e100ba2673d02906458342; ?>
<?php unset($__componentOriginal03b6c44728e100ba2673d02906458342); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\auth\register.blade.php ENDPATH**/ ?>