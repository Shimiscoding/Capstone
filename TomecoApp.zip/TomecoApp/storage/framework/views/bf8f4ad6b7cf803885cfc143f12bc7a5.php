

<?php $__env->startSection('title', $sectionLabel . ' Details'); ?>
<?php $__env->startSection('activePage', 'users-' . $section); ?>
<?php $__env->startSection('workspaceClass', 'user-editor-workspace staff-profile-workspace'); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/user-editor.css')); ?>?v=<?php echo e(filemtime(public_path('css/user-editor.css'))); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $sectionRoute = match ($section) {
            'supervisors' => route('dashboard.users.supervisors'),
            'admins' => route('dashboard.users.admins'),
            default => route('dashboard.users.enforcers'),
        };
    ?>
    <div class="page-head users-page-head">
        <div>
            <p class="eyebrow"><?php echo e($sectionLabel); ?> management</p>
            <h1><?php echo e($staffUser->fullName); ?></h1>
            <p class="page-description"><?php echo e($sectionLabel); ?> profile, contact, and location details.</p>
        </div>
        <div class="users-page-actions"><a class="page-button detail-back-button"
                href="<?php echo e($sectionRoute); ?>"
                aria-label="Back to <?php echo e($section); ?>" title="Back to <?php echo e($section); ?>">&larr;</a><a
                class="add-user-button" href="<?php echo e(route('dashboard.users.edit', ['user' => $staffUser, 'from' => $section])); ?>">Edit
                <?php echo e(strtolower($sectionLabel)); ?></a></div>
    </div>
    <section class="create-user-card staff-profile-card" aria-label="<?php echo e($sectionLabel); ?> profile">
        <div class="user-editor-photo-header">
            <div class="staff-profile-identity">
                <?php if (isset($component)) { $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-avatar','data' => ['user' => $staffUser,'class' => 'staff-profile-avatar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($staffUser),'class' => 'staff-profile-avatar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $attributes = $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $component = $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?>
                <div class="staff-profile-badges">
                    <span class="role-badge role-<?php echo e($staffUser->role); ?>"><?php echo e($sectionLabel); ?></span>
                    <span class="status-badge"><i></i> Registered</span>
                </div>
            </div>
            <div class="user-editor-photo-copy">
                <span class="user-editor-role"><?php echo e($sectionLabel); ?> account</span>
                <h2><?php echo e($staffUser->fullName); ?></h2>
                <p>Profile, contact, and location details.</p>
            </div>
        </div>
        <div class="staff-profile-body">
            <section class="staff-profile-section" aria-labelledby="staffPersonalHeading">
                <div class="form-section-heading">
                    <div><h2 id="staffPersonalHeading">Personal information</h2><p>Name and address recorded for this account.</p></div>
                </div>
                <dl class="staff-profile-details">
                    <div><dt>First name</dt><dd><?php echo e($staffUser->firstName ?: 'Not recorded'); ?></dd></div>
                    <div><dt>Middle name</dt><dd><?php echo e($staffUser->middleName ?: 'Not recorded'); ?></dd></div>
                    <div><dt>Last name</dt><dd><?php echo e($staffUser->lastName ?: 'Not recorded'); ?></dd></div>
                    <div><dt>Name extension</dt><dd><?php echo e($staffUser->nameExtension ?: 'None'); ?></dd></div>
                    <div class="staff-profile-wide"><dt>Address</dt><dd><?php echo e($staffUser->address ?: 'Not recorded'); ?></dd></div>
                </dl>
            </section>
            <section class="staff-profile-section" aria-labelledby="staffContactHeading">
                <div class="form-section-heading">
                    <div><h2 id="staffContactHeading">Contact information</h2><p>Phone number and email address.</p></div>
                </div>
                <dl class="staff-profile-details">
                    <div><dt>Phone number</dt><dd><?php echo e($staffUser->phoneNumber ?: 'Not recorded'); ?></dd></div>
                    <div><dt>Email</dt><dd><?php echo e($staffUser->email ?: 'Not recorded'); ?></dd></div>
                </dl>
            </section>
            <section class="staff-profile-section" aria-labelledby="staffAccountHeading">
                <div class="form-section-heading">
                    <div><h2 id="staffAccountHeading">Account details</h2><p><?php echo e($staffUser->isOfficer() ? 'Account registration and current assignment.' : 'Account registration details.'); ?></p></div>
                </div>
                <dl class="staff-profile-details">
                    <div><dt>Username</dt><dd><?php echo e($staffUser->username ? '@' . $staffUser->username : 'Not recorded'); ?></dd></div>
                    <div><dt>Joined</dt><dd><?php echo e($staffUser->created_at?->format('F j, Y') ?? 'Not recorded'); ?></dd></div>
                    <?php if($staffUser->isOfficer()): ?>
                        <div><dt>Supervisor</dt><dd>
                            <?php if($staffUser->supervisor): ?>
                                <a class="user-name-link" href="<?php echo e(route('dashboard.users.supervisors.show', $staffUser->supervisor)); ?>"><?php echo e($staffUser->supervisor->fullName); ?></a>
                            <?php else: ?>
                                Unassigned
                            <?php endif; ?>
                        </dd></div>
                        <div><dt>Area</dt><dd><?php echo e($staffUser->area ?: 'Unassigned'); ?></dd></div>
                    <?php endif; ?>
                </dl>
            </section>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\dashboard\users\staff-show.blade.php ENDPATH**/ ?>