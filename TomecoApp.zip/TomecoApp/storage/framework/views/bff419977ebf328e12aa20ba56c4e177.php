<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name', 'label', 'type' => 'text', 'hint' => null, 'optional' => false, 'value' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name', 'label', 'type' => 'text', 'hint' => null, 'optional' => false, 'value' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="auth-field">
    <label for="<?php echo e($name); ?>" class="auth-label"><?php echo e($label); ?> <?php if($optional): ?><small>(optional)</small><?php endif; ?></label>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['password-field' => $type === 'password']); ?>">
        <input id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" type="<?php echo e($type); ?>"
            <?php if($type !== 'password'): ?> value="<?php echo e(old($name, $value ?? ($name === 'login' ? old('email') : ''))); ?>" <?php endif; ?>
            aria-invalid="<?php echo e($errors->has($name) ? 'true' : 'false'); ?>"
            aria-describedby="<?php echo e($name); ?>-error<?php echo e($hint ? ' '.$name.'-hint' : ''); ?>"
            <?php echo e($attributes->class(['auth-input'])); ?>>
        <?php if($type === 'password'): ?>
            <button type="button" class="password-toggle" aria-controls="<?php echo e($name); ?>" aria-label="Show <?php echo e(strtolower($label)); ?>"
                aria-pressed="false" data-password-toggle title="Show <?php echo e(strtolower($label)); ?>">
                <svg class="eye-open" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>
                <svg class="eye-closed" viewBox="0 0 24 24" aria-hidden="true" hidden><path d="m3 3 18 18M10.6 6.2A12 12 0 0 1 12 6c6.5 0 10 6 10 6a18 18 0 0 1-3 3.7M6.6 6.6C3.6 8.4 2 12 2 12s3.5 6 10 6c1.5 0 2.8-.3 4-.8M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>
            </button>
        <?php endif; ?>
    </div>
    <?php if($hint): ?><p id="<?php echo e($name); ?>-hint" class="auth-field-hint"><?php echo e($hint); ?></p><?php endif; ?>
    <p id="<?php echo e($name); ?>-error" class="auth-error" <?php if(!$errors->has($name)): ?> hidden <?php endif; ?>><?php echo e($errors->first($name)); ?></p>
</div>
<?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\components\auth-field.blade.php ENDPATH**/ ?>