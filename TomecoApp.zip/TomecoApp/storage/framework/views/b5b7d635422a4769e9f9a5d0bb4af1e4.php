<?php if (isset($component)) { $__componentOriginal03b6c44728e100ba2673d02906458342 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal03b6c44728e100ba2673d02906458342 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-layout','data' => ['title' => 'Forgot password','page' => 'forgot-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Forgot password','page' => 'forgot-password']); ?>
    <p class="auth-page-label">Password recovery</p>
    <h1 id="auth-heading" class="auth-title">Forgot your password?</h1>
    <p class="auth-description">Enter your registered email address and we'll send you a password reset link.</p>

    <?php if(session('status')): ?>
        <p class="auth-status" role="status"><?php echo e(session('status')); ?></p>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('password.email')); ?>" class="auth-form" data-auth-form novalidate>
        <?php echo csrf_field(); ?>
        <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'email','label' => 'Email','type' => 'email','autocomplete' => 'email','placeholder' => 'you@example.com','required' => true,'autofocus' => true,'maxlength' => '255']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email','label' => 'Email','type' => 'email','autocomplete' => 'email','placeholder' => 'you@example.com','required' => true,'autofocus' => true,'maxlength' => '255']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
        <p class="auth-form-status sr-only" role="status" aria-live="polite"></p>
        <button type="submit" class="auth-button" data-busy-label="Sending reset link…">Email password reset link</button>
    </form>

    <p class="auth-note"><a href="<?php echo e(route('login')); ?>" class="auth-link">Back to login</a></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal03b6c44728e100ba2673d02906458342)): ?>
<?php $attributes = $__attributesOriginal03b6c44728e100ba2673d02906458342; ?>
<?php unset($__attributesOriginal03b6c44728e100ba2673d02906458342); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal03b6c44728e100ba2673d02906458342)): ?>
<?php $component = $__componentOriginal03b6c44728e100ba2673d02906458342; ?>
<?php unset($__componentOriginal03b6c44728e100ba2673d02906458342); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\auth\forgot-password.blade.php ENDPATH**/ ?>