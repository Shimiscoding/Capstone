

<?php $__env->startSection('title', 'Enforcer Attendance'); ?>
<?php $__env->startSection('activePage', 'enforcer-attendance'); ?>
<?php $__env->startSection('workspaceClass', 'workspace-full-width'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head users-page-head">
        <div class="users-heading-copy">
            <span class="sr-only">Enforcer Attendance</span>
            <h1><span class="management-subject">Enforcer</span> attendance <span class="users-heading-count"><?php echo e(number_format($enforcers->total())); ?></span></h1>
            <p class="page-description">Select an assigned enforcer to review their Time In and Time Out records.</p>
        </div>
    </div>

    <form class="user-table-filters users-reference-toolbar" method="GET" action="<?php echo e(route('supervisor.enforcers.attendance.index')); ?>" role="search">
        <div class="users-toolbar-main"><div class="users-toolbar-actions">
            <label class="toolbar-search"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="8.5" cy="8.5" r="5"/><path d="m12.2 12.2 4 4"/></svg><span class="sr-only">Search enforcers</span><input type="search" name="search" value="<?php echo e($search); ?>" placeholder="Search"></label>
            <label class="toolbar-customize"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="m10 2 6.5 3.8v7.5L10 18l-6.5-4.7V5.8z"/><circle cx="10" cy="10" r="2.3"/></svg><span class="sr-only">Sort enforcers</span><select name="sort" onchange="this.form.submit()"><option value="latest" <?php if($sort === 'latest'): echo 'selected'; endif; ?>>Customize</option><option value="oldest" <?php if($sort === 'oldest'): echo 'selected'; endif; ?>>Oldest first</option><option value="name_asc" <?php if($sort === 'name_asc'): echo 'selected'; endif; ?>>Name A&ndash;Z</option><option value="name_desc" <?php if($sort === 'name_desc'): echo 'selected'; endif; ?>>Name Z&ndash;A</option></select></label>
            <button class="toolbar-outline-button" type="button">Export</button>
        </div></div>
    </form>

    <section class="table-card" aria-live="polite">
        <div class="table-scroll">
            <table class="users-table attendance-table">
                <thead><tr>
                    <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="7" r="3"/><path d="M4 17c.6-4 2.6-6 6-6s5.4 2 6 6"/></svg>Full name</span></th>
                    <th>Attendance records</th>
                    <th>Latest Time In</th>
                    <th>Actions</th>
                </tr></thead>
                <tbody>
                <?php $__empty_2 = true; $__currentLoopData = $enforcers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enforcer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <?php
                        $enforcerName = $enforcer->fullName ?: 'Unnamed enforcer';
                        $initials = collect(explode(' ', $enforcerName))->filter()->map(fn($part) => strtoupper(substr($part, 0, 1)))->take(2)->join('');
                    ?>
                    <tr>
                        <td><div class="user-cell"><?php if (isset($component)) { $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-avatar','data' => ['user' => $enforcer]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($enforcer)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $attributes = $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $component = $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?><span><strong><a class="user-name-link" href="<?php echo e(route('supervisor.enforcers.attendance', $enforcer)); ?>"><?php echo e($enforcerName); ?></a></strong><small><?php echo e($enforcer->username ? '@'.$enforcer->username : $enforcer->email); ?></small></span></div></td>
                        <td><?php echo e(number_format($enforcer->enforcer_attendances_count)); ?></td>
                        <td><?php echo e($enforcer->enforcer_attendances_max_time_in ? \Illuminate\Support\Carbon::parse($enforcer->enforcer_attendances_max_time_in)->format('M d, Y h:i A') : '—'); ?></td>
                        <td><div class="user-row-actions"><a class="user-action action-edit" href="<?php echo e(route('supervisor.enforcers.attendance', $enforcer)); ?>">View details</a></div></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                    <tr><td colspan="4" class="empty-state"><strong><?php echo e($search !== '' ? 'No enforcers found' : 'No assigned enforcers'); ?></strong><span><?php echo e($search !== '' ? 'Try a different name.' : 'Add an enforcer from My Team to view attendance.'); ?></span></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="table-footer"><span>Showing <?php echo e($enforcers->firstItem() ?? 0); ?>&ndash;<?php echo e($enforcers->lastItem() ?? 0); ?> of <?php echo e($enforcers->total()); ?></span><div class="pagination-actions"><?php if($enforcers->onFirstPage()): ?><span class="page-button is-disabled" aria-disabled="true">Previous</span><?php else: ?><a class="page-button" href="<?php echo e($enforcers->previousPageUrl()); ?>">Previous</a><?php endif; ?> <?php if($enforcers->hasMorePages()): ?><a class="page-button" href="<?php echo e($enforcers->nextPageUrl()); ?>">Next</a><?php else: ?><span class="page-button is-disabled" aria-disabled="true">Next</span><?php endif; ?></div></div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.supervisor-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\supervisor\enforcer-attendance.blade.php ENDPATH**/ ?>