<?php if (! $__env->hasRenderedOnce('37676305-b277-48a6-bbaf-ca1d4a54257a')): $__env->markAsRenderedOnce('37676305-b277-48a6-bbaf-ca1d4a54257a'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard-search.css')); ?>?v=<?php echo e(filemtime(public_path('css/dashboard-search.css'))); ?>">
    <script src="<?php echo e(asset('js/dashboard-search.js')); ?>?v=<?php echo e(filemtime(public_path('js/dashboard-search.js'))); ?>" defer></script>
<?php endif; ?>
<form class="search dashboard-search" role="search" method="GET" action="<?php echo e(route('dashboard.search')); ?>" data-dashboard-search data-no-page-loader novalidate>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
    <label class="sr-only" for="dashboardSearchInput">Search dashboard</label>
    <input id="dashboardSearchInput" type="search" name="q" maxlength="160" placeholder="Search dashboard" autocomplete="off" aria-controls="dashboardSearchResults" data-dashboard-search-input>
    <button class="dashboard-search-clear" type="button" aria-label="Clear dashboard search" data-dashboard-search-clear hidden>&times;</button>
    <section class="dashboard-search-panel" id="dashboardSearchResults" aria-label="Dashboard search results" data-dashboard-search-panel hidden>
        <p class="dashboard-search-status" role="status" aria-live="polite" data-dashboard-search-status></p>
        <div data-dashboard-search-results></div>
        <button class="dashboard-search-retry page-button" type="button" data-dashboard-search-retry hidden>Retry search</button>
    </section>
</form>
<?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views/components/dashboard-search.blade.php ENDPATH**/ ?>