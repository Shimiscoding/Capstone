<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['staff', 'attendances']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['staff', 'attendances']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $canManage = auth()->user()->isAdmin();
?>
<section class="table-card attendance-records-card">
    <div class="supervisor-list-heading">
        <div class="user-cell"><?php if (isset($component)) { $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-avatar','data' => ['user' => $staff]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($staff)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $attributes = $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $component = $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?><span><strong><?php echo e($staff->fullName); ?></strong><small><?php echo e($staff->username ? '@'.$staff->username.' · ' : ''); ?><?php echo e($staff->email); ?></small></span></div>
    </div>
    <div class="table-scroll attendance-records-scroll" tabindex="0" role="region" aria-label="Attendance history table">
        <table class="users-table attendance-table attendance-records-table">
            <caption class="attendance-visually-hidden">Attendance history for <?php echo e($staff->fullName); ?></caption>
            <thead><tr>
                <th scope="col">Date</th>
                <th scope="col">Duty</th>
                <th scope="col">Time in</th><th scope="col">Time out</th><th scope="col">Total hours</th><th scope="col">Status</th>
                <?php if($canManage): ?><th scope="col">Actions</th><?php endif; ?>
            </tr></thead>
            <tbody>
                <?php $__empty_2 = true; $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <tr>
                        <th scope="row"><span class="attendance-cell-value"><?php echo e($attendance->attendance_date->format('M d, Y')); ?></span><small class="attendance-cell-detail"><?php echo e($attendance->attendance_date->format('l')); ?></small></th>
                        <td><?php echo e($attendance->dutyLabel()); ?></td>
                        <?php $__currentLoopData = ['time_in' => 'Time in', 'time_out' => 'Time out']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <span class="attendance-cell-value"><?php echo e($attendance->$field?->format('h:i:s A') ?? '—'); ?></span>
                                <?php if($attendance->{$field.'_latitude'} !== null && $attendance->{$field.'_longitude'} !== null): ?>
                                    <a class="attendance-cell-detail attendance-map-link" href="https://www.google.com/maps?q=<?php echo e($attendance->{$field.'_latitude'}); ?>,<?php echo e($attendance->{$field.'_longitude'}); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo e($label); ?> location for <?php echo e($attendance->attendance_date->format('M d, Y')); ?>, <?php echo e($attendance->dutyLabel()); ?> duty (opens in a new tab)">Open map</a>
                                <?php else: ?>
                                    <small class="attendance-cell-detail"><?php echo e($attendance->$field ? 'Location unavailable' : 'Not recorded'); ?></small>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($attendance->time_in && $attendance->time_out ? number_format($attendance->time_in->diffInMinutes($attendance->time_out) / 60, 2).' hrs' : '—'); ?></td>
                        <td><span class="attendance-state <?php echo e($attendance->time_out ? 'is-complete' : 'is-active'); ?>"><?php echo e($attendance->time_out ? 'Completed' : 'Timed in'); ?></span></td>
                        <?php if($canManage): ?>
                            <td><div class="attendance-row-actions">
                                <button type="button" class="attendance-record-button" data-attendance-edit data-url="<?php echo e(route('dashboard.attendance.enforcers.time-out', $attendance)); ?>" data-label="<?php echo e($attendance->attendance_date->format('l, M d, Y')); ?> · <?php echo e($attendance->dutyLabel()); ?> duty" data-time-in="<?php echo e($attendance->time_in?->format('H:i')); ?>" data-time-out="<?php echo e($attendance->time_out?->format('H:i')); ?>" aria-label="Edit attendance for <?php echo e($attendance->attendance_date->format('M d, Y')); ?>, <?php echo e($attendance->dutyLabel()); ?> duty">Edit</button>
                                <button type="button" class="attendance-record-button is-danger" data-attendance-delete data-url="<?php echo e(route('dashboard.attendance.enforcers.destroy', $attendance)); ?>" data-label="<?php echo e($attendance->attendance_date->format('l, M d, Y')); ?> · <?php echo e($attendance->dutyLabel()); ?> duty" aria-label="Delete attendance for <?php echo e($attendance->attendance_date->format('M d, Y')); ?>, <?php echo e($attendance->dutyLabel()); ?> duty">Delete</button>
                            </div></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                    <tr><td colspan="<?php echo e(6 + (int) $canManage); ?>" class="empty-state"><strong>No timestamp records</strong><span>This enforcer has not recorded attendance yet.</span></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($attendances->hasPages()): ?>
        <div class="table-footer"><span>Showing <?php echo e($attendances->firstItem()); ?>–<?php echo e($attendances->lastItem()); ?> of <?php echo e($attendances->total()); ?></span><div class="pagination-actions"><?php echo e($attendances->links()); ?></div></div>
    <?php endif; ?>
</section>

<?php if($canManage): ?>
    <dialog class="attendance-restriction-modal attendance-record-dialog" id="attendanceEditDialog" aria-labelledby="attendanceEditTitle" aria-describedby="attendanceEditDescription">
        <header class="attendance-modal-head"><div><h2 id="attendanceEditTitle">Edit attendance</h2><p id="attendanceEditDescription" data-record-label></p></div><button type="button" data-close-dialog aria-label="Close attendance editor">&times;</button></header>
        <form method="POST" class="attendance-record-form" novalidate>
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="attendance-record-fields">
                <p class="attendance-record-error" role="alert" tabindex="-1" hidden></p>
                <label for="attendanceRecordTimeIn">Time in<input id="attendanceRecordTimeIn" type="time" name="time_in" required></label>
                <label for="attendanceRecordTimeOut">Time out<input id="attendanceRecordTimeOut" type="time" name="time_out" required></label>
            </div>
            <footer class="attendance-modal-actions"><button type="button" data-close-dialog>Cancel</button><button type="submit">Save changes</button></footer>
        </form>
    </dialog>
    <dialog class="attendance-restriction-modal attendance-record-dialog" id="attendanceDeleteDialog" aria-labelledby="attendanceDeleteTitle" aria-describedby="attendanceDeleteDescription">
        <header class="attendance-modal-head"><div><h2 id="attendanceDeleteTitle">Delete attendance record?</h2><p><?php echo e($staff->fullName); ?></p></div><button type="button" data-close-dialog aria-label="Close delete confirmation">&times;</button></header>
        <form method="POST" class="attendance-record-form" novalidate>
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <input type="hidden" name="page" value="<?php echo e($attendances->currentPage()); ?>">
            <div class="attendance-record-fields"><p class="attendance-record-error" role="alert" tabindex="-1" hidden></p><p data-record-label></p><p id="attendanceDeleteDescription">This removes this attendance record from the history and totals. This cannot be undone. The deletion remains in the audit log.</p></div>
            <footer class="attendance-modal-actions"><button type="button" data-close-dialog autofocus>Cancel</button><button type="submit">Delete record</button></footer>
        </form>
    </dialog>
    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/attendance-history.js')); ?>?v=<?php echo e(filemtime(public_path('js/attendance-history.js'))); ?>" defer></script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\components\attendance-history-table.blade.php ENDPATH**/ ?>