<?php $__env->startSection('title', 'Area Assignments'); ?>
<?php $__env->startSection('activePage', 'area-assignments'); ?>
<?php $__env->startSection('workspaceClass', 'workspace-full-width area-assignment-workspace'); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/area-assignments.css')); ?>?v=<?php echo e(filemtime(public_path('css/area-assignments.css'))); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head users-page-head">
        <div class="users-heading-copy">
            <p class="eyebrow">Field operations</p>
            <h1><?php echo e($canManage ? 'Enforcer Area Assignments' : 'My Assigned Areas'); ?> <span class="users-heading-count"><?php echo e(number_format($officers->total())); ?></span></h1>
            <p class="page-description"><?php echo e($canManage ? 'Assign up to '.$maxAreas.' duty areas per enforcer.' : 'View your assigned duty areas.'); ?></p>
        </div>
    </div>

    <?php if(session('area_assignment_success')): ?>
        <div class="success-message" role="status"><?php echo e(session('area_assignment_success')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="flash-alert is-error" role="alert"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <?php if($canManage): ?>
        <form class="users-reference-toolbar area-assignment-toolbar" method="GET" action="<?php echo e(route('area-assignments.index')); ?>" role="search" novalidate>
            <input type="hidden" name="type" value="<?php echo e($type); ?>">
            <div class="users-toolbar-main">
                <div class="users-toolbar-actions">
                    <label class="toolbar-search">
                        <svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="8.5" cy="8.5" r="5"/><path d="m12.2 12.2 4 4"/></svg>
                        <span class="sr-only">Search enforcers</span>
                        <input name="search" type="search" id="areaOfficerSearch" value="<?php echo e($search); ?>" placeholder="Search enforcer or username">
                        <button class="area-search-clear" type="button" aria-label="Clear enforcer search" <?php if($search === ''): ?> hidden <?php endif; ?>>&times;</button>
                    </label>
                    <label class="users-filter-chip">
                        <span>Area</span>
                        <select name="area">
                            <option value="" <?php if($area === ''): echo 'selected'; endif; ?>>All areas</option>
                            <option value="__unassigned" <?php if($area === '__unassigned'): echo 'selected'; endif; ?>>Unassigned</option>
                            <?php if($area !== '' && $area !== '__unassigned' && !$areas->contains($area)): ?>
                                <option value="<?php echo e($area); ?>" selected><?php echo e($area); ?></option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $availableArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($availableArea); ?>" <?php if($area === $availableArea): echo 'selected'; endif; ?>><?php echo e($availableArea); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                    <button class="toolbar-outline-button" type="submit">Filter</button>
                    <?php if($search !== '' || $area !== ''): ?>
                        <a class="toolbar-text-button" href="<?php echo e(route('area-assignments.index', ['type' => $type])); ?>">Clear filters</a>
                    <?php endif; ?>
                    <button class="toolbar-outline-button toolbar-add-user" id="openAddArea" type="button"><span aria-hidden="true">+</span> Add area</button>
                </div>
            </div>
        </form>
    <?php endif; ?>

    <section class="table-card area-assignment-card <?php echo e($canManage ? '' : 'area-assignment-readonly'); ?>" aria-label="Enforcer area assignments">
        <p class="area-table-hint">Scroll horizontally to see all columns.</p>
        <div class="table-scroll" role="region" aria-label="Enforcer area assignments table" tabindex="0">
            <table class="users-table area-assignment-table">
                <caption class="sr-only">Enforcers and their current operational area assignments</caption>
                <thead><tr><th scope="col">Enforcer</th><?php if(auth()->user()->isOfficer()): ?><th scope="col">Supervisor / Team</th><?php endif; ?><th scope="col">Current areas</th><th scope="col"><?php echo e($canManage ? 'Actions' : 'Assignment status'); ?></th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $officers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php($assignedAreas = $officer->assignedAreas())
                        <tr>
                            <td><div class="user-cell"><x-user-avatar :user="$officer" /><span><strong>{{ $officer->fullName }}</strong><small>{{ $officer->username ? '@'.$officer->username : $officer->email }}</small></span></div></td>
                            @if(auth()->user()->isOfficer())
                                <td><strong>{{ $officer->supervisor?->fullName ?? 'Unassigned' }}</strong><small class="area-table-muted">{{ $officer->supervisor ? 'Supervisor-led team' : 'No team assigned' }}</small></td>
                            @endif
                            <td>
                                @if ($assignedAreas)
                                    <ul class="area-current-list" role="list">
                                        @foreach ($assignedAreas as $assignedArea)
                                            <li class="area-current">{{ $assignedArea }}</li>
                                        @endforeach
                                    </ul>
                                @else
                                    <span class="area-current is-unassigned">Unassigned</span>
                                @endif
                            </td>
                            <td>
                                @if ($canManage)
                                    <button type="button" class="page-button area-edit-button" aria-haspopup="dialog"
                                        aria-label="Edit areas for {{ $officer->fullName }}"
                                        data-edit-areas="{{ $officer->id }}" data-enforcer-name="{{ $officer->fullName }}"
                                        data-update-url="{{ route('area-assignments.update', $officer) }}"
                                        data-assigned-areas="{{ json_encode($assignedAreas, JSON_INVALID_UTF8_SUBSTITUTE) }}">
                                        Edit areas
                                    </button>
                                @else
                                    <span class="area-table-muted">Contact your supervisor if this assignment needs to be changed.</span>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="{{ auth()->user()->isOfficer() ? 4 : 3 }}" class="empty-state"><strong>{{ $search !== '' || $area !== '' ? 'No enforcers found' : 'No enforcers assigned yet' }}</strong><span>{{ $search !== '' || $area !== '' ? 'Try a different name or area.' : 'Enforcers will appear here when they are available for assignment.' }}</span>@if ($canManage && ($search !== '' || $area !== ''))<a class="page-button" href="{{ route('area-assignments.index', ['type' => $type]) }}">Clear filters</a>@endif</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="table-footer">
            <span>Showing {{ $officers->firstItem() ?? 0 }}–{{ $officers->lastItem() ?? 0 }} of {{ number_format($officers->total()) }} enforcers</span>
            <nav class="pagination-actions" aria-label="Area assignment pages">
                @if ($officers->onFirstPage())<span class="page-button is-disabled" aria-disabled="true">Previous</span>@else<a class="page-button" href="{{ $officers->previousPageUrl() }}">Previous</a>@endif
                <span class="area-page-number">Page {{ $officers->currentPage() }} of {{ max(1, $officers->lastPage()) }}</span>
                @if ($officers->hasMorePages())<a class="page-button" href="{{ $officers->nextPageUrl() }}">Next</a>@else<span class="page-button is-disabled" aria-disabled="true">Next</span>@endif
            </nav>
        </div>
    </section>

    @if ($canManage)
        <dialog class="attendance-restriction-modal area-modal" id="editAreaModal" aria-labelledby="editAreaTitle" aria-describedby="editAreaDescription"
            @if ($errors->hasAny(['areas', 'areas.*']))
                data-retry-enforcer="{{ old('assignment_user_id') }}"
                data-retry-areas="{{ json_encode(old('areas'), JSON_INVALID_UTF8_SUBSTITUTE) }}"
            @endif>
            <div class="attendance-modal-head">
                <div>
                    <h2 id="editAreaTitle" tabindex="-1">Edit duty areas</h2>
                    <p id="editAreaDescription">Assign up to {{ $maxAreas }} distinct areas to <strong id="editAreaEnforcer"></strong>. Leave unused slots blank.</p>
                </div>
                <button type="button" data-close-area-modal aria-label="Close edit areas">&times;</button>
            </div>
            <form class="attendance-restriction-form area-assignment-form" id="editAreaForm" method="POST" data-area-save novalidate>
                @csrf @method('PUT')
                <input type="hidden" name="assignment_user_id">
                <div class="area-assignment-fields">
                    @for ($index = 0; $index < $maxAreas; $index++)
                        @php
                            $fieldId = 'duty-area-'.$index;
                            $fieldError = ($index === 0 ? $errors->first('areas') : '') ?: $errors->first('areas.'.$index);
                        ?>
                        <div class="area-assignment-field">
                            <label for="<?php echo e($fieldId); ?>">Duty area <?php echo e($index + 1); ?></label>
                            <div>
                                <select id="<?php echo e($fieldId); ?>" name="areas[]" <?php if($fieldError): ?> aria-invalid="true" aria-describedby="<?php echo e($fieldId); ?>-error" <?php endif; ?>>
                                    <option value="">No area selected</option>
                                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $availableArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($availableArea); ?>"><?php echo e($availableArea); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($fieldError): ?>
                                    <span class="area-field-error" id="<?php echo e($fieldId); ?>-error"><?php echo e($fieldError); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
                <div class="attendance-modal-actions">
                    <button type="button" class="page-button" data-close-area-modal>Cancel</button>
                    <button type="submit">Save areas</button>
                </div>
            </form>
        </dialog>

        <dialog class="attendance-restriction-modal area-modal area-add-modal" id="addAreaModal" aria-labelledby="addAreaTitle" aria-describedby="addAreaDescription">
            <div class="attendance-modal-head">
                <div><h2 id="addAreaTitle">Add operational area</h2><p id="addAreaDescription">Create an area that can be selected when assigning enforcers.</p></div>
                <button type="button" data-close-area-modal aria-label="Close modal">&times;</button>
            </div>
            <form class="attendance-restriction-form" method="POST" action="<?php echo e(route('area-assignments.areas.store')); ?>" id="addAreaForm" data-area-save novalidate>
                <?php echo csrf_field(); ?>
                <div class="form-field">
                    <label for="newAreaName">Area or location <span>Required</span></label>
                    <input id="newAreaName" name="name" type="text" maxlength="255" required value="<?php echo e(old('name')); ?>" placeholder="Enter area name" aria-describedby="newAreaError" <?php if($errors->has('name')): ?> aria-invalid="true" <?php endif; ?>>
                    <span class="area-field-error" id="newAreaError" <?php if(!$errors->has('name')): ?> hidden <?php endif; ?>><?php echo e($errors->first('name')); ?></span>
                </div>
                <div class="attendance-modal-actions"><button class="page-button" type="button" data-close-area-modal>Cancel</button><button type="submit">Add area</button></div>
            </form>
        </dialog>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php if($canManage): ?>
<script>
(() => {
    const search = document.getElementById('areaOfficerSearch');
    const clearSearch = document.querySelector('.area-search-clear');
    search.addEventListener('input', () => { clearSearch.hidden = !search.value; });
    clearSearch.addEventListener('click', () => {
        search.value = '';
        clearSearch.hidden = true;
        search.focus();
        search.form.requestSubmit();
    });
    const modal = document.getElementById('addAreaModal');
    const opener = document.getElementById('openAddArea');
    const name = document.getElementById('newAreaName');
    const nameError = document.getElementById('newAreaError');
    opener.addEventListener('click', () => { modal.showModal(); name.focus(); });
    modal.addEventListener('close', () => opener.focus());
    name.addEventListener('input', () => { name.removeAttribute('aria-invalid'); nameError.hidden = true; });

    const editModal = document.getElementById('editAreaModal');
    const editForm = document.getElementById('editAreaForm');
    const editTitle = document.getElementById('editAreaTitle');
    const enforcer = document.getElementById('editAreaEnforcer');
    const editButtons = Array.from(document.querySelectorAll('[data-edit-areas]'));
    let editOpener;
    function openEditor(button, retry = false) {
        editOpener = button;
        editForm.action = button.dataset.updateUrl;
        editForm.elements.assignment_user_id.value = button.dataset.editAreas;
        enforcer.textContent = button.dataset.enforcerName;
        const saved = JSON.parse(button.dataset.assignedAreas);
        const selected = retry ? JSON.parse(editModal.dataset.retryAreas) : saved;

        editForm.querySelectorAll('select').forEach((select, index) => {
            select.querySelectorAll('[data-saved-option]').forEach(option => option.remove());
            saved.forEach(area => {
                if (Array.from(select.options).some(option => option.value === area)) return;
                const option = new Option(area, area);
                option.setAttribute('data-saved-option', '');
                select.add(option);
            });
            select.value = selected?.[index] ?? '';
            if (select.selectedIndex === -1) select.selectedIndex = 0;
        });
        editModal.showModal();
        (editForm.querySelector('[aria-invalid="true"]') ?? editTitle).focus();
    }
    editButtons.forEach(button => button.addEventListener('click', () => openEditor(button)));
    editModal.addEventListener('close', () => {
        editForm.querySelectorAll('[aria-invalid]').forEach(select => {
            select.removeAttribute('aria-invalid');
            select.removeAttribute('aria-describedby');
        });
        editForm.querySelectorAll('.area-field-error').forEach(error => { error.hidden = true; });
        editOpener?.focus();
    });
    [modal, editModal].forEach(dialog => {
        dialog.querySelectorAll('[data-close-area-modal]').forEach(button => button.addEventListener('click', () => dialog.close()));
        dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
    });
    document.querySelectorAll('[data-area-save]').forEach(form => form.addEventListener('submit', event => {
        if (form.dataset.submitting === 'true') { event.preventDefault(); return; }
        if (form.id === 'addAreaForm' && !name.value.trim()) {
            event.preventDefault();
            name.setAttribute('aria-invalid', 'true');
            nameError.textContent = 'Enter an area or location.';
            nameError.hidden = false;
            name.focus();
            return;
        }
        form.dataset.submitting = 'true';
        form.setAttribute('aria-busy', 'true');
        form.querySelector('button[type="submit"]').disabled = true;
    }));
    window.addEventListener('pageshow', () => document.querySelectorAll('[data-area-save]').forEach(form => {
        delete form.dataset.submitting;
        form.removeAttribute('aria-busy');
        form.querySelector('button[type="submit"]').disabled = false;
    }));
    const retryButton = editButtons.find(button => button.dataset.editAreas === editModal.dataset.retryEnforcer);
    if (retryButton) {
        openEditor(retryButton, true);
    } else if (name.hasAttribute('aria-invalid')) {
        modal.showModal();
        name.focus();
    }
})();
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make(auth()->user()->isSupervisor() ? 'layouts.supervisor-dashboard' : 'layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\area-assignments\index.blade.php ENDPATH**/ ?>