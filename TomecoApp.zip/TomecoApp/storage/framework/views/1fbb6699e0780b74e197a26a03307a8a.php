
<?php $__env->startSection('title', 'Settings'); ?>
<?php $__env->startSection('activePage', 'settings'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $tabs = [
            'general' => 'General',
            'notifications' => 'Notifications',
            'security' => 'Security',
        ];
        $activeTab = array_key_exists($activeTab, $tabs) ? $activeTab : 'general';
        $get = fn($key, $fallback = '') => old($key, $settings[$activeTab . '.' . $key] ?? $fallback);
        $checked = fn($key) => old($key, $settings[$activeTab . '.' . $key] ?? false);
    ?>
    <?php if(session('success')): ?>
        <div class="flash-alert is-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="flash-alert is-error">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>

    <div class="page-head">
        <div>
            <p class="eyebrow">Administration</p>
            <h1>System Settings</h1>
            <p class="page-description">Manage general preferences, notifications, and security.</p>
        </div>
    </div>

    <div class="settings-shell">
        <nav class="settings-tabs" aria-label="Settings sections">
            <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="<?php echo e($activeTab === $key ? 'is-active' : ''); ?>"
                    href="<?php echo e(route('dashboard.settings', ['tab' => $key])); ?>">
                    <?php echo e($label); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        <section class="settings-card">
            <div class="settings-heading">
                <h2><?php echo e($tabs[$activeTab]); ?></h2>
                <p>Changes are stored securely and apply across the application.</p>
            </div>

            <form method="POST" action="<?php echo e(route('dashboard.settings.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="section" value="<?php echo e($activeTab); ?>">
                <div class="settings-grid">
                    <?php if($activeTab === 'general'): ?>
                        <label>
                            <span>Organization name</span>
                            <input name="organization_name" value="<?php echo e($get('organization_name')); ?>" required>
                        </label>
                        <label>
                            <span>Contact email</span>
                            <input type="email" name="email" value="<?php echo e($get('email')); ?>">
                        </label>
                        <label class="wide">
                            <span>Office address</span>
                            <input name="address" value="<?php echo e($get('address')); ?>">
                        </label>
                        <label>
                            <span>Phone number</span>
                            <input name="phone" value="<?php echo e($get('phone')); ?>">
                        </label>
                        <label>
                            <span>Timezone</span>
                            <select name="timezone">
                                <option value="Asia/Manila" <?php if($get('timezone') === 'Asia/Manila'): echo 'selected'; endif; ?>>Asia/Manila</option>
                                <option value="UTC" <?php if($get('timezone') === 'UTC'): echo 'selected'; endif; ?>>UTC</option>
                            </select>
                        </label>
                        <label>
                            <span>Date format</span>
                            <select name="date_format">
                                <option value="M j, Y" <?php if($get('date_format') === 'M j, Y'): echo 'selected'; endif; ?>>Jul 22, 2026</option>
                                <option value="Y-m-d" <?php if($get('date_format') === 'Y-m-d'): echo 'selected'; endif; ?>>2026-07-22</option>
                                <option value="d/m/Y" <?php if($get('date_format') === 'd/m/Y'): echo 'selected'; endif; ?>>22/07/2026</option>
                            </select>
                        </label>
                        <label>
                            <span>Violation prefix</span>
                            <input name="violation_prefix" value="<?php echo e($get('violation_prefix')); ?>" required>
                        </label>
                    <?php elseif($activeTab === 'notifications'): ?>
                        <?php $__currentLoopData = ['new_violation' => 'New violation alerts', 'overdue_reminder' => 'Overdue fine reminders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="toggle-field">
                                <input type="checkbox" name="<?php echo e($key); ?>" value="1"
                                    <?php if($checked($key)): echo 'checked'; endif; ?>>
                                <span><?php echo e($label); ?></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="wide">
                            <span>Administrative recipient email</span>
                            <input type="email" name="recipient_email" value="<?php echo e($get('recipient_email')); ?>">
                        </label>
                    <?php elseif($activeTab === 'security'): ?>
                        <?php $__currentLoopData = ['password_min_length' => 'Minimum password length', 'session_timeout' => 'Session timeout (minutes)', 'login_attempts' => 'Maximum login attempts', 'api_token_days' => 'API token expiry (days)', 'audit_retention_days' => 'Audit retention (days)']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label>
                                <span><?php echo e($label); ?></span>
                                <input type="number" name="<?php echo e($field); ?>" value="<?php echo e($get($field)); ?>">
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="toggle-field">
                            <input type="checkbox" name="two_factor" value="1" <?php if($checked('two_factor')): echo 'checked'; endif; ?>>
                            <span>Require two-factor authentication</span>
                        </label>
                        <label class="toggle-field wide">
                            <input type="checkbox" name="admin_signup_enabled" value="1"
                                <?php if($checked('admin_signup_enabled')): echo 'checked'; endif; ?>>
                            <span>Allow admin signup <small>Shows “Sign up as admin” on the login page. Turn this off after creating the required administrator account.</small></span>
                        </label>
                    <?php endif; ?>
                </div>
                <div class="settings-actions">
                    <button type="submit">Save <?php echo e($tabs[$activeTab]); ?></button>
                </div>
            </form>

        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\dashboard\settings.blade.php ENDPATH**/ ?>