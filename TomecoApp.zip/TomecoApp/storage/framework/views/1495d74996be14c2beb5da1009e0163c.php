<?php $__env->startSection('title', ($motorist->full_name ?: 'Driver').' violation history'); ?>
<?php $__env->startSection('activePage', 'violation-records'); ?>
<?php $__env->startSection('workspaceClass', 'workspace-full-width'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $motoristName = $motorist->full_name ?: 'Unknown driver';
    $initials = collect(preg_split('/\s+/', $motoristName))->filter()->map(fn ($part) => strtoupper(substr($part, 0, 1)))->take(2)->join('');
    $permitType = match ($motorist->license_type) { 'professional' => 'Professional', 'non_professional' => 'Non-professional', 'student_permit' => 'Student permit', default => 'Not specified' };
?>

<header class="page-head violation-detail-page-head motorist-history-head">
    <div>
        <nav class="detail-breadcrumb" aria-label="Breadcrumb"><a href="<?php echo e(route('dashboard.violation-records')); ?>">Violation records</a><span aria-hidden="true">/</span><span aria-current="page"><?php echo e($motoristName); ?></span></nav>
        <h1>Driver violation history</h1>
        <p class="page-description">Identity details and every ticket recorded for this driver.</p>
    </div>
    <a class="page-button violation-back-button" href="<?php echo e(route('dashboard.violation-records')); ?>"><span aria-hidden="true">&larr;</span><span>Back to records</span></a>
</header>

<section class="motorist-profile-card" aria-labelledby="motorist-name">
    <div class="motorist-profile-identity"><span class="motorist-profile-avatar" aria-hidden="true"><?php echo e($initials ?: 'D'); ?></span><div><p class="eyebrow">Driver record</p><h2 id="motorist-name"><?php echo e($motoristName); ?></h2><div class="motorist-profile-meta"><span><?php echo e($permitType); ?></span><span><?php echo e($motoristViolations->total()); ?> <?php echo e(\Illuminate\Support\Str::plural('violation', $motoristViolations->total())); ?></span></div></div></div>
    <dl class="motorist-profile-facts">
        <div><dt>First name</dt><dd><?php echo e($motorist->first_name ?: 'Not recorded'); ?></dd></div>
        <div><dt>Middle name</dt><dd><?php echo e($motorist->middle_name ?: 'Not recorded'); ?></dd></div>
        <div><dt>Last name</dt><dd><?php echo e($motorist->last_name ?: 'Not recorded'); ?></dd></div>
        <div><dt>D/L permit number</dt><dd><?php echo e($motorist->license_number ?: 'Not recorded'); ?></dd></div>
        <div><dt>Permit type</dt><dd><?php echo e($permitType); ?></dd></div>
        <div><dt>Total assessed fines</dt><dd class="motorist-total-fine">&#8369;<?php echo e(number_format($totalAssessedFines, 2)); ?></dd></div>
    </dl>
</section>

<section class="motorist-history-section" aria-labelledby="history-title">
    <header class="motorist-history-section-head"><div><p class="eyebrow">Citation ledger</p><h2 id="history-title">Recorded violations</h2></div><span><?php echo e($motoristViolations->total()); ?> total</span></header>
    <div class="table-card motorist-history-table-card">
        <div class="table-scroll"><table class="users-table motorist-history-table">
            <thead><tr><th>Ticket</th><th>Violation</th><th>Vehicle</th><th>OR / CR</th><th>Location</th><th>Enforcer</th><th>Date issued</th><th>Fine / status</th><th class="actions-column">Actions</th></tr></thead>
            <tbody>
                <?php $__currentLoopData = $motoristViolations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a class="ticket-link" href="<?php echo e(route('dashboard.violation-records.show', $record)); ?>"><?php echo e($record->display_ticket_number); ?></a><small><?php echo e($record->created_at?->format('h:i A')); ?></small></td>
                        <td><strong><?php echo e($record->violation_type ?: 'Not recorded'); ?></strong></td>
                        <td><strong class="badge-number"><?php echo e($record->plate_number ?: '—'); ?></strong><small><?php echo e($record->vehicle_type ?: 'Not specified'); ?></small></td>
                        <td><span>OR: <?php echo e($record->or_number ?: '—'); ?></span><small>CR: <?php echo e($record->cr_number ?: '—'); ?></small></td>
                        <td><span class="cell-wrap"><?php echo e($record->location ?: 'Not recorded'); ?></span></td>
                        <td><strong><?php echo e($record->enforcer_name ?: $record->enforcer?->fullName ?: 'Not recorded'); ?></strong><small><?php echo e(filled($record->enforcer_signature) ? 'Signature recorded' : 'Signature missing'); ?></small></td>
                        <td><?php echo e($record->created_at?->format('M d, Y') ?? '—'); ?></td>
                        <td><div class="motorist-fine-status"><strong>&#8369;<?php echo e(number_format($record->fine_amount, 2)); ?></strong><span class="status-badge <?php echo e($record->status === 'paid' ? '' : 'status-pending'); ?>"><?php echo e(ucfirst($record->status ?: 'unpaid')); ?></span></div></td>
                        <td class="actions-column"><a class="row-view-action" href="<?php echo e(route('dashboard.violation-records.show', $record)); ?>" aria-label="View ticket <?php echo e($record->display_ticket_number); ?>">View</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table></div>
        <footer class="table-footer"><span>Showing <?php echo e($motoristViolations->firstItem()); ?>–<?php echo e($motoristViolations->lastItem()); ?> of <?php echo e($motoristViolations->total()); ?></span><?php if($motoristViolations->hasPages()): ?><nav class="pagination-actions" aria-label="Driver violation pages"><?php if($motoristViolations->onFirstPage()): ?><span class="page-button is-disabled">Previous</span><?php else: ?><a class="page-button" href="<?php echo e($motoristViolations->previousPageUrl()); ?>">Previous</a><?php endif; ?> <?php if($motoristViolations->hasMorePages()): ?><a class="page-button" href="<?php echo e($motoristViolations->nextPageUrl()); ?>">Next</a><?php else: ?><span class="page-button is-disabled">Next</span><?php endif; ?></nav><?php endif; ?></footer>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\dashboard\motorist-violation-history.blade.php ENDPATH**/ ?>