<?php $__env->startSection('title', 'Supervisor Dashboard'); ?>
<?php $__env->startSection('activePage', 'dashboard'); ?>
<?php $__env->startSection('workspaceClass', 'supervisor-home'); ?>
<?php $__env->startSection('headerSearch'); ?><span class="supervisor-topbar-label">Supervisor workspace</span><?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/supervisor-home.css')); ?>?v=<?php echo e(filemtime(public_path('css/supervisor-home.css'))); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <header class="page-head supervisor-home-heading">
        <div>
            <p class="eyebrow">Team operations / Overview</p>
            <h1>Welcome, <?php echo e($supervisor->firstName); ?></h1>
            <p class="page-description">Your team, assignments, and coverage at a glance.</p>
        </div>
        <div class="supervisor-home-date"><strong><?php echo e($dashboardNow->format('l, F j, Y')); ?></strong></div>
    </header>

    <section class="supervisor-home-stats" aria-label="Team summary">
        <a class="supervisor-home-stat is-primary" href="<?php echo e(route('supervisor.team')); ?>">
            <span>Assigned enforcers<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3"/><path d="M3 21v-2a6 6 0 0 1 12 0v2M17 5a3 3 0 0 1 0 6M20 21v-2a6 6 0 0 0-2-4"/></svg></span>
            <strong><?php echo e(number_format($enforcerCount)); ?></strong><small>Members under your supervision <span aria-hidden="true">↗</span></small>
        </a>
        <a class="supervisor-home-stat" href="<?php echo e(route('area-assignments.index')); ?>">
            <span>Areas covered<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3zM9 3v15M15 6v15"/></svg></span>
            <strong><?php echo e(number_format($areaCount)); ?></strong><small>Distinct areas assigned to your team <span aria-hidden="true">↗</span></small>
        </a>
        <a class="supervisor-home-stat" href="<?php echo e(route('area-assignments.index', ['area' => '__unassigned'])); ?>">
            <span>Awaiting area assignment<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s7-5 7-12a7 7 0 1 0-14 0c0 7 7 12 7 12Z"/><path d="M12 6v4M12 13v.5"/></svg></span>
            <strong><?php echo e(number_format($unassignedAreaCount)); ?></strong><small><?php echo e($unassignedAreaCount ? 'Review members without an assigned area' : 'No area assignments pending'); ?> <span aria-hidden="true">↗</span></small>
        </a>
    </section>

    <div class="supervisor-home-middle">
        <section class="supervisor-home-panel" aria-labelledby="coverageTitle">
            <div class="supervisor-home-panel-head"><div><h2 id="coverageTitle">Team coverage</h2><p>Enforcers by assigned area</p></div><a class="supervisor-home-link" href="<?php echo e(route('area-assignments.index')); ?>">Manage areas <span aria-hidden="true">→</span></a></div>
            <?php if($coverageAreas->isNotEmpty()): ?>
                <ul class="supervisor-coverage-list">
                    <?php $__currentLoopData = $coverageAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('area-assignments.index', ['area' => $area])); ?>"><span class="supervisor-coverage-name"><?php echo e($area); ?></span><span class="supervisor-coverage-track" aria-hidden="true"><span style="width: <?php echo e(round($count / max(1, $enforcerCount) * 100, 2)); ?>%"></span></span><strong><?php echo e($count); ?> <span><?php echo e(\Illuminate\Support\Str::plural('enforcer', $count)); ?></span></strong></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <p class="supervisor-coverage-note"><?php echo e($areaCount > 4 ? 'Showing the 4 areas with the most assigned enforcers.' : 'Based on current team assignments.'); ?> Assignment counts do not indicate live presence.</p>
            <?php else: ?>
                <div class="supervisor-home-empty"><span class="supervisor-empty-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3zM9 3v15M15 6v15"/></svg></span><strong>No areas assigned yet</strong><p><?php echo e($enforcerCount ? 'Assign an area to your enforcers to see team coverage here.' : 'Add enforcers to your team, then set their assigned areas.'); ?></p><a class="supervisor-home-link" href="<?php echo e(route($enforcerCount ? 'area-assignments.index' : 'supervisor.team')); ?>"><?php echo e($enforcerCount ? 'Assign areas' : 'Manage my team'); ?> <span aria-hidden="true">→</span></a></div>
            <?php endif; ?>
        </section>

        <section class="supervisor-home-panel supervisor-home-actions" aria-labelledby="actionsTitle">
            <div class="supervisor-home-panel-head"><div><h2 id="actionsTitle">Quick actions</h2><p>Continue your daily operations</p></div></div>
            <a href="<?php echo e(route('location-monitoring.index')); ?>"><span class="supervisor-action-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s7-5 7-12a7 7 0 1 0-14 0c0 7 7 12 7 12Z"/><circle cx="12" cy="9" r="2.5"/></svg></span><span><strong>Location Monitoring</strong><small>View your team's reported positions</small></span><span aria-hidden="true">↗</span></a>
            <a href="<?php echo e(route('supervisor.enforcers.attendance.index')); ?>"><span class="supervisor-action-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="5" width="16" height="16" rx="2"/><path d="M8 3v4M16 3v4M4 11h16m-12 5 3 3 5-5"/></svg></span><span><strong>Enforcer attendance</strong><small>Review your team's attendance history</small></span><span aria-hidden="true">↗</span></a>
            <a href="<?php echo e(route('supervisor.team')); ?>"><span class="supervisor-action-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3"/><path d="M3 21v-2a6 6 0 0 1 12 0v2M19 8v6M16 11h6"/></svg></span><span><strong>Manage my team</strong><small>Review and update your assigned members</small></span><span aria-hidden="true">↗</span></a>
        </section>
    </div>

    <section class="supervisor-home-panel supervisor-roster" aria-labelledby="rosterTitle">
        <div class="supervisor-home-panel-head"><div><h2 id="rosterTitle">Assigned enforcers <span class="supervisor-roster-count"><?php echo e(number_format($enforcerCount)); ?></span></h2><p>Your current team directory</p></div><a class="supervisor-home-link" href="<?php echo e(route('supervisor.team')); ?>">Manage team <span aria-hidden="true">→</span></a></div>
        <div class="table-scroll" role="region" aria-label="Assigned enforcers directory" tabindex="0">
            <table class="users-table supervisor-roster-table">
                <caption class="sr-only">Enforcers assigned to your team, with contact information and assigned areas</caption>
                <thead><tr><th scope="col">Enforcer</th><th scope="col">Contact details</th><th scope="col">Assigned area</th><th scope="col">Account status</th><th scope="col"><span class="sr-only">Attendance details</span></th></tr></thead>
                <tbody>
                    <?php $__empty_2 = true; $__currentLoopData = $enforcers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enforcer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <?php ($accountStatus = $enforcer->effectiveAccountStatus()); ?>
                        <tr>
                            <td><div class="user-cell"><?php if (isset($component)) { $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-avatar','data' => ['user' => $enforcer]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($enforcer)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $attributes = $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $component = $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?><span><strong><?php echo e($enforcer->fullName); ?></strong><small><?php echo e($enforcer->username ? '@'.$enforcer->username : 'No username'); ?></small></span></div></td>
                            <td class="supervisor-roster-contact"><span><?php echo e($enforcer->email ?: 'No email recorded'); ?></span><small><?php echo e($enforcer->phoneNumber ?: 'No phone recorded'); ?></small></td>
                            <td class="supervisor-roster-area"><span class="<?php echo e(trim((string) $enforcer->area) === '' ? 'supervisor-area-pending' : ''); ?>"><?php echo e(trim((string) $enforcer->area) ?: 'Not assigned'); ?></span><small><?php echo e($enforcer->address ?: 'No address recorded'); ?></small></td>
                            <td><span class="supervisor-account-status <?php echo e($accountStatus === 'active' ? 'is-active' : ''); ?>"><?php echo e(ucfirst($accountStatus)); ?></span></td>
                            <td><a class="supervisor-home-link" href="<?php echo e(route('supervisor.enforcers.attendance', $enforcer)); ?>" aria-label="View attendance for <?php echo e($enforcer->fullName); ?>">Attendance <span aria-hidden="true">→</span></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <tr><td colspan="5"><div class="supervisor-home-empty"><strong>No enforcers assigned yet</strong><p>Add an available enforcer from My Team to get started.</p><a class="supervisor-home-button" href="<?php echo e(route('supervisor.team')); ?>">Manage my team <span aria-hidden="true">→</span></a></div></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="table-footer"><span>Showing <?php echo e($enforcers->firstItem() ?? 0); ?>–<?php echo e($enforcers->lastItem() ?? 0); ?> of <?php echo e(number_format($enforcerCount)); ?> enforcers</span><nav class="pagination-actions" aria-label="Team directory pages"><?php if($enforcers->onFirstPage()): ?><span class="page-button is-disabled" aria-disabled="true">Previous</span><?php else: ?><a class="page-button" href="<?php echo e($enforcers->previousPageUrl()); ?>">Previous</a><?php endif; ?> <span class="supervisor-page-number">Page <?php echo e($enforcers->currentPage()); ?> of <?php echo e(max(1, $enforcers->lastPage())); ?></span> <?php if($enforcers->hasMorePages()): ?><a class="page-button" href="<?php echo e($enforcers->nextPageUrl()); ?>">Next</a><?php else: ?><span class="page-button is-disabled" aria-disabled="true">Next</span><?php endif; ?></nav></div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.supervisor-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\supervisor\index.blade.php ENDPATH**/ ?>