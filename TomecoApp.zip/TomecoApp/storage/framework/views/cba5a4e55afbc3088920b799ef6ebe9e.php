

<?php
    $sectionTitle = match ($userSection) {
        'supervisors' => 'Supervisors',
        'enforcers' => 'Enforcers',
        'admins' => 'Admins',
    };
    $sectionRoute = match ($userSection) {
        'supervisors' => route('dashboard.users.supervisors'),
        'enforcers' => route('dashboard.users.enforcers'),
        'admins' => route('dashboard.users.admins'),
    };
    $managementSubject = match ($userSection) {
        'supervisors' => 'Supervisor',
        'enforcers' => 'Enforcer',
        'admins' => 'Admin',
    };
    $managementDescription = match ($userSection) {
        'supervisors' => 'Manage your supervisors and their account permissions here.',
        'enforcers' => 'Manage your enforcers and their account permissions here.',
        'admins' => 'Manage your administrators and their account permissions here.',
    };
    $shownFilters = array_intersect((array) request()->query('filters', []), ['joined']);
    $showJoinedFilter = $joinedFrom !== '' || $joinedTo !== '' || in_array('joined', $shownFilters, true);
?>
<?php $__env->startSection('title', $sectionTitle); ?>
<?php $__env->startSection('activePage', 'users-' . $userSection); ?>
<?php $__env->startSection('workspaceClass', 'workspace-full-width'); ?>
<?php $__env->startSection('headerSearch'); ?>
    <form class="search" method="GET" action="<?php echo e($sectionRoute); ?>" role="search">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>
        <input type="search" name="search" value="<?php echo e($search); ?>" placeholder="Search <?php echo e(strtolower($sectionTitle)); ?>">
        <input type="hidden" name="sort" value="<?php echo e($sort); ?>">
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head users-page-head">
        <div class="users-heading-copy"><h1><span class="management-subject"><?php echo e($managementSubject); ?></span> management <span class="users-heading-count"><?php echo e(number_format($users->total())); ?></span></h1><p class="page-description"><?php echo e($managementDescription); ?></p></div>
    </div>
    <?php if(session('success')): ?><div class="success-message" role="status"><?php echo e(session('success')); ?></div><?php endif; ?>
    <?php if(session('error')): ?><div class="success-message" role="alert"><?php echo e(session('error')); ?></div><?php endif; ?>

    <form id="userTableFilters" class="user-table-filters users-reference-toolbar" method="GET" action="<?php echo e($sectionRoute); ?>" role="search">
        <div class="users-toolbar-main">
            <div class="users-toolbar-actions">
                <label class="toolbar-search"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="8.5" cy="8.5" r="5"/><path d="m12.2 12.2 4 4"/></svg><span class="sr-only">Search users</span><input type="search" name="search" value="<?php echo e($search); ?>" placeholder="Search"></label>
                <label class="toolbar-customize"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="m10 2 6.5 3.8v7.5L10 18l-6.5-4.7V5.8z"/><circle cx="10" cy="10" r="2.3"/></svg><span class="sr-only">Sort users</span><select name="sort" onchange="this.form.submit()"><option value="latest" <?php if($sort === 'latest'): echo 'selected'; endif; ?>>Customize</option><option value="oldest" <?php if($sort === 'oldest'): echo 'selected'; endif; ?>>Oldest first</option><option value="name_asc" <?php if($sort === 'name_asc'): echo 'selected'; endif; ?>>Name A–Z</option><option value="name_desc" <?php if($sort === 'name_desc'): echo 'selected'; endif; ?>>Name Z–A</option></select></label>
                <button class="toolbar-outline-button" type="button">Export</button>
                <a class="toolbar-outline-button toolbar-add-user" href="<?php echo e(match ($userSection) {'supervisors' => route('dashboard.users.supervisors.create'),'enforcers' => route('dashboard.users.enforcers.create'),'admins' => route('dashboard.users.admins.create')}); ?>">Add User<svg viewBox="0 0 16 16" aria-hidden="true"><path d="m4 6 4 4 4-4"/></svg></a>
            </div>
        </div>
        <div class="users-toolbar-filters">
            <div class="active-user-filter user-dynamic-filter" data-user-filter="joined" <?php if(!$showJoinedFilter): ?> hidden <?php endif; ?>><input type="hidden" name="filters[]" value="joined" data-filter-state="joined" <?php if(!$showJoinedFilter): echo 'disabled'; endif; ?>><details class="violation-filter-menu joined-date-filter">
                    <summary class="users-filter-summary"><svg viewBox="0 0 20 20" aria-hidden="true"><rect x="3" y="4" width="14" height="13" rx="2"/><path d="M6 2v4M14 2v4M3 8h14"/></svg>Joined date<svg class="filter-chevron" viewBox="0 0 16 16" aria-hidden="true"><path d="m4 6 4 4 4-4"/></svg></summary>
                    <div class="violation-filter-panel">
                        <label><span>Joined from</span><input type="date" name="joined_from" value="<?php echo e($joinedFrom); ?>"></label>
                        <label><span>Joined to</span><input type="date" name="joined_to" value="<?php echo e($joinedTo); ?>" min="<?php echo e($joinedFrom); ?>"></label>
                        <button class="violation-filter-apply" type="submit">Apply filters</button>
                    </div>
                </details><button class="remove-user-filter" type="button" data-remove-user-filter="joined" aria-label="Remove joined date filter">&times;</button></div>
            <details class="add-filter-picker">
                <summary class="add-filter-button">+&nbsp; Add filter</summary>
                <div class="add-filter-options">
                    <button type="button" data-add-user-filter="joined"><svg viewBox="0 0 20 20" aria-hidden="true"><rect x="3" y="4" width="14" height="13" rx="2"/><path d="M6 2v4M14 2v4M3 8h14"/></svg>Joined date</button>
                </div>
            </details>
        </div>
    </form>

    <div class="table-card" aria-live="polite"><div class="table-scroll"><table class="users-table">
        <thead><tr>
            <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="7" r="3"/><path d="M4 17c.6-4 2.6-6 6-6s5.4 2 6 6"/></svg>Full name</span></th>
            <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 18s6-5.4 6-10a6 6 0 1 0-12 0c0 4.6 6 10 6 10z"/><circle cx="10" cy="8" r="2"/></svg>Home address</span></th>
            <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M6 2.8 8.3 7 6.8 8.5c1.1 2.3 2.4 3.6 4.7 4.7l1.5-1.5 4.2 2.3-.5 3c-.2.8-.8 1.2-1.6 1.2C8 17.7 2.3 12 1.8 4.9c0-.8.4-1.4 1.2-1.6z"/></svg>Phone number</span></th>
            <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="7" cy="7" r="3"/><path d="M2.5 16c.5-3 2-4.5 4.5-4.5s4 1.5 4.5 4.5M13 8h4M15 6v4"/></svg>Role</span></th>
            <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><rect x="3" y="4" width="14" height="13" rx="2"/><path d="M6 2v4M14 2v4M3 8h14"/></svg>Joined</span></th>
            <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="7"/><path d="m7 10 2 2 4-4"/></svg>Status</span></th>
            <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="7"/><circle cx="10" cy="10" r="2"/></svg>Actions</span></th>
        </tr></thead>
        <tbody>
        <?php $__empty_2 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listedUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
            <?php $listedName = $listedUser->fullName ?: 'Unnamed user'; $listedInitials = collect(explode(' ', $listedName))->filter()->map(fn($part) => strtoupper(substr($part, 0, 1)))->take(2)->join(''); ?>
            <tr>
                <td><div class="user-cell"><?php if (isset($component)) { $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-avatar','data' => ['user' => $listedUser]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($listedUser)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $attributes = $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $component = $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?><span><strong><a class="user-name-link" href="<?php echo e(match ($userSection) {'supervisors' => route('dashboard.users.supervisors.show', $listedUser),'enforcers' => route('dashboard.users.enforcers.show', $listedUser),'admins' => route('dashboard.users.admins.show', $listedUser)}); ?>"><?php echo e($listedName); ?></a></strong></span></div></td>
                <td class="location-cell"><span title="<?php echo e($listedUser->address); ?>"><?php echo e($listedUser->address ?: 'No address recorded'); ?></span></td>
                <td><?php echo e($listedUser->phoneNumber ?: '—'); ?></td><td class="user-role-text"><?php echo e($listedUser->isOfficer() ? 'Enforcer' : ucfirst($listedUser->role)); ?></td><td><?php echo e($listedUser->created_at?->format('M d, Y') ?? '—'); ?></td><?php $accountStatus = $listedUser->effectiveAccountStatus(); ?><td><span class="status-badge status-<?php echo e($accountStatus); ?>" title="<?php echo e(match ($accountStatus) {'active' => 'Able to log in.','pending' => 'Waiting for administrator activation.','inactive' => 'Deactivated or unused for a long time.','suspended' => 'Temporarily blocked.','banned' => 'Permanently blocked.'}); ?>"><i></i> <?php echo e(ucfirst($accountStatus)); ?></span></td>
                <td><div class="user-row-actions"><details class="user-actions-menu"><summary aria-label="Actions for <?php echo e($listedName); ?>" title="Actions">&#8942;</summary><div class="user-actions-dropdown"><a class="user-action action-edit" href="<?php echo e(route('dashboard.users.edit', ['user' => $listedUser, 'from' => $userSection])); ?>">Edit</a><form method="POST" action="<?php echo e(route('dashboard.users.destroy', $listedUser)); ?>" onsubmit="return confirm('Delete this user? This cannot be undone.')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><input type="hidden" name="user_section" value="<?php echo e($userSection); ?>"><button class="user-action action-delete" type="submit">Delete</button></form></div></details></div></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
            <tr><td colspan="7" class="empty-state"><strong><?php echo e($search !== '' ? 'No users found' : 'No registered users yet'); ?></strong><span><?php echo e($search !== '' ? 'Try a different name.' : 'No registered accounts yet.'); ?></span></td></tr>
        <?php endif; ?>
        </tbody>
    </table></div>
    <div class="table-footer"><span>Showing <?php echo e($users->firstItem() ?? 0); ?>–<?php echo e($users->lastItem() ?? 0); ?> of <?php echo e($users->total()); ?></span><div class="pagination-actions"><?php if($users->onFirstPage()): ?><span class="page-button is-disabled" aria-disabled="true">Previous</span><?php else: ?><a class="page-button" href="<?php echo e($users->previousPageUrl()); ?>">Previous</a><?php endif; ?> <?php if($users->hasMorePages()): ?><a class="page-button" href="<?php echo e($users->nextPageUrl()); ?>">Next</a><?php else: ?><span class="page-button is-disabled" aria-disabled="true">Next</span><?php endif; ?></div></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.querySelectorAll('[data-add-user-filter]').forEach(button => {
    button.addEventListener('click', () => {
        const filter = document.querySelector(`[data-user-filter="${button.dataset.addUserFilter}"]`);
        if (!filter) return;
        filter.hidden = false;
        const filterState = filter.querySelector('[data-filter-state]');
        if (filterState) filterState.disabled = false;
        button.closest('.add-filter-picker')?.removeAttribute('open');
        filter.querySelector('select, input')?.focus();
        filter.querySelector('details')?.setAttribute('open', '');
    });
});
document.querySelectorAll('[data-remove-user-filter]').forEach(button => {
    button.addEventListener('click', () => {
        if (button.dataset.removeUserFilter === 'joined') {
            const joinedFrom = document.querySelector('[name="joined_from"]');
            const joinedTo = document.querySelector('[name="joined_to"]');
            if (joinedFrom) joinedFrom.value = '';
            if (joinedTo) joinedTo.value = '';
        }
        const filterState = button.closest('[data-user-filter]')?.querySelector('[data-filter-state]');
        if (filterState) filterState.disabled = true;
        document.getElementById('userTableFilters')?.requestSubmit();
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\dashboard\users\role-list.blade.php ENDPATH**/ ?>