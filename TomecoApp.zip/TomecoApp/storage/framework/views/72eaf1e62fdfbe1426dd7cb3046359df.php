<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'page' => 'login']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'page' => 'login']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title); ?> | TOMECO</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
    <link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>">
    <script src="<?php echo e(asset('js/auth.js')); ?>" defer></script>
</head>
<body class="auth-page login-page auth-split-page auth-<?php echo e($page); ?>">
    <?php if (isset($component)) { $__componentOriginal4d6bed2ebceb29e0a9932fbda627422a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d6bed2ebceb29e0a9932fbda627422a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-loader','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-loader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d6bed2ebceb29e0a9932fbda627422a)): ?>
<?php $attributes = $__attributesOriginal4d6bed2ebceb29e0a9932fbda627422a; ?>
<?php unset($__attributesOriginal4d6bed2ebceb29e0a9932fbda627422a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d6bed2ebceb29e0a9932fbda627422a)): ?>
<?php $component = $__componentOriginal4d6bed2ebceb29e0a9932fbda627422a; ?>
<?php unset($__componentOriginal4d6bed2ebceb29e0a9932fbda627422a); ?>
<?php endif; ?>
    <main class="auth-split-shell">
        <aside class="auth-showcase" aria-label="About TOMECO">
            <div class="auth-showcase-copy">
                <p class="auth-eyebrow">Tacloban City · Traffic operations</p>
                <h2><?php echo e($page === 'register' ? 'Better coordination.' : 'Safer streets.'); ?><br>
                    <?php echo e($page === 'register' ? 'One connected team.' : 'Smarter operations.'); ?></h2>
                <p class="auth-showcase-description"><?php echo e($page === 'register'
                    ? 'Bring your people, records, and daily traffic operations together in one place.'
                    : 'Your team, traffic records, and daily operations in one place.'); ?></p>
            </div>
            <div class="auth-showcase-footer">
                <span>Traffic Operation Management<br>Enforcement and Control Office</span>
                <span>Tacloban City<br>Philippines</span>
            </div>
        </aside>
        <section class="auth-form-panel" aria-labelledby="auth-heading">
            <div class="auth-panel-inner">
                <div class="auth-brand auth-brand-with-logo">
                    <img src="<?php echo e(asset('images/Tomeco_icon.jpg')); ?>" width="48" height="48" alt="TOMECO official seal">
                    <span><strong>TOMECO</strong><small>Traffic Operations · Tacloban City</small></span>
                </div>
                <div class="auth-panel-content"><?php echo e($slot); ?></div>
                <p class="auth-panel-footer">Traffic Operation Management Enforcement and Control Office Tacloban</p>
            </div>
        </section>
    </main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\components\auth-layout.blade.php ENDPATH**/ ?>