<?php $__env->startSection('title', 'Analytics Reports'); ?>
<?php $__env->startSection('activePage', 'analytics'); ?>
<?php $__env->startSection('workspaceClass', 'analytics-reports'); ?>
<?php $__env->startSection('headerSearch'); ?><span class="section-label">Reports &amp; insights</span><?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/analytics-reports.css')); ?>?v=<?php echo e(filemtime(public_path('css/analytics-reports.css'))); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-head analytics-page-head">
    <div><p class="eyebrow">Traffic operations / Analytics</p><h1>Analytics Reports</h1><p class="page-description">See ticket trends, track unpaid fines, and plan enforcement activity.</p></div>
    <button type="button" class="analytics-button" id="analyticsPrint"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 8V3h10v5M7 17H4V9h16v8h-3M7 14h10v7H7z"/></svg>Print report</button>
</div>
<section class="analytics-filter-card" aria-label="Report filters">
<form method="GET" action="<?php echo e(route('dashboard.analytics')); ?>" id="analyticsFilters" novalidate aria-describedby="analyticsAutoFilterHint">
    <span class="sr-only" id="analyticsAutoFilterHint">Filters update the report automatically when changed. Custom dates update after both dates are valid.</span>
    <input type="hidden" name="view" value="<?php echo e(in_array(request('view'), ['overall', 'paid', 'unpaid']) ? request('view') : 'overall'); ?>">
    <input type="hidden" name="chart" value="<?php echo e(request('chart') === 'bar' ? 'bar' : 'line'); ?>">
    <div class="analytics-filter-fields">
        <label class="analytics-field" for="analyticsReportPeriod"><span>Report period</span><select id="analyticsReportPeriod" name="summary">
            <?php $__currentLoopData = ['today' => 'Today', 'week' => 'This week', 'month' => 'This month', 'year' => 'This year', 'all' => 'All time', 'custom' => 'Custom dates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value); ?>" <?php if(($filterErrors->has('date_from') || $filterErrors->has('date_to') ? 'custom' : $summaryRange) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></label>
        <?php $__currentLoopData = ['date_from' => ['From', $dateFrom], 'date_to' => ['To', $dateTo]]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => [$label, $value]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label class="analytics-field" for="<?php echo e($name); ?>"><span><?php echo e($label); ?></span><input type="date" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>" max="<?php echo e($generatedAt->format('Y-m-d')); ?>" aria-invalid="<?php echo e($filterErrors->has($name) ? 'true' : 'false'); ?>" <?php if($filterErrors->has($name)): ?> aria-describedby="<?php echo e($name); ?>-error" <?php endif; ?>>
        <?php if($filterErrors->has($name)): ?><small class="analytics-field-error" id="<?php echo e($name); ?>-error"><?php echo e($filterErrors->first($name)); ?></small><?php endif; ?></label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <label class="analytics-field" for="analyticsStatus"><span>Payment status</span><select id="analyticsStatus" name="status"><option value="">All statuses</option><option value="unpaid" <?php if($statusFilter === 'unpaid'): echo 'selected'; endif; ?>>Unpaid</option><option value="paid" <?php if($statusFilter === 'paid'): echo 'selected'; endif; ?>>Paid</option></select></label>
        <label class="analytics-field" for="analyticsVehicle"><span>Vehicle type</span><select id="analyticsVehicle" name="vehicle"><option value="">All vehicles</option><?php if($vehicleFilter !== '' && !$vehicleOptions->contains($vehicleFilter)): ?><option value="<?php echo e($vehicleFilter); ?>" selected><?php echo e($vehicleFilter); ?> (not recorded)</option><?php endif; ?> <?php $__currentLoopData = $vehicleOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($option); ?>" <?php if($vehicleFilter === $option): echo 'selected'; endif; ?>><?php echo e($option); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
        <div class="analytics-filter-actions"><a class="analytics-button analytics-reset" href="<?php echo e(route('dashboard.analytics')); ?>">Reset</a></div>
    </div>
    <p id="analyticsFilterFeedback" class="analytics-filter-error" role="status" hidden></p>
    <noscript><button type="submit" class="analytics-button">Update report</button></noscript>
    <?php if($filterErrors->isNotEmpty()): ?><p class="analytics-filter-error" role="alert" tabindex="-1">Some filters could not be applied. Correct the highlighted dates or choose another report period. <?php echo e($filterErrors->first('summary')); ?> <?php echo e($filterErrors->first('status')); ?> <?php echo e($filterErrors->first('vehicle')); ?></p><?php endif; ?>
</form>
</section>
<div class="analytics-report-context"><div><strong><?php echo e($rangeStart->format('M d, Y')); ?> – <?php echo e($rangeEnd->format('M d, Y')); ?></strong><span><?php echo e(ucfirst($summaryDescription)); ?><?php echo e($statusFilter ? ' · '.ucfirst($statusFilter) : ' · All statuses'); ?><?php echo e($vehicleFilter ? ' · '.$vehicleFilter : ' · All vehicles'); ?></span></div><span>Generated <?php echo e($generatedAt->format('M d, Y · h:i A')); ?> PHT</span></div>
<div class="analytics-kpi-grid" aria-label="Ticket summary">
    <article class="analytics-kpi is-total"><span>Tickets issued</span><strong><?php echo e(number_format($summary['total'])); ?></strong><small><?php if($previousTotal === null): ?>All recorded ticket history <?php elseif($ticketChange !== null): ?><?php echo e($ticketChange > 0 ? '+' : ''); ?><?php echo e(number_format($ticketChange, 1)); ?>% vs previous period <?php elseif($summary['total']): ?><?php echo e(number_format($summary['total'])); ?> tickets; none in previous period <?php else: ?> No tickets in either period <?php endif; ?></small></article>
    <article class="analytics-kpi"><span>Paid tickets</span><strong><?php echo e(number_format($summary['resolved'])); ?></strong><small><?php echo e($settlementRate); ?>% of selected tickets</small></article>
    <article class="analytics-kpi"><span>Unpaid tickets</span><strong><?php echo e(number_format($summary['pending'])); ?></strong><small>Current status of selected tickets</small></article>
    <article class="analytics-kpi"><span>Outstanding fines</span><strong class="analytics-money">₱<?php echo e(number_format($outstandingFines, 2)); ?></strong><small>Assessed on selected unpaid tickets</small></article>
</div>
<?php if($previousTotal !== null): ?><p class="analytics-comparison-note">Comparison: <?php echo e($previousStart->format('M d, Y h:i A')); ?> – <?php echo e($previousEnd->format('M d, Y h:i A')); ?> PHT · Equal elapsed duration with the same filters.</p><?php endif; ?>
<div class="analytics-main-grid">
<section class="analytics-panel analytics-trend-panel">
    <div class="analytics-panel-heading"><div><h2>Ticket activity</h2><p><?php echo e(['hour' => 'Hourly', 'day' => 'Daily', 'month' => 'Monthly', 'year' => 'Yearly'][$granularity]); ?> ticket counts for the selected period</p></div><span class="analytics-label"><?php echo e(number_format($summary['total'])); ?> tickets</span></div>
    <div class="analytics-chart-toolbar"><label class="analytics-field" for="analyticsSeriesFilter"><span>Show</span><select id="analyticsSeriesFilter"><option value="overall">All tickets</option><option value="paid">Paid tickets</option><option value="unpaid">Unpaid tickets</option></select></label><label class="analytics-field" for="analyticsChartType"><span>Chart type</span><select id="analyticsChartType"><option value="line">Line chart</option><option value="bar">Bar chart</option></select></label></div>
    <div class="analytics-chart-frame"><canvas id="analyticsChart" role="img" aria-label="Ticket activity. The same counts are available in the activity data table below."></canvas></div>
    <p id="analyticsChartFeedback" class="analytics-inline-note" role="status" hidden>The chart could not load. Use the activity data table below or refresh to try again.</p>
    <noscript><p class="analytics-inline-note">Open View activity data below to read the ticket counts, or enable JavaScript to use the chart.</p></noscript>
    <?php if(!$summary['total']): ?><p class="analytics-inline-note">No tickets recorded during this period. Choose a longer range or reset the filters.</p><?php endif; ?>
    <details class="analytics-data-disclosure"><summary>View activity data</summary><div class="analytics-table-scroll" tabindex="0" role="region" aria-label="Activity data"><table><thead><tr><th scope="col">Period (PHT)</th><th scope="col">Tickets issued</th><th scope="col">Paid</th><th scope="col">Unpaid</th></tr></thead><tbody><?php $__currentLoopData = $dailyViolations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bucket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($bucket['date']); ?></td><td><?php echo e(number_format($bucket['value'])); ?></td><td><?php echo e(number_format($bucket['paid'])); ?></td><td><?php echo e(number_format($bucket['unpaid'])); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table></div></details>
    <p class="analytics-inline-note">Grouped by issue date. Paid and unpaid reflect current ticket status, not payment dates.</p>
</section>
<section class="analytics-panel analytics-settlement-panel">
    <div class="analytics-panel-heading"><div><h2>Ticket settlement</h2><p>Current payment status</p></div></div>
    <div class="analytics-settlement-number"><strong><?php echo e($settlementRate); ?><span>%</span></strong><p>of selected tickets are paid</p></div><div class="analytics-settlement-track" aria-hidden="true"><i style="width:<?php echo e($settlementRate); ?>%"></i></div>
    <dl class="analytics-settlement-details"><div><dt><i class="analytics-dot is-paid" aria-hidden="true"></i>Paid</dt><dd><?php echo e(number_format($summary['resolved'])); ?></dd></div><div><dt><i class="analytics-dot" aria-hidden="true"></i>Unpaid</dt><dd><?php echo e(number_format($summary['pending'])); ?></dd></div><div><dt>Total assessed fines</dt><dd>₱<?php echo e(number_format($assessedFines, 2)); ?></dd></div><div><dt>Enforcers issuing tickets</dt><dd><?php echo e(number_format($activeEnforcers)); ?></dd></div></dl>
    <p class="analytics-inline-note">Fine amounts are assessed values. Collections by payment date require payment records.</p>
</section>
</div>
<section class="analytics-panel analytics-violation-table">
    <div class="analytics-panel-heading"><div><h2>Most recorded violations</h2><p>Ranked by tickets issued in the selected period</p></div><span class="analytics-label"><?php echo e(number_format($violationTrends->count())); ?> violation types</span></div>
    <div class="analytics-table-scroll" tabindex="0" role="region" aria-label="Violation rankings, scroll horizontally for more columns"><table><thead><tr><th scope="col">Violation type</th><th scope="col">Tickets issued</th><th scope="col">Share of tickets</th><th scope="col">Unpaid</th><th scope="col">Paid</th></tr></thead><tbody>
        <?php $__empty_2 = true; $__currentLoopData = $violationPage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $violation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
        <?php ($share = $periodViolationTotal ? round($violation->total / $periodViolationTotal * 100, 1) : 0); ?>
        <tr><td><?php echo e($violation->violation_type ?: 'Unrecorded violation type'); ?></td><td><?php echo e(number_format($violation->total)); ?></td><td><span class="analytics-share"><span><?php echo e($share); ?>%</span><span class="analytics-share-track" aria-hidden="true"><i style="width:<?php echo e($share); ?>%"></i></span></span></td><td><?php echo e(number_format($violation->total - $violation->resolved)); ?></td><td><?php echo e(number_format($violation->resolved)); ?></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?><tr><td colspan="5"><div class="analytics-empty"><strong>No tickets recorded for these filters</strong><p>Choose a longer range or reset the filters to see violation rankings.</p></div></td></tr><?php endif; ?>
    </tbody></table></div>
    <div class="analytics-table-footer"><span>All recorded violation types · <?php echo e($violationPage->firstItem() ?? 0); ?>–<?php echo e($violationPage->lastItem() ?? 0); ?> of <?php echo e($violationPage->total()); ?></span><?php if($violationPage->hasPages()): ?><nav aria-label="Violation ranking pages"><?php if($violationPage->previousPageUrl()): ?><a class="analytics-button" href="<?php echo e($violationPage->previousPageUrl()); ?>">Previous</a><?php endif; ?><span>Page <?php echo e($violationPage->currentPage()); ?> of <?php echo e($violationPage->lastPage()); ?></span><?php if($violationPage->nextPageUrl()): ?><a class="analytics-button" href="<?php echo e($violationPage->nextPageUrl()); ?>">Next</a><?php endif; ?></nav><?php endif; ?></div>
    <p class="analytics-inline-note">A ticket can include several violation types, so shares may total more than 100%. <?php echo e(number_format($otherViolationTickets)); ?> tickets have no recorded violation group.</p>
    <?php if($violationPage->hasPages()): ?><p class="analytics-print-note">This printout includes violation ranking page <?php echo e($violationPage->currentPage()); ?> of <?php echo e($violationPage->lastPage()); ?>.</p><?php endif; ?>
</section>
<div class="analytics-breakdown-grid">
<section class="analytics-panel">
    <div class="analytics-panel-heading"><div><h2>Vehicle breakdown</h2><p>Most Common Vehicle Types</p></div></div>
    <div class="analytics-ranked-list"><?php $__empty_2 = true; $__currentLoopData = $vehicleTrends->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?><div class="analytics-ranked-item"><div><span><?php echo e($item->vehicle_type ?: 'Vehicle type not recorded'); ?></span><strong><?php echo e(number_format($item->total)); ?> <small><?php echo e($periodViolationTotal ? round($item->total / $periodViolationTotal * 100, 1) : 0); ?>%</small></strong></div><div class="analytics-rank-track" aria-hidden="true"><i style="width:<?php echo e($periodViolationTotal ? $item->total / $periodViolationTotal * 100 : 0); ?>%"></i></div></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?><div class="analytics-empty"><strong>No vehicle types recorded</strong><p>Choose a longer range or reset the filters.</p></div><?php endif; ?></div>
    <?php if($vehicleTrends->count() > 5): ?><p class="analytics-inline-note">Other vehicle types: <?php echo e(number_format($vehicleTrends->skip(5)->sum('total'))); ?> tickets.</p><?php endif; ?>
</section>
<section class="analytics-panel">
    <div class="analytics-panel-heading"><div><h2>Recorded locations</h2><p>Top 5 locations by issued tickets</p></div></div>
    <div class="analytics-ranked-list"><?php $__empty_2 = true; $__currentLoopData = $locationTrends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?><div class="analytics-location-row"><span class="analytics-rank-number"><?php echo e($loop->iteration); ?></span><span><?php echo e($item->label); ?></span><strong><?php echo e(number_format($item->total)); ?></strong></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?><div class="analytics-empty"><strong>No location activity</strong><p>Choose a period with recorded tickets.</p></div><?php endif; ?></div>
    <p class="analytics-inline-note">Based on ticket location text. Different spellings may appear separately.</p>
</section>
</div>
<div class="analytics-breakdown-grid">
<section class="analytics-panel">
    <div class="analytics-panel-heading"><div><h2>Unpaid ticket aging</h2><p>Age today of unpaid tickets issued in this period</p></div></div>
    <div class="analytics-table-scroll" tabindex="0" role="region" aria-label="Unpaid ticket aging"><table><thead><tr><th scope="col">Time since issue</th><th scope="col">Tickets</th><th scope="col">Outstanding fines</th></tr></thead><tbody><?php $__currentLoopData = $aging; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $band): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($band['label']); ?></td><td><?php echo e(number_format($band['total'])); ?></td><td>₱<?php echo e(number_format($band['amount'], 2)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table></div>
    <p class="analytics-inline-note">Age is measured in calendar days as of <?php echo e($generatedAt->format('M d, Y')); ?> PHT. These bands do not indicate legal due dates.</p>
</section>
<section class="analytics-panel">
    <div class="analytics-panel-heading"><div><h2>Enforcer activity</h2><p>Top 5 enforcers by issued tickets</p></div><span class="analytics-label"><?php echo e($activeEnforcers); ?> issuing</span></div>
    <div class="analytics-ranked-list"><?php $__empty_2 = true; $__currentLoopData = $enforcerTrends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?><div class="analytics-location-row"><span class="analytics-rank-number"><?php echo e($loop->iteration); ?></span><span><?php echo e($item->enforcer?->fullName ?: 'Enforcer not recorded'); ?></span><strong><?php echo e(number_format($item->total)); ?></strong></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?><div class="analytics-empty"><strong>No enforcer activity</strong><p>No tickets linked to enforcers in this period.</p></div><?php endif; ?></div>
    <p class="analytics-inline-note">Ticket volume describes recorded activity. Assignment and time worked affect these counts.</p>
</section>
</div>
<footer class="analytics-report-footnote">TOMECO · Traffic operations report · Counts reflect recorded tickets and their current status.</footer>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="application/json" id="analyticsChartData"><?php echo json_encode($dailyViolations->values(), 15, 512) ?></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
<script src="<?php echo e(asset('js/analytics-reports.js')); ?>?v=<?php echo e(filemtime(public_path('js/analytics-reports.js'))); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\dashboard\analytics.blade.php ENDPATH**/ ?>