

<?php $__env->startSection('title', 'My Profile'); ?>
<?php $__env->startSection('activePage', 'profile'); ?>
<?php $__env->startSection('workspaceClass', 'profile-workspace'); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/profile.css')); ?>?v=<?php echo e(filemtime(public_path('css/profile.css'))); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head profile-page-heading">
        <div><p class="eyebrow">Account settings</p><h1>My Profile</h1><p class="page-description">Manage your personal details, photo, and password.</p></div>
    </div>
    <?php if(session('success')): ?>
        <div class="success-message" role="status"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="profile-shell">
        <form id="profileForm" novalidate method="POST" enctype="multipart/form-data" action="<?php echo e(route('profile.update')); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <section class="profile-identity" aria-labelledby="profileName">
                <?php if (isset($component)) { $__componentOriginal5ec0b300512c458ac171487d7f2e54ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ec0b300512c458ac171487d7f2e54ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.profile-photo-field','data' => ['user' => $profileUser]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile-photo-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($profileUser)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ec0b300512c458ac171487d7f2e54ae)): ?>
<?php $attributes = $__attributesOriginal5ec0b300512c458ac171487d7f2e54ae; ?>
<?php unset($__attributesOriginal5ec0b300512c458ac171487d7f2e54ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ec0b300512c458ac171487d7f2e54ae)): ?>
<?php $component = $__componentOriginal5ec0b300512c458ac171487d7f2e54ae; ?>
<?php unset($__componentOriginal5ec0b300512c458ac171487d7f2e54ae); ?>
<?php endif; ?>
                <div class="profile-identity-copy">
                    <span class="profile-role"><?php echo e($profileUser->isOfficer() ? 'Enforcer' : ucfirst($profileUser->role)); ?></span>
                    <h2 id="profileName"><?php echo e($profileUser->fullName); ?></h2>
                    <p><?php echo e($profileUser->email); ?></p>
                    <?php if($profileUser->username): ?><span class="profile-username"><?php echo e('@'.$profileUser->username); ?></span><?php endif; ?>
                </div>
            </section>
            <div class="profile-content-grid">
            <section class="profile-section" aria-labelledby="personalDetailsTitle">
                <header class="profile-section-heading"><h2 id="personalDetailsTitle">Personal information</h2><p>Keep your contact details up to date.</p></header>
                <div class="user-form-grid">
                <div class="form-field"><label for="firstName">First name <b>Required</b></label><input id="firstName"
                        name="firstName" autocomplete="given-name" value="<?php echo e(old('firstName', $profileUser->firstName)); ?>" required>
                    <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="middleName">Middle name <em>Optional</em></label><input id="middleName"
                        name="middleName" value="<?php echo e(old('middleName', $profileUser->middleName)); ?>">
                    <?php $__errorArgs = ['middleName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="lastName">Last name <b>Required</b></label><input id="lastName"
                        name="lastName" autocomplete="family-name" value="<?php echo e(old('lastName', $profileUser->lastName)); ?>" required>
                    <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="nameExtension">Name extension <em>Optional</em></label><input
                        id="nameExtension" name="nameExtension"
                        value="<?php echo e(old('nameExtension', $profileUser->nameExtension)); ?>">
                    <?php $__errorArgs = ['nameExtension'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="username">Username <b>Required</b></label><input id="username"
                        name="username" value="<?php echo e(old('username', $profileUser->username)); ?>" required>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="address">Address <b>Required</b></label><input id="address"
                        name="address" value="<?php echo e(old('address', $profileUser->address)); ?>" required>
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="phoneNumber">Phone number <b>Required</b></label><input id="phoneNumber"
                        name="phoneNumber" type="tel" value="<?php echo e(old('phoneNumber', $profileUser->phoneNumber)); ?>"
                        pattern="09[0-9]{9}" maxlength="11" required>
                    <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="email">Email address <b>Required</b></label><input id="email"
                        name="email" autocomplete="email" type="email" value="<?php echo e(old('email', $profileUser->email)); ?>" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                </div>
            </section>
            <aside class="profile-section profile-account" aria-labelledby="accountDetailsTitle">
                <header class="profile-section-heading"><h2 id="accountDetailsTitle">Account details</h2><p>Your organization manages your role and assignment.</p></header>
                <dl>
                    <div><dt>Role</dt><dd><?php echo e($profileUser->isOfficer() ? 'Enforcer' : ucfirst($profileUser->role)); ?></dd></div>
                    <div><dt>Member since</dt><dd><?php echo e($profileUser->created_at?->format('M d, Y') ?? '—'); ?></dd></div>
                    <?php if($profileUser->isOfficer()): ?>
                        <div><dt>Supervisor</dt><dd><?php echo e($profileUser->supervisor?->fullName ?? 'Unassigned'); ?></dd></div>
                        <div><dt>Assigned area</dt><dd><?php echo e($profileUser->area ?: 'Unassigned'); ?></dd></div>
                    <?php endif; ?>
                </dl>
                <p class="profile-account-note">Contact an administrator if your account assignment needs to change.</p>
            </aside>
            <section class="profile-section profile-security" aria-labelledby="securityTitle">
                <header class="profile-section-heading"><h2 id="securityTitle">Password &amp; security</h2><p>Leave these fields empty to keep your current password.</p></header>
                <div class="user-form-grid">
                <div class="form-field"><label for="password">New password <em>Optional</em></label><input id="password"
                        name="password" type="password" autocomplete="new-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="password_confirmation">Confirm password <em>Optional</em></label><input
                        id="password_confirmation" name="password_confirmation" type="password" autocomplete="new-password">
                </div>
            </div>
            </section>
            </div>
            <div class="user-form-actions profile-form-actions"><a class="page-button" href="<?php echo e(route('dashboard')); ?>">Cancel</a><button
                    type="submit">Save profile</button></div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(auth()->user()->isSupervisor() ? 'layouts.supervisor-dashboard' : 'layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\profile\edit.blade.php ENDPATH**/ ?>