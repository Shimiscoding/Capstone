<?php $__env->startSection('title', 'Audit Log'); ?>
<?php $__env->startSection('activePage', 'audit-logs'); ?>
<?php $__env->startSection('workspaceClass', 'workspace-full-width'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $displayValue = static function (mixed $value): string {
            if ($value === null || $value === '') return 'Empty';
            if (is_bool($value)) return $value ? 'Yes' : 'No';
            if (is_array($value)) return collect($value)->map(fn ($item) => is_scalar($item) ? (string) $item : json_encode($item))->join(', ');
            return (string) $value;
        };
        $fieldLabel = static fn (string $field): string => \Illuminate\Support\Str::headline($field);
        $recordType = static fn (string $type): string => match (class_basename($type)) {
            'User' => 'user account',
            'Violation' => 'violation ticket',
            'Setting' => 'setting',
            'EnforcerAttendance' => 'enforcer attendance',
            'SupervisorAttendance' => 'supervisor attendance',
            default => strtolower(\Illuminate\Support\Str::headline(class_basename($type))),
        };
    ?>
    <div class="page-head users-page-head">
        <div>
            <p class="eyebrow">Administrator activity review</p>
            <h1>Audit Log</h1>
            <p class="page-description">Review recorded events across the website and mobile app. Filter by the role of the person who performed the action.</p>
        </div>
        <div class="user-count"><?php echo e(number_format($logs->total())); ?> <?php echo e(\Illuminate\Support\Str::plural('entry', $logs->total())); ?></div>
    </div>

    <form class="user-table-filters users-reference-toolbar audit-log-toolbar" method="GET" action="<?php echo e(route('dashboard.audit-logs')); ?>" role="search" novalidate>
        <div class="users-toolbar-main"><div class="users-toolbar-actions">
            <label class="toolbar-search"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="8.5" cy="8.5" r="5"/><path d="m12.2 12.2 4 4"/></svg><span class="sr-only">Search audit log</span><input type="search" name="search" value="<?php echo e($search); ?>" placeholder="Search user or record"><button type="button" data-clear-audit-search aria-label="Clear audit log search" <?php if($search === ''): ?> hidden <?php endif; ?>>&times;</button></label>
            <label class="audit-event-filter"><span class="sr-only">Filter by actor role</span><select name="actor_role" onchange="this.form.submit()"><option value="">All roles</option><?php $__currentLoopData = \App\Models\User::ROLES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($role); ?>" <?php if($actorRole === $role): echo 'selected'; endif; ?>><?php echo e($role === \App\Models\User::ROLE_OFFICER ? 'Enforcer' : ucfirst($role)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <label class="audit-event-filter"><span class="sr-only">Filter by activity</span><select name="event" onchange="this.form.submit()"><option value="">All activity</option><option value="created" <?php if($event === 'created'): echo 'selected'; endif; ?>>Created</option><option value="updated" <?php if($event === 'updated'): echo 'selected'; endif; ?>>Updated</option><option value="deleted" <?php if($event === 'deleted'): echo 'selected'; endif; ?>>Deleted</option></select></label>
            <button class="toolbar-outline-button" type="submit">Search</button>
            <?php if($search !== '' || $event !== '' || $actorRole !== ''): ?><a class="toolbar-outline-button" href="<?php echo e(route('dashboard.audit-logs')); ?>">Reset filters</a><?php endif; ?>
        </div></div>
    </form>

    <section class="table-card audit-log-card">
        <div class="table-scroll">
            <table class="users-table audit-log-table">
                <thead><tr><th>Date and time</th><th>Changed by</th><th>Activity</th><th>What they did</th><th>Record</th></tr></thead>
                <tbody>
                <?php $__empty_2 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <?php
                        $snapshotKey = match ($log->event) { 'created' => 'new', 'deleted' => 'old', default => null };
                        $visibleChanges = collect($log->changes ?? [])->filter(static function ($change) use ($snapshotKey): bool {
                            if ($snapshotKey === null) return true;
                            $value = $change[$snapshotKey] ?? null;
                            return $value !== null && $value !== '' && $value !== [];
                        });
                    ?>
                    <tr>
                        <td><time datetime="<?php echo e($log->created_at->toIso8601String()); ?>"><strong><?php echo e($log->created_at->format('M d, Y')); ?></strong><small><?php echo e($log->created_at->format('h:i:s A')); ?></small></time></td>
                        <td><div class="audit-actor"><div class="audit-actor-name"><strong><?php echo e($log->actor_name ?: $log->user?->fullName ?: 'System'); ?></strong><?php if($log->actor_role): ?><span class="role-badge"><?php echo e($log->actor_role === \App\Models\User::ROLE_OFFICER ? 'Enforcer' : ucfirst($log->actor_role)); ?></span><?php endif; ?></div><small><?php echo e($log->user?->email ?: 'Automated or archived account'); ?></small></div></td>
                        <td><span class="audit-event is-<?php echo e($log->event); ?>"><?php echo e(ucfirst($log->event)); ?></span></td>
                        <td class="audit-action-cell">
                            <strong><?php echo e(ucfirst($log->event)); ?> <?php echo e($recordType($log->auditable_type)); ?></strong>
                            <?php if($log->event === 'updated' && count($log->changes ?? []) > 0): ?>
                                <small>Changed <?php echo e(collect(array_keys($log->changes))->map($fieldLabel)->join(', ')); ?></small>
                            <?php else: ?>
                                <small><?php echo e($log->subject_label); ?></small>
                            <?php endif; ?>
                            <?php if($visibleChanges->isNotEmpty()): ?>
                                <details class="audit-change-details">
                                    <summary>View <?php echo e($visibleChanges->count()); ?> <?php echo e(\Illuminate\Support\Str::plural($snapshotKey === null ? 'change' : 'recorded field', $visibleChanges->count())); ?></summary>
                                    <div class="audit-change-list <?php echo e($snapshotKey !== null ? 'is-snapshot' : ''); ?>">
                                        <?php $__currentLoopData = $visibleChanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $change): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div>
                                                <strong><?php echo e($fieldLabel($field)); ?></strong>
                                                <?php if($field === 'signature'): ?>
                                                    <span class="audit-new-value">Signature <?php echo e($log->event === 'deleted' ? 'removed' : 'recorded'); ?></span>
                                                <?php elseif($snapshotKey !== null): ?>
                                                    <span class="<?php echo e($log->event === 'deleted' ? 'audit-old-value' : 'audit-new-value'); ?>"><?php echo e($displayValue($change[$snapshotKey])); ?></span>
                                                <?php else: ?>
                                                    <span class="audit-old-value"><?php echo e($displayValue($change['old'] ?? null)); ?></span>
                                                    <i aria-hidden="true">&rarr;</i>
                                                    <span class="audit-new-value"><?php echo e($displayValue($change['new'] ?? null)); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </details>
                            <?php endif; ?>
                        </td>
                        <td><strong><?php echo e($log->subject_label ?: class_basename($log->auditable_type).' #'.$log->auditable_id); ?></strong><small><?php echo e(class_basename($log->auditable_type)); ?></small></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                    <tr><td colspan="5" class="empty-state"><strong>No activity found</strong><span><?php echo e($search !== '' || $event !== '' || $actorRole !== '' ? 'Try another search or reset the filters to see more events.' : 'Recorded changes will appear here as people use the website and mobile app.'); ?></span></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($logs->hasPages()): ?>
            <div class="table-footer">
                <span>Showing <?php echo e($logs->firstItem()); ?>&ndash;<?php echo e($logs->lastItem()); ?> of <?php echo e($logs->total()); ?></span>
                <nav class="pagination-actions" aria-label="Audit log pagination">
                    <?php if($logs->onFirstPage()): ?>
                        <span class="page-button is-disabled" aria-disabled="true">Previous</span>
                    <?php else: ?>
                        <a class="page-button" href="<?php echo e($logs->previousPageUrl()); ?>" rel="prev">Previous</a>
                    <?php endif; ?>

                    <?php if($logs->hasMorePages()): ?>
                        <a class="page-button" href="<?php echo e($logs->nextPageUrl()); ?>" rel="next">Next</a>
                    <?php else: ?>
                        <span class="page-button is-disabled" aria-disabled="true">Next</span>
                    <?php endif; ?>
                </nav>
            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/audit-logs.js')); ?>?v=<?php echo e(filemtime(public_path('js/audit-logs.js'))); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\dashboard\audit-logs.blade.php ENDPATH**/ ?>