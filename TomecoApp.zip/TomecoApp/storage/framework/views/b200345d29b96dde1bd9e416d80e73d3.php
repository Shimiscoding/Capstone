<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> | TOMECO</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>?v=<?php echo e(filemtime(public_path('css/dashboard.css'))); ?>">
    <link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <?php if (isset($component)) { $__componentOriginal4d6bed2ebceb29e0a9932fbda627422a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d6bed2ebceb29e0a9932fbda627422a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-loader','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-loader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d6bed2ebceb29e0a9932fbda627422a)): ?>
<?php $attributes = $__attributesOriginal4d6bed2ebceb29e0a9932fbda627422a; ?>
<?php unset($__attributesOriginal4d6bed2ebceb29e0a9932fbda627422a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d6bed2ebceb29e0a9932fbda627422a)): ?>
<?php $component = $__componentOriginal4d6bed2ebceb29e0a9932fbda627422a; ?>
<?php unset($__componentOriginal4d6bed2ebceb29e0a9932fbda627422a); ?>
<?php endif; ?>
    <?php
        $user = auth()->user();
        $initials = collect(explode(' ', $user->fullName ?: 'User'))
            ->filter()
            ->map(fn($part) => strtoupper(substr($part, 0, 1)))
            ->take(2)
            ->join('');
        $activePage = trim($__env->yieldContent('activePage', 'dashboard'));
    ?>

    <div class="app-frame">
        <header class="topbar">
            <div class="brand-switcher">
                <img class="brand-logo" src="<?php echo e(asset('images/favicon.ico')); ?>" alt="TOMECO logo">
                <div class="brand-title"><strong>TOMECO</strong><span>Traffic Operations</span></div>
                <button class="plain-button sidebar-toggle" id="sidebarToggle" type="button" aria-label="Hide sidebar"
                    aria-controls="dashboardSidebar" aria-expanded="true">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor"
                        stroke-width="2" stroke-linecap="round">
                        <path d="M4 7h16" />
                        <path d="M4 12h16" />
                        <path d="M4 17h16" />
                    </svg>
                </button>
            </div>

            <?php if (! empty(trim($__env->yieldContent('headerSearch')))): ?>
                <?php echo $__env->yieldContent('headerSearch'); ?>
            <?php elseif($user->isCashier()): ?>
                <span class="section-label">Cashier workspace</span>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginala1fe0af09feec53b7c7ea8a1ff65c2c9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1fe0af09feec53b7c7ea8a1ff65c2c9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1fe0af09feec53b7c7ea8a1ff65c2c9)): ?>
<?php $attributes = $__attributesOriginala1fe0af09feec53b7c7ea8a1ff65c2c9; ?>
<?php unset($__attributesOriginala1fe0af09feec53b7c7ea8a1ff65c2c9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1fe0af09feec53b7c7ea8a1ff65c2c9)): ?>
<?php $component = $__componentOriginala1fe0af09feec53b7c7ea8a1ff65c2c9; ?>
<?php unset($__componentOriginala1fe0af09feec53b7c7ea8a1ff65c2c9); ?>
<?php endif; ?>
            <?php endif; ?>

            <div class="topbar-spacer"></div>
            <?php if (! ($user->isCashier())): ?>
                <?php echo $__env->make('dashboard.partials.notifications', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
            <div class="profile-menu" id="profileMenu">
                <button class="profile" id="profileMenuToggle" type="button" aria-label="Open account menu"
                    aria-haspopup="menu" aria-expanded="false"><?php if (isset($component)) { $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-avatar','data' => ['user' => $user,'class' => 'header-profile-avatar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user),'class' => 'header-profile-avatar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $attributes = $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $component = $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?></button>
                <div class="profile-dropdown" id="profileDropdown" role="menu" hidden>
                    <div class="profile-dropdown-user">
                        <strong><?php echo e($user->fullName ?: 'User'); ?></strong><small><?php echo e($user->email); ?></small></div>
                    <?php if (! ($user->isCashier())): ?>
                        <a href="<?php echo e(route('profile.edit')); ?>" role="menuitem"><span>My Profile</span></a>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('logout')); ?>" novalidate><?php echo csrf_field(); ?><button type="submit" role="menuitem">Sign
                            out</button></form>
                </div>
            </div>
        </header>

        <aside class="sidebar" id="dashboardSidebar" aria-label="Main navigation">
            <div class="sidebar-scroll">
                <?php if($user->isCashier()): ?>
                    <nav class="nav-section" aria-label="Cashier">
                        <p class="section-label">Cashier</p>
                        <a class="nav-item <?php echo e($activePage === 'cashier' ? 'is-active' : ''); ?>" href="<?php echo e(route('cashier.dashboard')); ?>" <?php if($activePage === 'cashier'): ?> aria-current="page" <?php endif; ?>>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M7 3h10l2 2v16l-3-2-4 2-4-2-3 2V5Z" /><path d="M9 8h6M9 12h6M9 16h4" /></svg>
                            <span class="nav-text">Ticket overview</span>
                        </a>
                    </nav>
                <?php else: ?>
                <nav class="nav-section">
                    <p class="section-label">Operations</p>
                    <a class="nav-item <?php echo e($activePage === 'dashboard' ? 'is-active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 11.5 12 4l9 7.5" /><path d="M5 10.5V20h5v-6h4v6h5v-9.5" /></svg>
                        <span class="nav-text">Home</span>
                    </a>
                    <a class="nav-item <?php echo e($activePage === 'analytics' ? 'is-active' : ''); ?>" href="<?php echo e(route('dashboard.analytics')); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 19V5" /><path d="m7 15 4-4 3 3 5-6" /></svg>
                        <span class="nav-text">Analytics</span>
                    </a>
                    <a class="nav-item <?php echo e($activePage === 'violation-records' ? 'is-active' : ''); ?>" href="<?php echo e(route('dashboard.violation-records')); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M7 3h10l2 2v16l-3-2-4 2-4-2-3 2V5Z" /><path d="M9 8h6M9 12h6M9 16h4" /></svg>
                        <span class="nav-text">Violation Records</span>
                    </a>
                    <a class="nav-item <?php echo e($activePage === 'location-monitoring' ? 'is-active' : ''); ?>" href="<?php echo e(route('location-monitoring.index')); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 21s7-5.2 7-12a7 7 0 1 0-14 0c0 6.8 7 12 7 12Z" /><circle cx="12" cy="9" r="2.5" /></svg>
                        <span class="nav-text">Location Monitoring</span>
                    </a>
                </nav>

                <nav class="nav-section">
                    <p class="section-label">Administration</p>
                    <details class="nav-dropdown" <?php if(str_starts_with($activePage, 'users')): ?> open <?php endif; ?>>
                        <summary class="nav-item <?php echo e(str_starts_with($activePage, 'users') ? 'is-active' : ''); ?>">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21a8 8 0 0 0-16 0" /><circle cx="12" cy="7" r="4" /></svg>
                            <span class="nav-text">Users</span><span class="nav-dropdown-arrow">&rsaquo;</span>
                        </summary>
                        <div class="nav-submenu">
                            <a class="nav-subitem <?php echo e($activePage === 'users-supervisors' ? 'is-active' : ''); ?>" href="<?php echo e(route('dashboard.users.supervisors')); ?>">Supervisors</a>
                            <a class="nav-subitem <?php echo e($activePage === 'users-enforcers' ? 'is-active' : ''); ?>" href="<?php echo e(route('dashboard.users.enforcers')); ?>">Enforcers</a>
                            <a class="nav-subitem <?php echo e($activePage === 'users-admins' ? 'is-active' : ''); ?>" href="<?php echo e(route('dashboard.users.admins')); ?>">Admins</a>
                        </div>
                    </details>
                  
                    <a class="nav-item <?php echo e($activePage === 'attendance' ? 'is-active' : ''); ?>" href="<?php echo e(route('dashboard.attendance')); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>
                        <span class="nav-text">Attendance</span>
                    </a>
                      <a class="nav-item <?php echo e($activePage === 'area-assignments' ? 'is-active' : ''); ?>" href="<?php echo e(route('area-assignments.index')); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 20h16M6 17V7l6-4 6 4v10" /><path d="M9 10h6M9 14h6" /></svg>
                        <span class="nav-text">Area Assignments</span>
                    </a>
                    <?php if($user->isAdmin()): ?>
                    <a class="nav-item <?php echo e($activePage === 'audit-logs' ? 'is-active' : ''); ?>" href="<?php echo e(route('dashboard.audit-logs')); ?>" <?php if($activePage === 'audit-logs'): ?> aria-current="page" <?php endif; ?>>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M6 3h9l3 3v15H6z"/><path d="M9 10h6M9 14h6M9 18h4M14 3v4h4"/></svg>
                        <span class="nav-text">Audit Log</span>
                    </a>
                    <?php endif; ?>
                </nav>
                <?php endif; ?>
            </div>
            <?php if (! ($user->isCashier())): ?>
            <div class="sidebar-footer">
                <a class="nav-item <?php echo e($activePage === 'profile' ? 'is-active' : ''); ?>" href="<?php echo e(route('profile.edit')); ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></svg>
                    <span class="nav-text">My Profile</span>
                </a>
                <a class="nav-item <?php echo e($activePage === 'settings' ? 'is-active' : ''); ?>" href="<?php echo e(route('dashboard.settings')); ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1A2 2 0 1 1 4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14a2 2 0 0 1 0-4 1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9A2 2 0 1 1 7.1 4.2a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3a2 2 0 0 1 4 0 1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3A2 2 0 1 1 19.8 7a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1 2 2 0 0 1 0 4 1.7 1.7 0 0 0-1.7 1Z" /></svg>
                    <span class="nav-text">Settings</span>
                </a>
            </div>
            <?php endif; ?>
        </aside>

        <main class="content">
            <section class="workspace <?php echo $__env->yieldContent('workspaceClass'); ?>">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </main>
    </div>
    <script>
        (() => {
            const frame = document.querySelector('.app-frame');
            const toggle = document.getElementById('sidebarToggle');
            const narrowSidebar = window.matchMedia('(max-width: 640px)');
            let sidebarHidden = narrowSidebar.matches;
            try {
                if (!narrowSidebar.matches) sidebarHidden = localStorage.getItem('tomeco-sidebar-hidden') === 'true';
            } catch (error) {}

            const setSidebar = (hidden) => {
                frame.classList.toggle('is-sidebar-hidden', hidden);
                document.getElementById('dashboardSidebar').inert = hidden;
                toggle.setAttribute('aria-expanded', String(!hidden));
                toggle.setAttribute('aria-label', hidden ? 'Show sidebar' : 'Hide sidebar');
                try {
                    if (!narrowSidebar.matches) localStorage.setItem('tomeco-sidebar-hidden', String(hidden));
                } catch (error) {}
            };

            setSidebar(sidebarHidden);
            toggle.addEventListener('click', () => {
                sidebarHidden = !frame.classList.contains('is-sidebar-hidden');
                setSidebar(sidebarHidden);
            });

            const profileMenu = document.getElementById('profileMenu');
            const profileMenuToggle = document.getElementById('profileMenuToggle');
            const profileDropdown = document.getElementById('profileDropdown');
            const closeProfileMenu = () => {
                profileDropdown.hidden = true;
                profileMenuToggle.setAttribute('aria-expanded', 'false');
            };

            profileMenuToggle.addEventListener('click', () => {
                const willOpen = profileDropdown.hidden;
                profileDropdown.hidden = !willOpen;
                profileMenuToggle.setAttribute('aria-expanded', String(willOpen));
            });
            document.addEventListener('click', (event) => {
                if (!profileMenu.contains(event.target)) closeProfileMenu();
            });
            document.addEventListener('keydown', (event) => {
                if (event.key === 'Escape') closeProfileMenu();
            });

            document.querySelectorAll('.success-message[role="status"], .flash-alert.is-success').forEach((
            message) => {
                window.setTimeout(() => {
                    message.classList.add('is-dismissing');
                    message.addEventListener('transitionend', () => message.remove(), {
                        once: true
                    });
                    window.setTimeout(() => message.remove(), 400);
                }, 4000);
            });
        })();
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views/layouts/admin-dashboard.blade.php ENDPATH**/ ?>