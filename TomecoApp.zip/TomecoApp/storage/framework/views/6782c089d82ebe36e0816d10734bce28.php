

<?php $__env->startSection('title', 'Supervisor Details'); ?>
<?php $__env->startSection('activePage', 'users-supervisors'); ?>
<?php $__env->startSection('workspaceClass', 'workspace-full-width'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head users-page-head">
        <div class="users-heading-copy">
            <h1><span class="management-subject">Supervisor</span> management <span class="users-heading-count"><?php echo e($supervisor->enforcers->count()); ?></span></h1>
            <p class="page-description">View the enforcers assigned to this supervisor.</p>
        </div>
    </div>

    <?php if(session('team_success')): ?>
        <div class="success-message" role="status"><?php echo e(session('team_success')); ?></div>
    <?php endif; ?>
    <?php if(session('team_error')): ?>
        <div class="success-message" role="alert"><?php echo e(session('team_error')); ?></div>
    <?php endif; ?>

    <div class="users-reference-toolbar supervisor-team-toolbar">
        <div class="users-toolbar-main"><div class="users-toolbar-actions">
            <label class="toolbar-search"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="8.5" cy="8.5" r="5"/><path d="m12.2 12.2 4 4"/></svg><span class="sr-only">Search assigned enforcers</span><input id="assignedEnforcerSearch" type="search" placeholder="Search"></label>
            <a class="toolbar-outline-button" href="<?php echo e(route('dashboard.users.supervisors')); ?>">Back</a>
            <button class="toolbar-outline-button" id="openSupervisorDetails" type="button">View details</button>
            <a class="toolbar-outline-button" href="<?php echo e(route('dashboard.users.edit', ['user' => $supervisor, 'from' => 'supervisors', 'return_to' => 'detail'])); ?>">Edit supervisor</a>
            <button class="toolbar-outline-button toolbar-add-user" id="openAddEnforcer" type="button">Add enforcer</button>
        </div>
        </div></div>

    <section class="table-card supervisor-team-full">
        <div class="table-scroll">
            <table class="users-table" id="assignedEnforcersTable">
                <thead>
                    <tr>
                        <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="7" r="3"/><path d="M4 17c.6-4 2.6-6 6-6s5.4 2 6 6"/></svg>Full name</span></th>
                        <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M6 2.8 8.3 7 6.8 8.5c1.1 2.3 2.4 3.6 4.7 4.7l1.5-1.5 4.2 2.3-.5 3"/></svg>Contact</span></th>
                        <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 18s6-5.4 6-10a6 6 0 1 0-12 0c0 4.6 6 10 6 10z"/><circle cx="10" cy="8" r="2"/></svg>Location</span></th>
                        <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="7"/><path d="m7 10 2 2 4-4"/></svg>Status</span></th>
                        <th><span class="users-column-heading"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="7"/><circle cx="10" cy="10" r="2"/></svg>Actions</span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_2 = true; $__currentLoopData = $supervisor->enforcers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enforcer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <tr data-assigned-enforcer="<?php echo e(\Illuminate\Support\Str::lower($enforcer->fullName.' '.$enforcer->username.' '.$enforcer->email)); ?>">
                            <td>
                                <div class="user-cell"><?php if (isset($component)) { $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-avatar','data' => ['user' => $enforcer]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($enforcer)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $attributes = $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $component = $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?><span><strong><?php echo e($enforcer->fullName); ?></strong><small><?php echo e($enforcer->username ? '@' . $enforcer->username : $enforcer->email); ?></small></span>
                                </div>
                            </td>
                            <td><?php echo e($enforcer->phoneNumber ?: '—'); ?><br><small><?php echo e($enforcer->email); ?></small></td>
                            <td class="location-cell"
                                title="<?php echo e(collect([$enforcer->area, $enforcer->address])->filter()->join(', ')); ?>">
                                <strong><?php echo e($enforcer->area ?: '—'); ?></strong><small
                                    class="location-truncate"><?php echo e($enforcer->address ?: 'No address'); ?></small>
                            </td>
                            <td><span class="status-badge"><i></i> Registered</span></td>
                            <td class="team-actions-column">
                                <div class="user-row-actions">
                                    <form method="POST" action="<?php echo e(route('dashboard.users.supervisors.enforcers.remove', [$supervisor, $enforcer])); ?>"
                                        onsubmit="return confirm('Remove this enforcer from the supervisor?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <details class="user-actions-menu"><summary aria-label="Actions" title="Actions">&#8942;</summary><div class="user-actions-dropdown"><a class="user-action action-edit" href="<?php echo e(route('dashboard.users.enforcers.show', $enforcer)); ?>">View details</a><button class="user-action action-delete" type="submit">Remove</button></div></details>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <tr>
                            <td colspan="5" class="empty-state"><strong>No assigned enforcers</strong><span>Assign an
                                    enforcer to this supervisor from the Enforcers section.</span></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="table-footer"><span>Showing <?php echo e($supervisor->enforcers->count()); ?> of <?php echo e($supervisor->enforcers->count()); ?></span></div>
    </section>

    <dialog class="supervisor-details-modal available-enforcers-modal" id="addEnforcerModal">
        <div class="supervisor-modal-heading">
            <div>
                <p class="eyebrow">Available</p>
                <h2>Unassigned enforcers</h2>
            </div><button id="closeAddEnforcer" type="button" aria-label="Close add enforcer form">&times;</button>
        </div>
        <div class="enforcer-modal-search">
            <label for="adminEnforcerSearch">Search by name</label>
            <input id="adminEnforcerSearch" type="search" placeholder="Enter enforcer name" autocomplete="off">
        </div>
        <div class="table-scroll">
            <table class="users-table">
                <thead><tr><th>Enforcer</th><th>Contact</th><th>Location</th><th>Action</th></tr></thead>
                <tbody id="adminAvailableEnforcers">
                    <?php $__empty_2 = true; $__currentLoopData = $availableEnforcers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enforcer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <tr data-enforcer-name="<?php echo e(\Illuminate\Support\Str::lower($enforcer->fullName)); ?>">
                            <td><div class="user-cell"><?php if (isset($component)) { $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-avatar','data' => ['user' => $enforcer]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($enforcer)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $attributes = $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $component = $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?><span><strong><?php echo e($enforcer->fullName); ?></strong><small><?php echo e($enforcer->username ? '@'.$enforcer->username : $enforcer->email); ?></small></span></div></td>
                            <td><?php echo e($enforcer->phoneNumber ?: '—'); ?></td>
                            <td class="location-cell"><strong><?php echo e($enforcer->area ?: '—'); ?></strong><small class="location-truncate"><?php echo e($enforcer->address ?: 'No address'); ?></small></td>
                            <td><form method="POST" action="<?php echo e(route('dashboard.users.supervisors.enforcers.assign', [$supervisor, $enforcer])); ?>"><?php echo csrf_field(); ?><button class="team-add-button" type="submit">Add to team</button></form></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <tr><td colspan="4" class="empty-state"><strong>No available enforcers</strong><span>All enforcers are currently assigned.</span></td></tr>
                    <?php endif; ?>
                    <tr class="enforcer-search-empty" hidden><td colspan="4" class="empty-state"><strong>No matching enforcers</strong><span>Try a different name.</span></td></tr>
                </tbody>
            </table>
        </div>
    </dialog>

    <dialog class="supervisor-details-modal" id="supervisorDetailsModal">
        <div class="supervisor-modal-heading">
            <div>
                <p class="eyebrow">Supervisor profile</p>
                <h2><?php echo e($supervisor->fullName); ?></h2>
            </div><button id="closeSupervisorDetails" type="button" aria-label="Close supervisor details">&times;</button>
        </div>
        <dl class="user-detail-list supervisor-modal-details">
            <div>
                <dt>Username</dt>
                <dd><?php echo e($supervisor->username ? '@' . $supervisor->username : '—'); ?></dd>
            </div>
            <div>
                <dt>Email</dt>
                <dd><?php echo e($supervisor->email ?: '—'); ?></dd>
            </div>
            <div>
                <dt>Phone number</dt>
                <dd><?php echo e($supervisor->phoneNumber ?: '—'); ?></dd>
            </div>
            <div>
                <dt>Area</dt>
                <dd><?php echo e($supervisor->area ?: '—'); ?></dd>
            </div>
            <div>
                <dt>Address</dt>
                <dd><?php echo e($supervisor->address ?: '—'); ?></dd>
            </div>
        </dl>
    </dialog>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const supervisorDetailsModal = document.getElementById('supervisorDetailsModal');
        const addEnforcerModal = document.getElementById('addEnforcerModal');
        const adminEnforcerSearch = document.getElementById('adminEnforcerSearch');
        const adminEnforcerRows = [...document.querySelectorAll('#adminAvailableEnforcers tr[data-enforcer-name]')];
        const adminSearchEmpty = document.querySelector('#adminAvailableEnforcers .enforcer-search-empty');
        const assignedEnforcerSearch = document.getElementById('assignedEnforcerSearch');
        const assignedEnforcerRows = [...document.querySelectorAll('#assignedEnforcersTable tr[data-assigned-enforcer]')];
        assignedEnforcerSearch.addEventListener('input', () => {
            const query = assignedEnforcerSearch.value.trim().toLowerCase();
            assignedEnforcerRows.forEach(row => row.hidden = !row.dataset.assignedEnforcer.includes(query));
        });
        document.getElementById('openAddEnforcer').addEventListener('click', () => addEnforcerModal.showModal());
        document.getElementById('closeAddEnforcer').addEventListener('click', () => addEnforcerModal.close());
        addEnforcerModal.addEventListener('click', event => {
            if (event.target === addEnforcerModal) addEnforcerModal.close();
        });
        adminEnforcerSearch.addEventListener('input', () => {
            const query = adminEnforcerSearch.value.trim().toLowerCase();
            let visible = 0;
            adminEnforcerRows.forEach(row => {
                row.hidden = !row.dataset.enforcerName.includes(query);
                if (!row.hidden) visible++;
            });
            adminSearchEmpty.hidden = visible !== 0 || adminEnforcerRows.length === 0;
        });
        document.getElementById('openSupervisorDetails').addEventListener('click', () => supervisorDetailsModal
        .showModal());
        document.getElementById('closeSupervisorDetails').addEventListener('click', () => supervisorDetailsModal.close());
        supervisorDetailsModal.addEventListener('click', event => {
            if (event.target === supervisorDetailsModal) supervisorDetailsModal.close();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.supervisor-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\supervisor\show.blade.php ENDPATH**/ ?>