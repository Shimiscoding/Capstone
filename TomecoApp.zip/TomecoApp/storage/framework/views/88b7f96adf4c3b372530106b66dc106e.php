<?php if (isset($component)) { $__componentOriginal03b6c44728e100ba2673d02906458342 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal03b6c44728e100ba2673d02906458342 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-layout','data' => ['title' => 'Reset password','page' => 'reset-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Reset password','page' => 'reset-password']); ?>
    <p class="auth-page-label">Password recovery</p>
    <h1 id="auth-heading" class="auth-title">Choose a new password</h1>
    <p class="auth-description">Enter and confirm your new password to get back to your account.</p>

    <form method="POST" action="<?php echo e(route('password.update')); ?>" class="auth-form" data-auth-form novalidate>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="token" value="<?php echo e($token); ?>">
        <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'email','label' => 'Email','type' => 'email','value' => $email,'autocomplete' => 'email','placeholder' => 'you@example.com','required' => true,'autofocus' => true,'maxlength' => '255']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email','label' => 'Email','type' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($email),'autocomplete' => 'email','placeholder' => 'you@example.com','required' => true,'autofocus' => true,'maxlength' => '255']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'password','label' => 'New password','type' => 'password','autocomplete' => 'new-password','placeholder' => 'Create a new password','required' => true,'minlength' => ''.e($passwordMinLength).'','hint' => 'At least '.e($passwordMinLength).' characters.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password','label' => 'New password','type' => 'password','autocomplete' => 'new-password','placeholder' => 'Create a new password','required' => true,'minlength' => ''.e($passwordMinLength).'','hint' => 'At least '.e($passwordMinLength).' characters.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'password_confirmation','label' => 'Confirm new password','type' => 'password','autocomplete' => 'new-password','placeholder' => 'Repeat your new password','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password_confirmation','label' => 'Confirm new password','type' => 'password','autocomplete' => 'new-password','placeholder' => 'Repeat your new password','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
        <p class="auth-form-status sr-only" role="status" aria-live="polite"></p>
        <button type="submit" class="auth-button" data-busy-label="Resetting password…">Reset password</button>
    </form>

    <p class="auth-note"><a href="<?php echo e(route('login')); ?>" class="auth-link">Back to login</a></p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal03b6c44728e100ba2673d02906458342)): ?>
<?php $attributes = $__attributesOriginal03b6c44728e100ba2673d02906458342; ?>
<?php unset($__attributesOriginal03b6c44728e100ba2673d02906458342); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal03b6c44728e100ba2673d02906458342)): ?>
<?php $component = $__componentOriginal03b6c44728e100ba2673d02906458342; ?>
<?php unset($__componentOriginal03b6c44728e100ba2673d02906458342); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\auth\reset-password.blade.php ENDPATH**/ ?>