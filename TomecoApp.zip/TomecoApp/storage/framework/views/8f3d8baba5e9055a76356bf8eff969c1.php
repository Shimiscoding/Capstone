

<?php $__env->startSection('title', $enforcer->fullName . ' Attendance'); ?>
<?php $__env->startSection('activePage', auth()->user()->isAdmin() ? 'attendance' : 'enforcer-attendance'); ?>

<?php $__env->startSection('workspaceClass', 'workspace-full-width'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head users-page-head">
        <div>
            <p class="eyebrow">Attendance history</p>
            <h1><?php echo e($enforcer->fullName); ?></h1>
            <p class="page-description">Complete Time In and Time Out timestamp history for this enforcer.</p>
        </div>
        <div class="users-page-actions"><a class="page-button detail-back-button"
                href="<?php echo e(auth()->user()->isAdmin() ? route('dashboard.attendance', ['type' => 'enforcer']) : route('supervisor.enforcers.attendance.index')); ?>"
                aria-label="Back to attendance" title="Back to attendance">&larr;</a><span
                class="user-count"><?php echo e(number_format($attendances->total())); ?> records</span></div>
    </div>

    <?php if(session('attendance_success')): ?>
        <div class="success-message" role="status"><?php echo e(session('attendance_success')); ?></div>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal0da32c90acb2d8af58f56c78694a1786 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0da32c90acb2d8af58f56c78694a1786 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.attendance-history-table','data' => ['staff' => $enforcer,'attendances' => $attendances]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('attendance-history-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['staff' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($enforcer),'attendances' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attendances)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0da32c90acb2d8af58f56c78694a1786)): ?>
<?php $attributes = $__attributesOriginal0da32c90acb2d8af58f56c78694a1786; ?>
<?php unset($__attributesOriginal0da32c90acb2d8af58f56c78694a1786); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0da32c90acb2d8af58f56c78694a1786)): ?>
<?php $component = $__componentOriginal0da32c90acb2d8af58f56c78694a1786; ?>
<?php unset($__componentOriginal0da32c90acb2d8af58f56c78694a1786); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(auth()->user()->isAdmin() ? 'layouts.admin-dashboard' : 'layouts.supervisor-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\supervisor\enforcer-attendance-show.blade.php ENDPATH**/ ?>