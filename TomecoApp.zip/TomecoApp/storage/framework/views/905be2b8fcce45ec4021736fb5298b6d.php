<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['user', 'class' => 'table-avatar']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['user', 'class' => 'table-avatar']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<span <?php echo e($attributes->class([$class, 'user-photo-avatar'])); ?>>
    <span><?php echo e(collect(preg_split('/\s+/', $user->fullName))->filter()->map(fn ($part) => mb_strtoupper(mb_substr($part, 0, 1)))->take(2)->join('') ?: 'U'); ?></span>
    <?php if($user->profile_photo_url): ?>
        <img src="<?php echo e($user->profile_photo_url); ?>" alt="" loading="lazy" onerror="this.remove()">
    <?php endif; ?>
</span>
<?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views/components/user-avatar.blade.php ENDPATH**/ ?>