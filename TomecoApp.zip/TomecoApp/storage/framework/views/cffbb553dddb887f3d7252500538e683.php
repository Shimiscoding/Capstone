

<?php
    $sectionLabel = match ($userSection ?? null) {
        'supervisors' => 'Supervisor',
        'enforcers' => 'Enforcer',
        'admins' => 'Admin',
        default => 'User',
    };
    $isRoleLocked = isset($fixedRole) || isset($editedUser);
    $lockedRole = $fixedRole ?? ($editedUser->role ?? null);
    $returnRoute = ($returnTo ?? null) === 'detail' && isset($editedUser)
        ? match ($editedUser->role) {
            \App\Models\User::ROLE_SUPERVISOR => route('dashboard.users.supervisors.show', $editedUser),
            \App\Models\User::ROLE_OFFICER => route('dashboard.users.enforcers.show', $editedUser),
            \App\Models\User::ROLE_ADMIN => route('dashboard.users.admins.show', $editedUser),
            default => route('dashboard.users.supervisors'),
        }
        : match ($userSection ?? null) {
            'supervisors' => route('dashboard.users.supervisors'),
            'enforcers' => route('dashboard.users.enforcers'),
            'admins' => route('dashboard.users.admins'),
            default => route('dashboard.users.supervisors'),
        };
?>
<?php $__env->startSection('title', isset($editedUser) ? 'Edit User' : 'Create ' . $sectionLabel); ?>
<?php $__env->startSection('workspaceClass', 'user-editor-workspace'); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/user-editor.css')); ?>?v=<?php echo e(filemtime(public_path('css/user-editor.css'))); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('activePage', $userSection ?? null ? 'users-' . $userSection : 'users'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head users-page-head">
        <div>
            <p class="eyebrow">User management</p>
            <h1><?php echo e(isset($editedUser) ? 'Edit user' : 'Create ' . $sectionLabel); ?></h1>
            <p class="page-description">
                <?php echo e(isset($editedUser) ? 'Update this TOMECO account.' : 'Add a new ' . strtolower($sectionLabel) . ' account.'); ?>

            </p>
        </div><a class="page-button" href="<?php echo e($returnRoute); ?>">Back</a>
    </div>
    <div class="create-user-card">
        <form novalidate method="POST" enctype="multipart/form-data"
            action="<?php echo e(isset($editedUser) ? route('dashboard.users.update', $editedUser) : route('dashboard.users.store')); ?>">
            <?php echo csrf_field(); ?> <?php if(isset($editedUser)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <?php if(isset($userSection)): ?>
                <input type="hidden" name="user_section" value="<?php echo e($userSection); ?>">
            <?php endif; ?>
            <?php if(($returnTo ?? null) === 'detail'): ?>
                <input type="hidden" name="return_to" value="detail">
            <?php endif; ?>
            <div class="user-editor-photo-header">
                <?php if (isset($component)) { $__componentOriginal5ec0b300512c458ac171487d7f2e54ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ec0b300512c458ac171487d7f2e54ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.profile-photo-field','data' => ['user' => $editedUser ?? null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile-photo-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($editedUser ?? null)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ec0b300512c458ac171487d7f2e54ae)): ?>
<?php $attributes = $__attributesOriginal5ec0b300512c458ac171487d7f2e54ae; ?>
<?php unset($__attributesOriginal5ec0b300512c458ac171487d7f2e54ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ec0b300512c458ac171487d7f2e54ae)): ?>
<?php $component = $__componentOriginal5ec0b300512c458ac171487d7f2e54ae; ?>
<?php unset($__componentOriginal5ec0b300512c458ac171487d7f2e54ae); ?>
<?php endif; ?>
                <div class="user-editor-photo-copy"><span class="user-editor-role"><?php echo e($sectionLabel); ?> account</span><h2><?php echo e($editedUser->fullName ?? 'Set up a new account'); ?></h2><p>The photo will appear in staff tables and location monitoring.</p></div>
            </div>
            <div class="user-form-grid">
                <div class="form-section-heading"><span>1</span>
                    <div>
                        <h2>Personal information</h2>
                        <p>Enter the user's name exactly as shown on an official ID.</p>
                    </div>
                </div>
                <div class="form-field"><label for="firstName">First name <b>Required</b></label><input id="firstName"
                        name="firstName" type="text" value="<?php echo e(old('firstName', $editedUser->firstName ?? '')); ?>"
                        placeholder="e.g., Juan" autocomplete="given-name" required>
                    <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="field-error"><?php echo e($message); ?></small><?php else: ?><small class="field-help">Given name
                            only.</small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="middleName">Middle name <em>Optional</em></label><input id="middleName"
                        name="middleName" type="text" value="<?php echo e(old('middleName', $editedUser->middleName ?? '')); ?>"
                        placeholder="e.g., Santos" autocomplete="additional-name">
                    <?php $__errorArgs = ['middleName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="field-error"><?php echo e($message); ?></small><?php else: ?><small class="field-help">Leave blank if the
                            user has no middle name.</small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="lastName">Last name <b>Required</b></label><input id="lastName"
                        name="lastName" type="text" value="<?php echo e(old('lastName', $editedUser->lastName ?? '')); ?>"
                        placeholder="e.g., Dela Cruz" autocomplete="family-name" required>
                    <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="field-error"><?php echo e($message); ?></small><?php else: ?><small class="field-help">Family or
                            surname.</small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="nameExtension">Name extension <em>Optional</em></label><input
                        id="nameExtension" name="nameExtension" type="text"
                        value="<?php echo e(old('nameExtension', $editedUser->nameExtension ?? '')); ?>"
                        placeholder="e.g., Jr., Sr., III" maxlength="20">
                    <?php $__errorArgs = ['nameExtension'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="field-error"><?php echo e($message); ?></small><?php else: ?><small class="field-help">Do not enter
                            professional titles such as Atty. or Engr.</small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="username">Username <b>Required</b></label><input id="username"
                        name="username" type="text" value="<?php echo e(old('username', $editedUser->username ?? '')); ?>"
                        placeholder="e.g., juan.delacruz" autocomplete="username" required>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="field-error"><?php echo e($message); ?></small><?php else: ?><small class="field-help">Letters, numbers,
                            dashes, and underscores only.</small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="address">Address <b>Required</b></label><input id="address"
                        name="address" type="text" value="<?php echo e(old('address', $editedUser->address ?? '')); ?>"
                        placeholder="House number and street" autocomplete="street-address" required>
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <?php if (! ($isRoleLocked)): ?>
                    <div class="form-section-heading"><span>2</span>
                        <div>
                            <h2>Account assignment</h2>
                            <p>Select a role first; applicable identification fields will be enabled automatically.</p>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($isRoleLocked): ?>
                    <input id="role" name="role" type="hidden" value="<?php echo e($fixedRole ?? $editedUser->role); ?>">
                <?php else: ?>
                    <div class="form-field"><label for="role">Account role <b>Required</b></label><select id="role"
                            name="role" required>
                            <option value="officer" <?php if(old('role', $editedUser->role ?? 'officer') === 'officer'): echo 'selected'; endif; ?>>Enforcer</option>
                            <option value="supervisor" <?php if(old('role', $editedUser->role ?? '') === 'supervisor'): echo 'selected'; endif; ?>>Supervisor</option>
                            <option value="admin" <?php if(old('role', $editedUser->role ?? '') === 'admin'): echo 'selected'; endif; ?>>Administrator</option>
                        </select>
                        <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small><?php else: ?><small class="field-help"
                                id="roleHelp">Controls dashboard permissions and required identification.</small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
                <div class="form-field" id="supervisorField"><label for="supervisor_id">Supervisor <b>Optional</b></label><select id="supervisor_id" name="supervisor_id">
                        <option value="">No supervisor (unassigned)</option>
                        <?php $__currentLoopData = $supervisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($supervisor->id); ?>" <?php if((string) old('supervisor_id', $editedUser->supervisor_id ?? '') === (string) $supervisor->id): echo 'selected'; endif; ?>>
                                <?php echo e($supervisor->fullName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['supervisor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="field-error"><?php echo e($message); ?></small><?php else: ?><small class="field-help">Optionally assign a
                            supervisor responsible for this enforcer.</small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-section-heading"><span>2</span>
                    <div>
                        <h2>Contact and security</h2>
                        <p>Provide working contact details and secure account credentials.</p>
                    </div>
                </div>
                <div class="form-field"><label for="phoneNumber">Phone number <b>Required</b></label><input
                        id="phoneNumber" name="phoneNumber" type="tel"
                        value="<?php echo e(old('phoneNumber', $editedUser->phoneNumber ?? '')); ?>" placeholder="e.g., 09171234567"
                        inputmode="numeric" pattern="09[0-9]{9}" minlength="11" maxlength="11"
                        title="Enter exactly 11 digits starting with 09" autocomplete="tel"
                        oninput="this.value=this.value.replace(/\D/g, '').slice(0, 11)" required>
                    <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="field-error"><?php echo e($message); ?></small><?php else: ?><small class="field-help">Enter exactly 11
                            digits beginning with 09.</small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label for="email">Email address <b>Required</b></label><input id="email" name="email"
                        type="email" value="<?php echo e(old('email', $editedUser->email ?? '')); ?>"
                        placeholder="e.g., juan@example.com" autocomplete="email" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="field-error"><?php echo e($message); ?></small><?php else: ?><small class="field-help">This email is
                            used to sign in.</small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field"><label
                        for="password"><?php echo e(isset($editedUser) ? 'New password' : 'Temporary password'); ?> <?php if(isset($editedUser)): ?>
                        <em>Optional</em><?php else: ?><b>Required</b>
                        <?php endif; ?>
                    </label>
                    <div class="user-password-field"><input id="password" name="password" type="password"
                            placeholder="<?php echo e(isset($editedUser) ? 'Leave blank to keep current password' : 'At least 8 characters'); ?>"
                            autocomplete="new-password" <?php if(!isset($editedUser)): echo 'required'; endif; ?>><button class="user-password-toggle"
                            type="button" data-password-target="password" aria-label="Show temporary password"
                            aria-pressed="false">Show</button></div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="field-error"><?php echo e($message); ?></small><?php else: ?><small class="field-help">Use a strong
                            password that is not shared with other accounts.</small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <?php if(isset($editedUser)): ?>
                    <div class="form-field"><label for="account_status">Account status <b>Required</b></label><select id="account_status" name="account_status" required>
                        <?php $__currentLoopData = \App\Models\User::ACCOUNT_STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accountStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($accountStatus); ?>" <?php if(old('account_status', $editedUser->effectiveAccountStatus()) === $accountStatus): echo 'selected'; endif; ?>><?php echo e(ucfirst($accountStatus)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['account_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php else: ?><small class="field-help">Inactive, suspended, and banned accounts cannot sign in.</small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                <?php endif; ?>
                <div class="form-field"><label for="password_confirmation">Confirm password <?php if(isset($editedUser)): ?>
                        <em>Optional</em><?php else: ?><b>Required</b>
                        <?php endif; ?>
                    </label>
                    <div class="user-password-field"><input id="password_confirmation" name="password_confirmation"
                            type="password" placeholder="Re-enter the password" autocomplete="new-password"
                            <?php if(!isset($editedUser)): echo 'required'; endif; ?>><button class="user-password-toggle" type="button"
                            data-password-target="password_confirmation" aria-label="Show password confirmation"
                            aria-pressed="false">Show</button></div><small class="field-help">Must exactly match the
                        password above.</small>
                </div>
            </div>
            <div class="user-form-actions"><a class="page-button"
                    href="<?php echo e($returnRoute); ?>">Cancel</a><button
                    type="submit"><?php echo e(isset($editedUser) ? 'Update user' : 'Create user'); ?></button></div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const roleInput = document.getElementById('role');
        const supervisorInput = document.getElementById('supervisor_id');
        const supervisorField = document.getElementById('supervisorField');

        function syncRoleFields() {
            const isEnforcer = roleInput.value === 'officer';
            supervisorField.hidden = !isEnforcer;
            supervisorInput.disabled = !isEnforcer;
            supervisorInput.required = false;
        }
        roleInput.addEventListener('change', syncRoleFields);
        syncRoleFields();
        document.querySelectorAll('.user-password-toggle').forEach(button => {
            button.addEventListener('click', () => {
                const input = document.getElementById(button.dataset.passwordTarget);
                const isVisible = input.type === 'text';
                input.type = isVisible ? 'password' : 'text';
                button.textContent = isVisible ? 'Show' : 'Hide';
                button.setAttribute('aria-pressed', String(!isVisible));
                button.setAttribute('aria-label',
                    `${isVisible ? 'Show' : 'Hide'} ${input.id === 'password_confirmation' ? 'password confirmation' : 'temporary password'}`
                    );
                input.focus();
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\dashboard\users\user-create.blade.php ENDPATH**/ ?>