<?php $__env->startSection('title', $violation->full_name.' Violation History'); ?>
<?php $__env->startSection('activePage', 'violation-records'); ?>
<?php $__env->startSection('workspaceClass', 'workspace-full-width'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $motoristName = $violation->full_name ?: 'Unknown driver';
        $permitType = match ($violation->license_type) {
            'professional' => 'Professional',
            'non_professional' => 'Non-professional',
            'student_permit' => 'Student permit',
            'other' => 'Other',
            default => 'Not specified',
        };
        $signedViolation = $motoristViolations->first(fn ($record) => filled($record->signature));
        $imageSource = static function (?string $value): ?string {
            $value = trim((string) $value);

            if (preg_match('/^data:image\/(?:png|jpe?g|webp);base64,[A-Za-z0-9+\/=\s]+$/i', $value)) {
                return $value;
            }

            return $value !== '' && preg_match('/^[A-Za-z0-9+\/=\s]+$/', $value)
                ? 'data:image/png;base64,'.preg_replace('/\s+/', '', $value)
                : null;
        };
        $signatureSource = \App\Support\SignatureImage::source($signedViolation?->signature);
    ?>

    <div class="page-head users-page-head violation-detail-page-head">
        <div class="users-heading-copy">
            <p class="eyebrow">Violation records</p>
            <h1>Driver details</h1>
            <p class="page-description">Review the driver profile and complete citation history.</p>
        </div>
        <a class="page-button detail-back-button violation-back-button" href="<?php echo e(route('dashboard.violation-records')); ?>">
            <span aria-hidden="true">&larr;</span><span>Back to records</span>
        </a>
    </div>

    <section class="create-user-card staff-detail-card violation-motorist-details">
        <div class="staff-detail-heading">
            <span class="table-avatar"><?php echo e(collect(explode(' ', $motoristName))->filter()->map(fn($part) => strtoupper(substr($part, 0, 1)))->take(2)->join('') ?: 'M'); ?></span>
            <div>
                <h2><?php echo e($motoristName); ?></h2>
                <p><span class="role-badge">Driver</span><span class="status-badge"><i></i><?php echo e($motoristViolations->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('citation', $motoristViolations->count())); ?></span></p>
            </div>
        </div>
        <dl class="user-detail-list staff-detail-list">
            <div><dt>First name</dt><dd><?php echo e($violation->first_name ?: '—'); ?></dd></div>
            <div><dt>Middle name</dt><dd><?php echo e($violation->middle_name ?: '—'); ?></dd></div>
            <div><dt>Last name</dt><dd><?php echo e($violation->last_name ?: '—'); ?></dd></div>
            <div><dt>D/L permit number</dt><dd><?php echo e($violation->license_number ?: '—'); ?></dd></div>
            <div><dt>Permit type</dt><dd><?php echo e($permitType); ?></dd></div>
            <div><dt>Vehicle type</dt><dd><?php echo e($violation->vehicle_type ?: 'Not specified'); ?></dd></div>
            <div><dt>Total assessed fines</dt><dd>&#8369;<?php echo e(number_format($motoristViolations->sum('fine_amount'), 2)); ?></dd></div>
            <div class="motorist-signature-detail">
                <dt>Driver signature</dt>
                <dd>
                    <?php if($signatureSource): ?>
                        <img src="<?php echo e($signatureSource); ?>" alt="<?php echo e($motoristName); ?> signature">
                        <small>Captured for ticket #<?php echo e(str_pad((string) $signedViolation->id, 7, '0', STR_PAD_LEFT)); ?></small>
                    <?php else: ?>
                        <span class="signature-empty">Not recorded</span>
                    <?php endif; ?>
                </dd>
            </div>
        </dl>
    </section>

    <section class="table-card">
        <div class="table-scroll">
            <table class="users-table">
                <thead><tr><th>Ticket</th><th>Violation</th><th>Plate number</th><th>OR / CR</th><th>Location</th><th>Enforcer</th><th>Date issued</th><th>Fine</th><th>Status</th></tr></thead>
                <tbody>
                    <?php $__currentLoopData = $motoristViolations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($enforcerSignature = \App\Support\SignatureImage::source($record->enforcer_signature)); ?>
                        <tr>
                            <td><div class="user-cell"><span class="table-avatar">T</span><span><strong>#<?php echo e(str_pad((string) $record->id, 7, '0', STR_PAD_LEFT)); ?></strong><small><?php echo e($record->created_at?->format('h:i A')); ?></small></span></div></td>
                            <td><strong><?php echo e($record->violation_type ?: '—'); ?></strong></td>
                            <td><span class="badge-number"><?php echo e($record->plate_number ?: '—'); ?></span></td>
                            <td><span class="violation-permit-cell"><span>OR: <?php echo e($record->or_number ?: '—'); ?></span><small>CR: <?php echo e($record->cr_number ?: '—'); ?></small></span></td>
                            <td><?php echo e($record->location ?: '—'); ?></td>
                            <td>
                                <div class="citation-enforcer">
                                    <?php if($record->enforcer): ?>
                                        <strong><?php echo e($record->enforcer_name ?: $record->enforcer->fullName); ?></strong>
                                        <small>Issuing enforcer</small>
                                        <?php if($enforcerSignature): ?>
                                            <img src="<?php echo e($enforcerSignature); ?>" alt="<?php echo e($record->enforcer_name ?: $record->enforcer->fullName); ?> signature">
                                        <?php else: ?>
                                            <span>Signature not recorded</span>
                                        <?php endif; ?>
                                    <?php elseif($record->enforcer_name): ?>
                                        <strong><?php echo e($record->enforcer_name); ?></strong>
                                        <small>Issuing enforcer (archived account)</small>
                                    <?php else: ?>
                                        <strong>Not recorded</strong>
                                        <small>Legacy ticket</small>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td><?php echo e($record->created_at?->format('M d, Y') ?? '—'); ?></td>
                            <td><strong>&#8369;<?php echo e(number_format($record->fine_amount, 2)); ?></strong></td>
                            <td><span class="status-badge <?php echo e($record->status === 'paid' ? '' : 'status-pending'); ?>"><i></i><?php echo e(ucfirst($record->status ?: 'unpaid')); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="table-footer"><span>Showing <?php echo e($motoristViolations->count()); ?> of <?php echo e($motoristViolations->count()); ?> records</span></div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\dashboard\violation-record-show.blade.php ENDPATH**/ ?>