<?php $__env->startSection('title', 'Access denied'); ?>
<?php $__env->startSection('workspaceClass', 'workspace-full-width'); ?>

<?php $__env->startSection('content'); ?>
    <header class="page-head">
        <div>
            <p class="eyebrow">403 / Access denied</p>
            <h1>Ticket overview access only</h1>
            <p class="page-description">Your cashier account can view the ticket overview. This page is unavailable for your role.</p>
        </div>
    </header>
    <a class="page-button" href="<?php echo e(route('cashier.dashboard')); ?>">Back to ticket overview</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\cashier\forbidden.blade.php ENDPATH**/ ?>