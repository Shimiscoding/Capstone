<?php if (isset($component)) { $__componentOriginal03b6c44728e100ba2673d02906458342 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal03b6c44728e100ba2673d02906458342 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-layout','data' => ['title' => 'Log in']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Log in']); ?>
    <p class="auth-page-label">Log in</p>
    <h1 id="auth-heading" class="auth-title">Welcome back.</h1>
    <p class="auth-description">Log in to manage your daily traffic operations.</p>

    <?php if(session('status')): ?>
        <p class="auth-status" role="status"><?php echo e(session('status')); ?></p>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login.store')); ?>" class="auth-form" data-auth-form novalidate>
        <?php echo csrf_field(); ?>
        <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'login','label' => 'Username or email','autocomplete' => 'username','placeholder' => 'Enter your username or email','required' => true,'autofocus' => true,'maxlength' => '255']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'login','label' => 'Username or email','autocomplete' => 'username','placeholder' => 'Enter your username or email','required' => true,'autofocus' => true,'maxlength' => '255']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale2be5f5f1c011e26e63e98af53354f16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2be5f5f1c011e26e63e98af53354f16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-field','data' => ['name' => 'password','label' => 'Password','type' => 'password','autocomplete' => 'current-password','placeholder' => 'Enter your password','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password','label' => 'Password','type' => 'password','autocomplete' => 'current-password','placeholder' => 'Enter your password','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $attributes = $__attributesOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__attributesOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2be5f5f1c011e26e63e98af53354f16)): ?>
<?php $component = $__componentOriginale2be5f5f1c011e26e63e98af53354f16; ?>
<?php unset($__componentOriginale2be5f5f1c011e26e63e98af53354f16); ?>
<?php endif; ?>
        <div class="auth-login-options">
            <label class="auth-check"><input type="checkbox" name="remember" value="1" <?php if(old('remember')): echo 'checked'; endif; ?>> Remember me</label>
            <a href="<?php echo e(route('password.request')); ?>" class="auth-link auth-forgot-link">Forgot password?</a>
        </div>
        <p class="auth-form-status sr-only" role="status" aria-live="polite"></p>
        <button type="submit" class="auth-button" data-busy-label="Logging in…">Log in <span aria-hidden="true">→</span></button>
    </form>
    <?php if($adminSignupEnabled): ?>
        <p class="auth-note">Need an administrator account? <a href="<?php echo e(route('register')); ?>" class="auth-link">Sign up as admin</a></p>
    <?php endif; ?>
    <p class="auth-note auth-support-note">Having trouble logging in?<br>Contact your administrator for help.</p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal03b6c44728e100ba2673d02906458342)): ?>
<?php $attributes = $__attributesOriginal03b6c44728e100ba2673d02906458342; ?>
<?php unset($__attributesOriginal03b6c44728e100ba2673d02906458342); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal03b6c44728e100ba2673d02906458342)): ?>
<?php $component = $__componentOriginal03b6c44728e100ba2673d02906458342; ?>
<?php unset($__componentOriginal03b6c44728e100ba2673d02906458342); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\auth\login.blade.php ENDPATH**/ ?>