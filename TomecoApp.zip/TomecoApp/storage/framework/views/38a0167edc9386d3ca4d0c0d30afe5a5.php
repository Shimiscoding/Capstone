<?php $__env->startSection('title', 'Violation ticket '.$violation->display_ticket_number); ?>
<?php $__env->startSection('activePage', 'violation-records'); ?>
<?php $__env->startSection('workspaceClass', 'workspace-full-width'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $ticketNumber = $violation->display_ticket_number;
    $permitType = match ($violation->license_type) { 'professional' => 'Professional', 'non_professional' => 'Non-professional', 'student_permit' => 'Student permit', default => 'Not specified' };
    $imageSource = static function (?string $value): ?string {
        $value = trim((string) $value);
        if ($value === '') return null;
        if (preg_match('/^data:image\/(?:png|jpe?g|webp);base64,[A-Za-z0-9+\/=\s]+$/i', $value)) return preg_replace('/\s+/', '', $value);
        return preg_match('/^[A-Za-z0-9+\/=\s]+$/', $value) ? 'data:image/jpeg;base64,'.preg_replace('/\s+/', '', $value) : null;
    };
    $evidenceSources = [];
    foreach ($violation->evidence_photos as $index => $photo) {
        $source = str_starts_with($photo, \App\Services\TicketEvidence::PREFIX)
            ? route('tickets.evidence', [$violation, $index]) : $imageSource($photo);
        if ($source) $evidenceSources[] = $source;
    }
    $motoristSignatureSource = \App\Support\SignatureImage::source($violation->signature);
    $enforcerSignatureSource = \App\Support\SignatureImage::source($violation->enforcer_signature);
?>

<header class="page-head violation-detail-page-head">
    <div><nav class="detail-breadcrumb" aria-label="Breadcrumb"><a href="<?php echo e(route('dashboard.violation-records')); ?>">Violation records</a><span aria-hidden="true">/</span><span aria-current="page"><?php echo e($ticketNumber); ?></span></nav><h1>Violation ticket <?php echo e($ticketNumber); ?></h1><p class="page-description">Complete citation record and captured supporting evidence.</p></div>
    <a class="page-button violation-back-button" href="<?php echo e(route('dashboard.violation-records')); ?>"><span aria-hidden="true">&larr;</span><span>Back to records</span></a>
</header>

<div class="violation-detail-layout">
    <div class="violation-detail-main">
        <section class="violation-detail-card"><header class="violation-detail-section-head"><h2>Driver and permit</h2></header><dl class="violation-detail-list">
            <div><dt>Full name</dt><dd><?php echo e($violation->full_name ?: 'Not recorded'); ?></dd></div><div><dt>D/L permit number</dt><dd><?php echo e($violation->license_number ?: 'Not recorded'); ?></dd></div>
            <div><dt>First name</dt><dd><?php echo e($violation->first_name ?: '—'); ?></dd></div><div><dt>Middle name</dt><dd><?php echo e($violation->middle_name ?: '—'); ?></dd></div>
            <div><dt>Last name</dt><dd><?php echo e($violation->last_name ?: '—'); ?></dd></div><div><dt>Permit type</dt><dd><?php echo e($permitType); ?></dd></div>
        </dl></section>
        <section class="violation-detail-card"><header class="violation-detail-section-head"><h2>Vehicle documents</h2></header><dl class="violation-detail-list">
            <div><dt>Observed plate</dt><dd><?php echo e($violation->plate_number ?: 'Not recorded'); ?></dd></div><div><dt>Document plate</dt><dd><?php echo e($violation->registration_plate_number ?: 'Not recorded'); ?></dd></div>
            <div><dt>Vehicle description</dt><dd><?php echo e($violation->vehicle_type ?: 'Not recorded'); ?></dd></div><div><dt>Make</dt><dd><?php echo e($violation->vehicle_make ?: 'Not recorded'); ?></dd></div>
            <div><dt>Model / series</dt><dd><?php echo e($violation->vehicle_series ?: 'Not recorded'); ?></dd></div><div><dt>Body type</dt><dd><?php echo e($violation->vehicle_body_type ?: 'Not recorded'); ?></dd></div>
            <div><dt>Year model</dt><dd><?php echo e($violation->vehicle_year_model ?: 'Not recorded'); ?></dd></div>
            <div><dt>Official receipt (OR)</dt><dd><?php echo e($violation->or_number ?: 'Not recorded'); ?></dd></div><div><dt>Certificate of registration (CR)</dt><dd><?php echo e($violation->cr_number ?: 'Not recorded'); ?></dd></div>
        </dl></section>
        <section class="violation-detail-card"><header class="violation-detail-section-head"><h2>Registered owner</h2></header><dl class="violation-detail-list">
            <div><dt>Owner name</dt><dd><?php echo e($violation->registered_owner_name ?: 'Not recorded'); ?></dd></div><div><dt>Owner address</dt><dd><?php echo e($violation->registered_owner_address ?: 'Not recorded'); ?></dd></div>
        </dl></section>
        <section class="violation-detail-card"><header class="violation-detail-section-head"><h2>Evidence images</h2><span class="record-state <?php echo e($evidenceSources ? 'is-recorded' : 'is-missing'); ?>"><?php echo e($evidenceSources ? count($evidenceSources).' recorded' : 'Not recorded'); ?></span></header>
            <?php $__empty_2 = true; $__currentLoopData = $evidenceSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?><figure class="violation-evidence-image"><img src="<?php echo e($source); ?>" alt="Evidence photo <?php echo e($index + 1); ?> for violation ticket <?php echo e($ticketNumber); ?>"><figcaption>Evidence photo <?php echo e($index + 1); ?> of <?php echo e(count($evidenceSources)); ?></figcaption></figure><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?><div class="record-empty">No evidence image was submitted for this ticket.</div><?php endif; ?>
        </section>
        <section class="violation-signatures-grid" aria-label="Ticket signatures">
            <?php $__currentLoopData = [['Driver signature', $motoristSignatureSource, $violation->full_name ?: 'Driver'], ['Enforcer signature', $enforcerSignatureSource, $violation->enforcer_name ?: 'Enforcer']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $source, $name]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="violation-detail-card signature-record"><header class="violation-detail-section-head"><h2><?php echo e($label); ?></h2><span class="record-state <?php echo e($source ? 'is-recorded' : 'is-missing'); ?>"><?php echo e($source ? 'Recorded' : 'Not recorded'); ?></span></header><div class="signature-record-body"><?php if($source): ?><img src="<?php echo e($source); ?>" alt="<?php echo e($name); ?> signature"><p><?php echo e($name); ?> · Captured for ticket <?php echo e($ticketNumber); ?></p><?php else: ?><div class="record-empty">No signature was captured.</div><?php endif; ?></div></article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    </div>
    <aside class="violation-detail-card violation-citation-card"><header class="violation-detail-section-head"><h2>Citation summary</h2><span class="status-badge <?php echo e($violation->status === 'paid' ? '' : 'status-pending'); ?>"><i></i><?php echo e(ucfirst($violation->status ?: 'unpaid')); ?></span></header><dl class="violation-detail-list">
        <div><dt>Cited violations</dt><dd>
            <?php $__empty_2 = true; $__currentLoopData = $violation->issuedViolations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                <?php
                    $normalizeLabel = fn ($text) => preg_replace('/[^\p{L}\p{N}]+/u', '', mb_strtolower($text ?? ''));
                    $showDescription = filled($offense->description_snapshot)
                        && $normalizeLabel($offense->description_snapshot) !== $normalizeLabel($offense->formOption->label);
                ?>
                <p><strong><?php echo e($offense->formOption->label); ?></strong><br>
                    <?php if($showDescription): ?><?php echo e($offense->description_snapshot); ?><br><?php endif; ?>
                    <?php if($offense->type): ?><small>Sec. <?php echo e($offense->type->section_id); ?></small><?php endif; ?>
                    <?php if($offense->remarks): ?><br><small><?php echo e($offense->remarks); ?></small><?php endif; ?>
                </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                Not recorded
            <?php endif; ?>
        </dd></div><div class="violation-fine-row"><dt>Assessed fine</dt><dd>&#8369;<?php echo e(number_format($violation->fine_amount, 2)); ?></dd></div>
        <div><dt>Issued</dt><dd><?php echo e($violation->created_at?->format('M d, Y · h:i A') ?? 'Not recorded'); ?></dd></div><div><dt>Location</dt><dd><?php echo e($violation->location ?: 'Not recorded'); ?></dd></div>
        <div><dt>Issuing enforcer</dt><dd><?php echo e($violation->enforcer_name ?: $violation->enforcer?->fullName ?: 'Not recorded'); ?></dd></div>
    </dl></aside>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\dashboard\violation-ticket-show.blade.php ENDPATH**/ ?>