<?php $__env->startSection('title', 'Cashier dashboard'); ?>
<?php $__env->startSection('activePage', 'cashier'); ?>
<?php $__env->startSection('workspaceClass', 'workspace-full-width cashier-workspace'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/cashier-dashboard.css')); ?>?v=<?php echo e(filemtime(public_path('css/cashier-dashboard.css'))); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <header class="page-head users-page-head">
        <div>
            <p class="eyebrow">Cashier dashboard</p>
            <h1>Ticket overview</h1>
            <p class="page-description">Review issued tickets, assessed fines, and recorded payment status.</p>
        </div>
        <div class="user-count"><?php echo e(number_format($tickets->total())); ?> <?php echo e(\Illuminate\Support\Str::plural('ticket', $tickets->total())); ?></div>
    </header>

    <div class="table-card">
        <div class="table-scroll" tabindex="0" role="region" aria-label="Issued tickets. Scroll horizontally to see all columns.">
            <table class="users-table cashier-tickets-table">
                <caption class="sr-only">Issued tickets, newest first. Dates and times are in Philippine time.</caption>
                <thead>
                    <tr>
                        <th scope="col">Ticket</th>
                        <th scope="col">Motorist</th>
                        <th scope="col">Plate number</th>
                        <th scope="col">Violation</th>
                        <th scope="col">Assessed fine</th>
                        <th scope="col">Status</th>
                        <th scope="col">Issued (PHT)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_2 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <tr>
                            <th scope="row" class="cashier-ticket-id"><?php echo e($ticket->display_ticket_number); ?></th>
                            <td><?php echo e($ticket->full_name ?: 'Not recorded'); ?></td>
                            <td><?php echo e($ticket->plate_number ?: 'Not recorded'); ?></td>
                            <td><?php echo e($ticket->violation_type ?: 'Not recorded'); ?></td>
                            <td class="cashier-fine">&#8369;<?php echo e(number_format((float) $ticket->fine_amount, 2)); ?></td>
                            <td><span class="status-badge <?php echo e($ticket->status === 'paid' ? '' : 'status-pending'); ?>"><i aria-hidden="true"></i><?php echo e(filled($ticket->status) ? ucfirst($ticket->status) : 'Not recorded'); ?></span></td>
                            <td>
                                <?php if($ticket->created_at): ?>
                                    <time datetime="<?php echo e($ticket->created_at->toIso8601String()); ?>"><?php echo e($ticket->created_at->copy()->timezone('Asia/Manila')->format('M d, Y')); ?><small><?php echo e($ticket->created_at->copy()->timezone('Asia/Manila')->format('h:i A')); ?></small></time>
                                <?php else: ?>
                                    Not recorded
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <tr><td colspan="7" class="empty-state"><strong>No tickets available</strong><span>Issued tickets will appear here once they are recorded.</span></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <footer class="table-footer">
            <span>Showing <?php echo e($tickets->firstItem() ?? 0); ?>&ndash;<?php echo e($tickets->lastItem() ?? 0); ?> of <?php echo e(number_format($tickets->total())); ?></span>
            <nav class="pagination-actions" aria-label="Ticket pages">
                <?php if($tickets->onFirstPage()): ?>
                    <span class="page-button is-disabled" aria-disabled="true">Previous</span>
                <?php else: ?>
                    <a class="page-button" href="<?php echo e($tickets->previousPageUrl()); ?>" rel="prev">Previous</a>
                <?php endif; ?>
                <?php if($tickets->hasMorePages()): ?>
                    <a class="page-button" href="<?php echo e($tickets->nextPageUrl()); ?>" rel="next">Next</a>
                <?php else: ?>
                    <span class="page-button is-disabled" aria-disabled="true">Next</span>
                <?php endif; ?>
            </nav>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Capstone\TomecoApp\resources\views\cashier\index.blade.php ENDPATH**/ ?>